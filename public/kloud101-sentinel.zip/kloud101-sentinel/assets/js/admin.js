/**
 * Kloud101 Sentinel — shared admin screen behavior.
 *
 * Drives the scan-trigger buttons on both the Dashboard and the Run
 * Scan page (they share the same markup contract: a button with class
 * "k101-scan-trigger" and a "data-scan-type" attribute, plus a
 * "#k101-scan-progress" container with a ".k101-progress-fill" bar and
 * a ".k101-progress-status" paragraph), and confirms destructive
 * quarantine actions before navigating to them.
 */
( function ( $ ) {
	'use strict';

	if ( 'undefined' === typeof kloud101Sentinel ) {
		return;
	}

	/**
	 * Poll process_batch() until a scan reports done:true, updating the
	 * progress bar after every batch.
	 *
	 * @param {number} reportId Report ID returned by start_scan.
	 * @param {jQuery} $progress Progress container element.
	 * @param {jQuery} $buttons  Scan trigger buttons (re-enabled on finish).
	 */
	function pollBatch( reportId, $progress, $buttons ) {
		$.post( kloud101Sentinel.ajaxUrl, {
			action: 'kloud101_sentinel_scan_batch',
			nonce: kloud101Sentinel.nonce,
			report_id: reportId,
		} )
			.done( function ( response ) {
				if ( ! response || ! response.success ) {
					showFailure( $progress, $buttons );
					return;
				}

				var data = response.data;
				var percent = data.total > 0 ? Math.min( 100, Math.round( ( data.processed / data.total ) * 100 ) ) : 100;

				$progress.find( '.k101-progress-fill' ).css( 'width', percent + '%' );
				$progress.find( '.k101-progress-status' ).text(
					data.processed + ' / ' + data.total + ' — ' + data.findings + ' finding(s) so far'
				);

				if ( data.done ) {
					$progress.find( '.k101-progress-status' ).text( kloud101Sentinel.i18n.scanComplete + ' (' + data.findings + ' finding(s))' );
					$buttons.prop( 'disabled', false );
					window.setTimeout( function () {
						window.location.reload();
					}, 1500 );
					return;
				}

				pollBatch( reportId, $progress, $buttons );
			} )
			.fail( function () {
				showFailure( $progress, $buttons );
			} );
	}

	/**
	 * Show a failure state on the progress panel and re-enable buttons.
	 *
	 * @param {jQuery} $progress Progress container element.
	 * @param {jQuery} $buttons  Scan trigger buttons.
	 */
	function showFailure( $progress, $buttons ) {
		$progress.find( '.k101-progress-status' ).text( kloud101Sentinel.i18n.scanFailed );
		$buttons.prop( 'disabled', false );
	}

	$( function () {
		var $buttons = $( '.k101-scan-trigger' );
		var $progress = $( '#k101-scan-progress' );

		$buttons.on( 'click', function () {
			var scanType = $( this ).data( 'scan-type' );

			$buttons.prop( 'disabled', true );
			$progress.removeAttr( 'hidden' );
			$progress.find( '.k101-progress-fill' ).css( 'width', '0%' );
			$progress.find( '.k101-progress-status' ).text( kloud101Sentinel.i18n.scanning );

			$.post( kloud101Sentinel.ajaxUrl, {
				action: 'kloud101_sentinel_start_scan',
				nonce: kloud101Sentinel.nonce,
				scan_type: scanType,
			} )
				.done( function ( response ) {
					if ( ! response || ! response.success ) {
						showFailure( $progress, $buttons );
						return;
					}

					var data = response.data;

					if ( data.done ) {
						$progress.find( '.k101-progress-fill' ).css( 'width', '100%' );
						$progress.find( '.k101-progress-status' ).text( kloud101Sentinel.i18n.scanComplete );
						$buttons.prop( 'disabled', false );
						return;
					}

					pollBatch( data.report_id, $progress, $buttons );
				} )
				.fail( function () {
					showFailure( $progress, $buttons );
				} );
		} );

		// Confirm permanent quarantine deletion before following the link.
		$( document ).on( 'click', '.k101-confirm-delete', function ( event ) {
			if ( ! window.confirm( kloud101Sentinel.i18n.confirmDelete ) ) {
				event.preventDefault();
			}
		} );
	} );
} )( jQuery );
