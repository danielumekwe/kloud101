<?php
/**
 * Settings screen: General, Scanning, Login Protection, Firewall,
 * Hardening, and Notifications tabs, backed by the Settings API.
 *
 * @package Kloud101Sentinel\Admin
 */

namespace Kloud101Sentinel\Admin;

use Kloud101Sentinel\Includes\Installer;
use Kloud101Sentinel\Includes\Loader;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Settings
 *
 * All settings are stored in the single `kloud101_sentinel_settings`
 * option (an associative array) rather than one WordPress option per
 * field, so the whole configuration can be read/exported/reasoned
 * about atomically. sanitize() is the single choke point every value
 * passes through before being persisted.
 */
class Settings {

	/**
	 * @var array<string, object>
	 */
	private $modules;

	/**
	 * Constructor.
	 *
	 * @param array<string, object> $modules Live module instances.
	 */
	public function __construct( array $modules ) {
		$this->modules = $modules;
	}

	/**
	 * Register hooks.
	 *
	 * @param Loader $loader Shared hook loader.
	 */
	public function register( Loader $loader ) {
		$loader->add_action( 'admin_menu', $this, 'register_menu' );
		$loader->add_action( 'admin_init', $this, 'register_settings' );
		$loader->add_action( 'admin_init', $this, 'handle_hardening_actions' );
		$loader->add_action( 'update_option_kloud101_sentinel_settings', $this, 'apply_hardening_side_effects', 10, 2 );
	}

	/**
	 * Register the Settings submenu page.
	 */
	public function register_menu() {
		add_submenu_page(
			'kloud101-sentinel',
			__( 'Settings', 'kloud101-sentinel' ),
			__( 'Settings', 'kloud101-sentinel' ),
			'manage_kloud101_sentinel',
			'kloud101-sentinel-settings',
			array( $this, 'render_page' )
		);
	}

	/**
	 * Register the setting with the Settings API.
	 */
	public function register_settings() {
		register_setting(
			'kloud101_sentinel_settings_group',
			'kloud101_sentinel_settings',
			array(
				'type'              => 'array',
				'sanitize_callback' => array( $this, 'sanitize' ),
			)
		);
	}

	/**
	 * Sanitize submitted settings, filling in any missing keys from
	 * defaults so a partially-submitted form (e.g. one tab at a time)
	 * never silently drops the rest of the configuration.
	 *
	 * @param array $input Raw submitted values.
	 * @return array<string, mixed>
	 */
	public function sanitize( $input ) {
		$existing = wp_parse_args( get_option( 'kloud101_sentinel_settings', array() ), Installer::default_settings() );
		$input    = is_array( $input ) ? $input : array();

		$booleans = array(
			'scan_uploads_on_schedule', 'enable_wordpress_org_lookups', 'email_notifications', 'firewall_enabled',
			'firewall_block_sqli', 'firewall_block_xss', 'firewall_block_traversal', 'firewall_block_bad_bots',
			'hardening_disable_xmlrpc', 'hardening_disable_file_edit', 'hardening_block_php_uploads',
			'hardening_hide_wp_version', 'hardening_disable_dir_browsing', 'hardening_restrict_rest_api',
			'remove_data_on_uninstall',
		);

		$output = $existing;

		foreach ( $booleans as $key ) {
			$output[ $key ] = ! empty( $input[ $key ] );
		}

		if ( isset( $input['scan_frequency'] ) && in_array( $input['scan_frequency'], array( 'daily', 'weekly', 'monthly' ), true ) ) {
			$output['scan_frequency'] = $input['scan_frequency'];
		}

		if ( isset( $input['notification_email'] ) && is_email( $input['notification_email'] ) ) {
			$output['notification_email'] = sanitize_email( $input['notification_email'] );
		}

		if ( isset( $input['login_max_attempts'] ) ) {
			$output['login_max_attempts'] = max( 1, min( 50, (int) $input['login_max_attempts'] ) );
		}

		if ( isset( $input['login_lockout_minutes'] ) ) {
			$output['login_lockout_minutes'] = max( 1, min( 1440, (int) $input['login_lockout_minutes'] ) );
		}

		if ( isset( $input['log_retention_days'] ) ) {
			$output['log_retention_days'] = max( 7, min( 730, (int) $input['log_retention_days'] ) );
		}

		foreach ( array( 'login_whitelist', 'login_blacklist' ) as $list_key ) {
			if ( isset( $input[ $list_key ] ) ) {
				$output[ $list_key ] = $this->sanitize_ip_list( $input[ $list_key ] );
			}
		}

		add_settings_error( 'kloud101_sentinel_settings', 'settings_saved', __( 'Settings saved.', 'kloud101-sentinel' ), 'success' );

		return $output;
	}

	/**
	 * Parse a textarea of one-IP-per-line into a clean array, dropping
	 * anything that doesn't validate as an IP address.
	 *
	 * @param string|array $raw Raw textarea value.
	 * @return string[]
	 */
	private function sanitize_ip_list( $raw ) {
		$lines = is_array( $raw ) ? $raw : preg_split( '/[\r\n,]+/', (string) $raw );
		$clean = array();

		foreach ( $lines as $line ) {
			$line = trim( $line );

			if ( '' !== $line && filter_var( $line, FILTER_VALIDATE_IP ) ) {
				$clean[] = $line;
			}
		}

		return array_values( array_unique( $clean ) );
	}

	/**
	 * Apply filesystem-level hardening the instant its toggle switches
	 * from off to on (e.g. writing the uploads .htaccess block the
	 * moment "Block PHP execution in uploads" is checked and saved),
	 * so the administrator doesn't have to separately click an "Apply"
	 * button after saving the checkbox.
	 *
	 * @param array $old_value Previous settings.
	 * @param array $new_value New settings.
	 */
	public function apply_hardening_side_effects( $old_value, $new_value ) {
		/** @var \Kloud101Sentinel\Includes\Hardening $hardening */
		$hardening = $this->modules['hardening'];

		$transitions = array(
			'hardening_block_php_uploads'    => 'apply_block_php_in_uploads',
			'hardening_disable_dir_browsing' => 'apply_disable_directory_browsing',
		);

		foreach ( $transitions as $setting_key => $method ) {
			$was_on = ! empty( $old_value[ $setting_key ] );
			$is_on  = ! empty( $new_value[ $setting_key ] );

			if ( $is_on && ! $was_on ) {
				$hardening->{$method}();
			}
		}
	}

	/**
	 * Handle the standalone hardening action buttons (Rotate Salts,
	 * Reset Permissions, Protect wp-config.php, Protect .htaccess) that
	 * are one-shot operations rather than persistent toggles.
	 */
	public function handle_hardening_actions() {
		if ( empty( $_POST['kloud101_sentinel_hardening_action'] ) || ! current_user_can( 'manage_kloud101_sentinel' ) ) {
			return;
		}

		check_admin_referer( 'kloud101_sentinel_hardening_action' );

		$action    = sanitize_key( wp_unslash( $_POST['kloud101_sentinel_hardening_action'] ) );
		/** @var \Kloud101Sentinel\Includes\Hardening $hardening */
		$hardening = $this->modules['hardening'];
		$message   = '';
		$type      = 'success';

		switch ( $action ) {
			case 'rotate_salts':
				$result  = $hardening->rotate_salts();
				$message = is_wp_error( $result ) ? $result->get_error_message() : __( 'Authentication keys/salts rotated successfully.', 'kloud101-sentinel' );
				$type    = is_wp_error( $result ) ? 'error' : 'success';
				break;

			case 'reset_permissions':
				$result  = $hardening->reset_permissions();
				$message = sprintf( __( 'Updated permissions on %d path(s).', 'kloud101-sentinel' ), $result['files_updated'] );
				break;

			case 'protect_wp_config':
				$hardening->apply_protect_wp_config();
				$message = __( 'wp-config.php protection rules applied.', 'kloud101-sentinel' );
				break;

			case 'protect_htaccess':
				$hardening->apply_protect_htaccess();
				$message = __( '.htaccess permissions locked down.', 'kloud101-sentinel' );
				break;

			case 'check_db_prefix':
				$found   = $hardening->check_database_prefix();
				$message = $found ? __( 'Default "wp_" prefix detected — see the finding on the Dashboard.', 'kloud101-sentinel' ) : __( 'Database is not using the default prefix. Good.', 'kloud101-sentinel' );
				break;
		}

		if ( $message ) {
			add_settings_error( 'kloud101_sentinel_settings', 'hardening_action', $message, $type );
			set_transient( 'settings_errors', get_settings_errors(), 30 );
			wp_safe_redirect( add_query_arg( array( 'page' => 'kloud101-sentinel-settings', 'tab' => 'hardening', 'settings-updated' => 'true' ), admin_url( 'admin.php' ) ) );
			exit;
		}
	}

	/**
	 * Render the tabbed settings page.
	 */
	public function render_page() {
		if ( ! current_user_can( 'manage_kloud101_sentinel' ) ) {
			wp_die( esc_html__( 'You do not have permission to access this page.', 'kloud101-sentinel' ) );
		}

		$settings = wp_parse_args( get_option( 'kloud101_sentinel_settings', array() ), Installer::default_settings() );
		$tabs     = array(
			'general'   => __( 'General', 'kloud101-sentinel' ),
			'scanning'  => __( 'Scanning', 'kloud101-sentinel' ),
			'login'     => __( 'Login Protection', 'kloud101-sentinel' ),
			'firewall'  => __( 'Firewall', 'kloud101-sentinel' ),
			'hardening' => __( 'Hardening', 'kloud101-sentinel' ),
			'notify'    => __( 'Notifications', 'kloud101-sentinel' ),
		);
		$active_tab = isset( $_GET['tab'] ) && isset( $tabs[ sanitize_key( wp_unslash( $_GET['tab'] ) ) ] ) // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			? sanitize_key( wp_unslash( $_GET['tab'] ) ) // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			: 'general';
		?>
		<div class="wrap k101-wrap">
			<h1><?php esc_html_e( 'Kloud101 Sentinel Settings', 'kloud101-sentinel' ); ?></h1>

			<?php settings_errors( 'kloud101_sentinel_settings' ); ?>

			<h2 class="nav-tab-wrapper">
				<?php foreach ( $tabs as $slug => $label ) : ?>
					<a href="<?php echo esc_url( add_query_arg( array( 'page' => 'kloud101-sentinel-settings', 'tab' => $slug ), admin_url( 'admin.php' ) ) ); ?>" class="nav-tab <?php echo $active_tab === $slug ? 'nav-tab-active' : ''; ?>">
						<?php echo esc_html( $label ); ?>
					</a>
				<?php endforeach; ?>
			</h2>

			<form method="post" action="options.php">
				<?php settings_fields( 'kloud101_sentinel_settings_group' ); ?>

				<?php if ( 'general' === $active_tab ) : ?>
					<table class="form-table" role="presentation">
						<tr>
							<th><?php esc_html_e( 'Remove data on uninstall', 'kloud101-sentinel' ); ?></th>
							<td>
								<label>
									<input type="checkbox" name="kloud101_sentinel_settings[remove_data_on_uninstall]" value="1" <?php checked( $settings['remove_data_on_uninstall'] ); ?> />
									<?php esc_html_e( 'Delete all tables, settings, and quarantined files when the plugin is uninstalled.', 'kloud101-sentinel' ); ?>
								</label>
							</td>
						</tr>
					</table>
				<?php elseif ( 'scanning' === $active_tab ) : ?>
					<table class="form-table" role="presentation">
						<tr>
							<th><label for="scan_frequency"><?php esc_html_e( 'Scheduled scan frequency', 'kloud101-sentinel' ); ?></label></th>
							<td>
								<select name="kloud101_sentinel_settings[scan_frequency]" id="scan_frequency">
									<option value="daily" <?php selected( $settings['scan_frequency'], 'daily' ); ?>><?php esc_html_e( 'Daily', 'kloud101-sentinel' ); ?></option>
									<option value="weekly" <?php selected( $settings['scan_frequency'], 'weekly' ); ?>><?php esc_html_e( 'Weekly', 'kloud101-sentinel' ); ?></option>
									<option value="monthly" <?php selected( $settings['scan_frequency'], 'monthly' ); ?>><?php esc_html_e( 'Monthly', 'kloud101-sentinel' ); ?></option>
								</select>
							</td>
						</tr>
						<tr>
							<th><?php esc_html_e( 'Log retention (days)', 'kloud101-sentinel' ); ?></th>
							<td><input type="number" min="7" max="730" name="kloud101_sentinel_settings[log_retention_days]" value="<?php echo esc_attr( $settings['log_retention_days'] ); ?>" class="small-text" /></td>
						</tr>
						<tr>
							<th><?php esc_html_e( 'WordPress.org lookups', 'kloud101-sentinel' ); ?></th>
							<td>
								<label>
									<input type="checkbox" name="kloud101_sentinel_settings[enable_wordpress_org_lookups]" value="1" <?php checked( $settings['enable_wordpress_org_lookups'] ); ?> />
									<?php esc_html_e( 'Allow optional outbound requests to the official WordPress.org API during scans.', 'kloud101-sentinel' ); ?>
								</label>
								<p class="description">
									<?php esc_html_e( 'When enabled, Integrity Checks send your WordPress version and locale to api.wordpress.org to cross-check core file checksums, and Full Scans send each installed plugin\'s slug to check whether it has been abandoned. No personal data, content, or credentials are ever sent. Everything else in this plugin (malware signatures, file integrity hashing, the firewall) runs fully offline regardless of this setting.', 'kloud101-sentinel' ); ?>
								</p>
							</td>
						</tr>
					</table>
				<?php elseif ( 'login' === $active_tab ) : ?>
					<table class="form-table" role="presentation">
						<tr>
							<th><?php esc_html_e( 'Max failed attempts', 'kloud101-sentinel' ); ?></th>
							<td><input type="number" min="1" max="50" name="kloud101_sentinel_settings[login_max_attempts]" value="<?php echo esc_attr( $settings['login_max_attempts'] ); ?>" class="small-text" /></td>
						</tr>
						<tr>
							<th><?php esc_html_e( 'Lockout duration (minutes)', 'kloud101-sentinel' ); ?></th>
							<td><input type="number" min="1" max="1440" name="kloud101_sentinel_settings[login_lockout_minutes]" value="<?php echo esc_attr( $settings['login_lockout_minutes'] ); ?>" class="small-text" /></td>
						</tr>
						<tr>
							<th><label for="login_whitelist"><?php esc_html_e( 'IP whitelist', 'kloud101-sentinel' ); ?></label></th>
							<td><textarea id="login_whitelist" name="kloud101_sentinel_settings[login_whitelist]" rows="4" class="large-text code"><?php echo esc_textarea( implode( "\n", $settings['login_whitelist'] ) ); ?></textarea><p class="description"><?php esc_html_e( 'One IP address per line. Bypasses lockouts and the firewall.', 'kloud101-sentinel' ); ?></p></td>
						</tr>
						<tr>
							<th><label for="login_blacklist"><?php esc_html_e( 'IP blacklist', 'kloud101-sentinel' ); ?></label></th>
							<td><textarea id="login_blacklist" name="kloud101_sentinel_settings[login_blacklist]" rows="4" class="large-text code"><?php echo esc_textarea( implode( "\n", $settings['login_blacklist'] ) ); ?></textarea><p class="description"><?php esc_html_e( 'One IP address per line. Permanently blocked from logging in.', 'kloud101-sentinel' ); ?></p></td>
						</tr>
					</table>
				<?php elseif ( 'firewall' === $active_tab ) : ?>
					<table class="form-table" role="presentation">
						<tr><th><?php esc_html_e( 'Enable firewall', 'kloud101-sentinel' ); ?></th><td><label><input type="checkbox" name="kloud101_sentinel_settings[firewall_enabled]" value="1" <?php checked( $settings['firewall_enabled'] ); ?> /> <?php esc_html_e( 'Turn on request inspection.', 'kloud101-sentinel' ); ?></label></td></tr>
						<tr><th><?php esc_html_e( 'Block SQL injection', 'kloud101-sentinel' ); ?></th><td><label><input type="checkbox" name="kloud101_sentinel_settings[firewall_block_sqli]" value="1" <?php checked( $settings['firewall_block_sqli'] ); ?> /></label></td></tr>
						<tr><th><?php esc_html_e( 'Block XSS attempts', 'kloud101-sentinel' ); ?></th><td><label><input type="checkbox" name="kloud101_sentinel_settings[firewall_block_xss]" value="1" <?php checked( $settings['firewall_block_xss'] ); ?> /></label></td></tr>
						<tr><th><?php esc_html_e( 'Block directory traversal', 'kloud101-sentinel' ); ?></th><td><label><input type="checkbox" name="kloud101_sentinel_settings[firewall_block_traversal]" value="1" <?php checked( $settings['firewall_block_traversal'] ); ?> /></label></td></tr>
						<tr><th><?php esc_html_e( 'Block known bad bots', 'kloud101-sentinel' ); ?></th><td><label><input type="checkbox" name="kloud101_sentinel_settings[firewall_block_bad_bots]" value="1" <?php checked( $settings['firewall_block_bad_bots'] ); ?> /></label></td></tr>
					</table>
				<?php elseif ( 'hardening' === $active_tab ) : ?>
					<table class="form-table" role="presentation">
						<tr><th><?php esc_html_e( 'Disable XML-RPC', 'kloud101-sentinel' ); ?></th><td><label><input type="checkbox" name="kloud101_sentinel_settings[hardening_disable_xmlrpc]" value="1" <?php checked( $settings['hardening_disable_xmlrpc'] ); ?> /></label></td></tr>
						<tr><th><?php esc_html_e( 'Disable file editing', 'kloud101-sentinel' ); ?></th><td><label><input type="checkbox" name="kloud101_sentinel_settings[hardening_disable_file_edit]" value="1" <?php checked( $settings['hardening_disable_file_edit'] ); ?> /></label></td></tr>
						<tr><th><?php esc_html_e( 'Block PHP execution in uploads', 'kloud101-sentinel' ); ?></th><td><label><input type="checkbox" name="kloud101_sentinel_settings[hardening_block_php_uploads]" value="1" <?php checked( $settings['hardening_block_php_uploads'] ); ?> /></label></td></tr>
						<tr><th><?php esc_html_e( 'Hide WordPress version', 'kloud101-sentinel' ); ?></th><td><label><input type="checkbox" name="kloud101_sentinel_settings[hardening_hide_wp_version]" value="1" <?php checked( $settings['hardening_hide_wp_version'] ); ?> /></label></td></tr>
						<tr><th><?php esc_html_e( 'Disable directory browsing', 'kloud101-sentinel' ); ?></th><td><label><input type="checkbox" name="kloud101_sentinel_settings[hardening_disable_dir_browsing]" value="1" <?php checked( $settings['hardening_disable_dir_browsing'] ); ?> /></label></td></tr>
						<tr><th><?php esc_html_e( 'Restrict REST API to logged-in users', 'kloud101-sentinel' ); ?></th><td><label><input type="checkbox" name="kloud101_sentinel_settings[hardening_restrict_rest_api]" value="1" <?php checked( $settings['hardening_restrict_rest_api'] ); ?> /></label></td></tr>
					</table>
				<?php elseif ( 'notify' === $active_tab ) : ?>
					<table class="form-table" role="presentation">
						<tr><th><?php esc_html_e( 'Email notifications', 'kloud101-sentinel' ); ?></th><td><label><input type="checkbox" name="kloud101_sentinel_settings[email_notifications]" value="1" <?php checked( $settings['email_notifications'] ); ?> /> <?php esc_html_e( 'Send email alerts for critical events.', 'kloud101-sentinel' ); ?></label></td></tr>
						<tr><th><label for="notification_email"><?php esc_html_e( 'Notification email', 'kloud101-sentinel' ); ?></label></th><td><input type="email" id="notification_email" name="kloud101_sentinel_settings[notification_email]" value="<?php echo esc_attr( $settings['notification_email'] ); ?>" class="regular-text" /></td></tr>
					</table>
				<?php endif; ?>

				<?php submit_button( __( 'Save Settings', 'kloud101-sentinel' ) ); ?>
			</form>

			<?php if ( 'hardening' === $active_tab ) : ?>
				<h2><?php esc_html_e( 'One-Click Actions', 'kloud101-sentinel' ); ?></h2>
				<p class="description"><?php esc_html_e( 'These run immediately and are independent of the checkboxes above.', 'kloud101-sentinel' ); ?></p>
				<?php
				foreach ( array(
					'protect_wp_config' => __( 'Protect wp-config.php', 'kloud101-sentinel' ),
					'protect_htaccess'  => __( 'Protect .htaccess', 'kloud101-sentinel' ),
					'check_db_prefix'   => __( 'Check Database Prefix', 'kloud101-sentinel' ),
					'rotate_salts'      => __( 'Rotate Salts', 'kloud101-sentinel' ),
					'reset_permissions' => __( 'Reset Permissions', 'kloud101-sentinel' ),
				) as $action_key => $label ) :
					?>
					<form method="post" style="display:inline-block;margin:0 8px 8px 0;">
						<?php wp_nonce_field( 'kloud101_sentinel_hardening_action' ); ?>
						<input type="hidden" name="kloud101_sentinel_hardening_action" value="<?php echo esc_attr( $action_key ); ?>" />
						<button type="submit" class="button"><?php echo esc_html( $label ); ?></button>
					</form>
				<?php endforeach; ?>
			<?php endif; ?>
		</div>
		<?php
	}
}
