<?php
/**
 * Logs screen: browse, filter, and download the plugin's structured
 * log entries.
 *
 * @package Kloud101Sentinel\Admin
 */

namespace Kloud101Sentinel\Admin;

use Kloud101Sentinel\Includes\Loader;
use Kloud101Sentinel\Includes\Logger;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class LogsPage
 */
class LogsPage {

	/**
	 * @var array<string, object>
	 */
	private $modules;

	/**
	 * Constructor.
	 *
	 * @param array<string, object> $modules Live module instances.
	 */
	public function __construct( array $modules ) {
		$this->modules = $modules;
	}

	/**
	 * Register hooks.
	 *
	 * @param Loader $loader Shared hook loader.
	 */
	public function register( Loader $loader ) {
		$loader->add_action( 'admin_menu', $this, 'register_menu' );
		$loader->add_action( 'admin_post_kloud101_sentinel_download_logs', $this, 'handle_download' );
	}

	/**
	 * Register the Logs submenu page.
	 */
	public function register_menu() {
		add_submenu_page(
			'kloud101-sentinel',
			__( 'Logs', 'kloud101-sentinel' ),
			__( 'Logs', 'kloud101-sentinel' ),
			'manage_kloud101_sentinel',
			'kloud101-sentinel-logs',
			array( $this, 'render_page' )
		);
	}

	/**
	 * Render the logs list with level/source filters.
	 */
	public function render_page() {
		if ( ! current_user_can( 'manage_kloud101_sentinel' ) ) {
			wp_die( esc_html__( 'You do not have permission to access this page.', 'kloud101-sentinel' ) );
		}

		$level  = isset( $_GET['level'] ) ? sanitize_key( wp_unslash( $_GET['level'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$source = isset( $_GET['source'] ) ? sanitize_key( wp_unslash( $_GET['source'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$paged  = isset( $_GET['paged'] ) ? max( 1, (int) $_GET['paged'] ) : 1; // phpcs:ignore WordPress.Security.NonceVerification.Recommended

		/** @var Logger $logger */
		$logger = $this->modules['logger'];
		$data   = $logger->get_logs( array( 'level' => $level, 'source' => $source, 'paged' => $paged, 'per_page' => 50 ) );
		?>
		<div class="wrap k101-wrap">
			<h1><?php esc_html_e( 'Logs', 'kloud101-sentinel' ); ?></h1>

			<form method="get" class="k101-log-filters">
				<input type="hidden" name="page" value="kloud101-sentinel-logs" />
				<select name="level">
					<option value=""><?php esc_html_e( 'All levels', 'kloud101-sentinel' ); ?></option>
					<?php foreach ( array( Logger::LEVEL_ERROR, Logger::LEVEL_WARNING, Logger::LEVEL_INFO, Logger::LEVEL_ACTION ) as $level_option ) : ?>
						<option value="<?php echo esc_attr( $level_option ); ?>" <?php selected( $level, $level_option ); ?>><?php echo esc_html( ucfirst( $level_option ) ); ?></option>
					<?php endforeach; ?>
				</select>
				<input type="text" name="source" value="<?php echo esc_attr( $source ); ?>" placeholder="<?php esc_attr_e( 'Source (e.g. malware_scanner)', 'kloud101-sentinel' ); ?>" />
				<button type="submit" class="button"><?php esc_html_e( 'Filter', 'kloud101-sentinel' ); ?></button>
				<a class="button" href="<?php echo esc_url( admin_url( 'admin.php?page=kloud101-sentinel-logs' ) ); ?>"><?php esc_html_e( 'Reset', 'kloud101-sentinel' ); ?></a>
				<a class="button button-secondary" href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=kloud101_sentinel_download_logs' ), 'kloud101_sentinel_download_logs' ) ); ?>"><?php esc_html_e( 'Download CSV', 'kloud101-sentinel' ); ?></a>
			</form>

			<table class="widefat striped">
				<thead>
					<tr>
						<th><?php esc_html_e( 'Level', 'kloud101-sentinel' ); ?></th>
						<th><?php esc_html_e( 'Source', 'kloud101-sentinel' ); ?></th>
						<th><?php esc_html_e( 'Message', 'kloud101-sentinel' ); ?></th>
						<th><?php esc_html_e( 'Date', 'kloud101-sentinel' ); ?></th>
					</tr>
				</thead>
				<tbody>
					<?php if ( empty( $data['rows'] ) ) : ?>
						<tr><td colspan="4"><?php esc_html_e( 'No log entries match this filter.', 'kloud101-sentinel' ); ?></td></tr>
					<?php else : ?>
						<?php foreach ( $data['rows'] as $row ) : ?>
							<tr>
								<td><span class="k101-badge k101-badge-log-<?php echo esc_attr( $row->level ); ?>"><?php echo esc_html( ucfirst( $row->level ) ); ?></span></td>
								<td><code><?php echo esc_html( $row->source ); ?></code></td>
								<td><?php echo esc_html( $row->message ); ?></td>
								<td><?php echo esc_html( $row->created_at ); ?></td>
							</tr>
						<?php endforeach; ?>
					<?php endif; ?>
				</tbody>
			</table>

			<?php $this->render_pagination( $paged, (int) ceil( $data['total'] / 50 ) ); ?>
		</div>
		<?php
	}

	/**
	 * Stream a CSV download of every log entry.
	 */
	public function handle_download() {
		if ( ! current_user_can( 'manage_kloud101_sentinel' ) ) {
			wp_die( esc_html__( 'You do not have permission to perform this action.', 'kloud101-sentinel' ) );
		}

		check_admin_referer( 'kloud101_sentinel_download_logs' );

		/** @var Logger $logger */
		$logger = $this->modules['logger'];

		nocache_headers();
		header( 'Content-Type: text/csv; charset=utf-8' );
		header( 'Content-Disposition: attachment; filename="kloud101-sentinel-logs.csv"' );
		$logger->export_csv();
		exit;
	}

	/**
	 * Render simple prev/next pagination links.
	 *
	 * @param int $current     Current page.
	 * @param int $total_pages Total number of pages.
	 */
	private function render_pagination( $current, $total_pages ) {
		if ( $total_pages <= 1 ) {
			return;
		}
		?>
		<p class="k101-pagination">
			<?php if ( $current > 1 ) : ?>
				<a class="button" href="<?php echo esc_url( add_query_arg( 'paged', $current - 1 ) ); ?>">&laquo; <?php esc_html_e( 'Previous', 'kloud101-sentinel' ); ?></a>
			<?php endif; ?>
			<?php
			printf(
				/* translators: 1: current page, 2: total pages */
				esc_html__( 'Page %1$d of %2$d', 'kloud101-sentinel' ),
				(int) $current,
				(int) $total_pages
			);
			?>
			<?php if ( $current < $total_pages ) : ?>
				<a class="button" href="<?php echo esc_url( add_query_arg( 'paged', $current + 1 ) ); ?>"><?php esc_html_e( 'Next', 'kloud101-sentinel' ); ?> &raquo;</a>
			<?php endif; ?>
		</p>
		<?php
	}
}
