<?php
/**
 * Main plugin dashboard screen.
 *
 * @package Kloud101Sentinel\Admin
 */

namespace Kloud101Sentinel\Admin;

use Kloud101Sentinel\Includes\Findings;
use Kloud101Sentinel\Includes\Loader;
use Kloud101Sentinel\Includes\Utilities;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Dashboard
 *
 * Registers the plugin's top-level admin menu (every other admin page
 * class attaches to it as a submenu) and renders the security overview
 * screen: status cards plus the quick-action buttons that kick off a
 * scan via Scanner's AJAX endpoints.
 *
 * Also owns the single admin_enqueue_scripts hook shared by every
 * Kloud101 Sentinel screen, since the CSS/JS bundle and its localized
 * nonce/strings are identical regardless of which submenu is open.
 */
class Dashboard {

	/**
	 * Live module instances, keyed the same way as the main plugin's
	 * registry (see Kloud101Sentinel_Plugin::load_modules()).
	 *
	 * @var array<string, object>
	 */
	private $modules;

	/**
	 * Constructor.
	 *
	 * @param array<string, object> $modules Live module instances.
	 */
	public function __construct( array $modules ) {
		$this->modules = $modules;
	}

	/**
	 * Register hooks.
	 *
	 * @param Loader $loader Shared hook loader.
	 */
	public function register( Loader $loader ) {
		$loader->add_action( 'admin_menu', $this, 'register_menu' );
		$loader->add_action( 'admin_enqueue_scripts', $this, 'enqueue_assets' );
	}

	/**
	 * Register the top-level "Kloud101 Sentinel" admin menu.
	 */
	public function register_menu() {
		add_menu_page(
			__( 'Kloud101 Sentinel', 'kloud101-sentinel' ),
			__( 'Sentinel', 'kloud101-sentinel' ),
			'manage_kloud101_sentinel',
			'kloud101-sentinel',
			array( $this, 'render_page' ),
			'dashicons-shield',
			80
		);

		add_submenu_page(
			'kloud101-sentinel',
			__( 'Dashboard', 'kloud101-sentinel' ),
			__( 'Dashboard', 'kloud101-sentinel' ),
			'manage_kloud101_sentinel',
			'kloud101-sentinel',
			array( $this, 'render_page' )
		);
	}

	/**
	 * Enqueue shared admin CSS/JS on every Kloud101 Sentinel screen
	 * only — never on the rest of wp-admin, per the "never slow down
	 * the frontend/admin" performance requirement.
	 *
	 * @param string $hook Current admin page hook suffix.
	 */
	public function enqueue_assets( $hook ) {
		if ( false === strpos( (string) $hook, 'kloud101-sentinel' ) ) {
			return;
		}

		wp_enqueue_style( 'kloud101-sentinel-admin', KLOUD101_SENTINEL_URL . 'assets/css/admin.css', array(), KLOUD101_SENTINEL_VERSION );
		wp_enqueue_script( 'kloud101-sentinel-admin', KLOUD101_SENTINEL_URL . 'assets/js/admin.js', array( 'jquery' ), KLOUD101_SENTINEL_VERSION, true );

		wp_localize_script(
			'kloud101-sentinel-admin',
			'kloud101Sentinel',
			array(
				'ajaxUrl' => admin_url( 'admin-ajax.php' ),
				'nonce'   => wp_create_nonce( 'kloud101_sentinel_admin' ),
				'i18n'    => array(
					'scanning'      => __( 'Scanning…', 'kloud101-sentinel' ),
					'scanComplete'  => __( 'Scan complete.', 'kloud101-sentinel' ),
					'scanFailed'    => __( 'Scan failed. Check the Logs page for details.', 'kloud101-sentinel' ),
					'confirmDelete' => __( 'Permanently delete this file? This cannot be undone.', 'kloud101-sentinel' ),
					'confirmRestore' => __( 'Restore this file to its original location?', 'kloud101-sentinel' ),
				),
			)
		);
	}

	/**
	 * Render the dashboard screen.
	 */
	public function render_page() {
		if ( ! current_user_can( 'manage_kloud101_sentinel' ) ) {
			wp_die( esc_html__( 'You do not have permission to access this page.', 'kloud101-sentinel' ) );
		}

		/** @var Findings $findings */
		$findings   = $this->modules['findings'];
		$quarantine = $this->modules['quarantine'];

		$score           = $findings->calculate_security_score();
		$severity_counts = $findings->counts_by_severity();
		$active_threats  = $findings->count_open();
		$quarantined     = $quarantine->count_active();

		$last_report = $this->get_last_report();
		$login_stats = $this->get_login_stats();
		$plugins     = $this->modules['plugin_scanner']->get_inventory();

		$health = $score >= 90 ? __( 'Excellent', 'kloud101-sentinel' ) : ( $score >= 70 ? __( 'Good', 'kloud101-sentinel' ) : ( $score >= 40 ? __( 'At Risk', 'kloud101-sentinel' ) : __( 'Critical', 'kloud101-sentinel' ) ) );

		global $wpdb;

		$cards = array(
			array( 'label' => __( 'Overall Security Score', 'kloud101-sentinel' ), 'value' => $score . '/100' ),
			array( 'label' => __( 'Website Health', 'kloud101-sentinel' ), 'value' => $health ),
			array( 'label' => __( 'Active Threats', 'kloud101-sentinel' ), 'value' => $active_threats ),
			array( 'label' => __( 'Critical Issues', 'kloud101-sentinel' ), 'value' => $severity_counts[ Findings::SEVERITY_CRITICAL ] ),
			array( 'label' => __( 'Last Scan', 'kloud101-sentinel' ), 'value' => $last_report ? human_time_diff( strtotime( $last_report->started_at . ' UTC' ) ) . ' ' . __( 'ago', 'kloud101-sentinel' ) : __( 'Never', 'kloud101-sentinel' ) ),
			array( 'label' => __( 'Total Files Scanned', 'kloud101-sentinel' ), 'value' => $last_report && is_array( $last_report->summary ) ? number_format_i18n( $last_report->summary['total_tasks'] ?? 0 ) : '—' ),
			array( 'label' => __( 'Files Modified', 'kloud101-sentinel' ), 'value' => $this->count_findings_by_signature( 'file_modified' ) ),
			array( 'label' => __( 'Quarantined Files', 'kloud101-sentinel' ), 'value' => $quarantined ),
			array( 'label' => __( 'Failed Logins (24h)', 'kloud101-sentinel' ), 'value' => $login_stats['failed'] ),
			array( 'label' => __( 'Blocked IPs', 'kloud101-sentinel' ), 'value' => $login_stats['blocked'] ),
			array( 'label' => __( 'WordPress Version', 'kloud101-sentinel' ), 'value' => get_bloginfo( 'version' ) ),
			array( 'label' => __( 'PHP Version', 'kloud101-sentinel' ), 'value' => PHP_VERSION ),
			array( 'label' => __( 'Database Version', 'kloud101-sentinel' ), 'value' => $wpdb->db_version() ),
			array( 'label' => __( 'Active Plugins', 'kloud101-sentinel' ), 'value' => $plugins['active'] . ' / ' . $plugins['total'] ),
			array( 'label' => __( 'Active Theme', 'kloud101-sentinel' ), 'value' => wp_get_theme()->get( 'Name' ) ),
			array( 'label' => __( 'Disk Usage (Uploads)', 'kloud101-sentinel' ), 'value' => Utilities::format_bytes( Utilities::get_directory_size( wp_upload_dir()['basedir'] ) ) ),
			array( 'label' => __( 'Memory Usage', 'kloud101-sentinel' ), 'value' => Utilities::get_memory_usage() ),
		);

		?>
		<div class="wrap k101-wrap">
			<h1 class="k101-page-title">
				<span class="dashicons dashicons-shield"></span>
				<?php esc_html_e( 'Kloud101 Sentinel', 'kloud101-sentinel' ); ?>
			</h1>

			<div class="k101-cards-grid">
				<?php foreach ( $cards as $card ) : ?>
					<div class="k101-card">
						<div class="k101-card-label"><?php echo esc_html( $card['label'] ); ?></div>
						<div class="k101-card-value"><?php echo esc_html( $card['value'] ); ?></div>
					</div>
				<?php endforeach; ?>
			</div>

			<h2><?php esc_html_e( 'Quick Actions', 'kloud101-sentinel' ); ?></h2>
			<div class="k101-quick-actions">
				<button type="button" class="button button-primary k101-scan-trigger" data-scan-type="quick"><?php esc_html_e( 'Quick Scan', 'kloud101-sentinel' ); ?></button>
				<button type="button" class="button button-primary k101-scan-trigger" data-scan-type="full"><?php esc_html_e( 'Full Scan', 'kloud101-sentinel' ); ?></button>
				<button type="button" class="button k101-scan-trigger" data-scan-type="uploads"><?php esc_html_e( 'Scan Uploads', 'kloud101-sentinel' ); ?></button>
				<button type="button" class="button k101-scan-trigger" data-scan-type="integrity"><?php esc_html_e( 'Run Integrity Check', 'kloud101-sentinel' ); ?></button>
				<a class="button" href="<?php echo esc_url( admin_url( 'admin.php?page=kloud101-sentinel-settings&tab=hardening' ) ); ?>"><?php esc_html_e( 'Security Hardening', 'kloud101-sentinel' ); ?></a>
				<a class="button" href="<?php echo esc_url( admin_url( 'admin.php?page=kloud101-sentinel-reports' ) ); ?>"><?php esc_html_e( 'View Reports', 'kloud101-sentinel' ); ?></a>
				<a class="button" href="<?php echo esc_url( admin_url( 'admin.php?page=kloud101-sentinel-logs' ) ); ?>"><?php esc_html_e( 'View Logs', 'kloud101-sentinel' ); ?></a>
				<a class="button" href="<?php echo esc_url( admin_url( 'admin.php?page=kloud101-sentinel-quarantine' ) ); ?>"><?php esc_html_e( 'Quarantine Manager', 'kloud101-sentinel' ); ?></a>
			</div>

			<div id="k101-scan-progress" class="k101-scan-progress" hidden>
				<div class="k101-progress-bar"><div class="k101-progress-fill"></div></div>
				<p class="k101-progress-status"></p>
			</div>

			<h2><?php esc_html_e( 'Recent Findings', 'kloud101-sentinel' ); ?></h2>
			<?php $this->render_recent_findings( $findings ); ?>
		</div>
		<?php
	}

	/**
	 * Render a compact table of the most recent open findings.
	 *
	 * @param Findings $findings Findings repository.
	 */
	private function render_recent_findings( Findings $findings ) {
		$result = $findings->list_findings( array( 'status' => Findings::STATUS_OPEN, 'per_page' => 10 ) );

		if ( empty( $result['rows'] ) ) {
			echo '<p>' . esc_html__( 'No open findings — nice work.', 'kloud101-sentinel' ) . '</p>';
			return;
		}
		?>
		<table class="widefat striped">
			<thead>
				<tr>
					<th><?php esc_html_e( 'Severity', 'kloud101-sentinel' ); ?></th>
					<th><?php esc_html_e( 'Type', 'kloud101-sentinel' ); ?></th>
					<th><?php esc_html_e( 'Location', 'kloud101-sentinel' ); ?></th>
					<th><?php esc_html_e( 'Description', 'kloud101-sentinel' ); ?></th>
					<th><?php esc_html_e( 'Detected', 'kloud101-sentinel' ); ?></th>
				</tr>
			</thead>
			<tbody>
				<?php foreach ( $result['rows'] as $row ) : ?>
					<tr>
						<td><span class="k101-badge k101-badge-<?php echo esc_attr( $row->severity ); ?>"><?php echo esc_html( ucfirst( $row->severity ) ); ?></span></td>
						<td><?php echo esc_html( ucfirst( $row->type ) ); ?></td>
						<td><code><?php echo esc_html( $row->file_path ); ?></code></td>
						<td><?php echo esc_html( $row->description ); ?></td>
						<td><?php echo esc_html( human_time_diff( strtotime( $row->detected_at . ' UTC' ) ) . ' ' . __( 'ago', 'kloud101-sentinel' ) ); ?></td>
					</tr>
				<?php endforeach; ?>
			</tbody>
		</table>
		<?php
	}

	/**
	 * Fetch the most recently completed report row.
	 *
	 * @return object|null
	 */
	private function get_last_report() {
		global $wpdb;

		$row = $wpdb->get_row( "SELECT * FROM {$wpdb->prefix}k101_reports WHERE finished_at IS NOT NULL ORDER BY finished_at DESC LIMIT 1" ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery

		if ( $row && $row->summary ) {
			$row->summary = json_decode( $row->summary, true );
		}

		return $row;
	}

	/**
	 * Count open findings matching a specific signature (used for the
	 * "Files Modified" card).
	 *
	 * @param string $signature Signature identifier.
	 * @return int
	 */
	private function count_findings_by_signature( $signature ) {
		global $wpdb;

		return (int) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(*) FROM {$wpdb->prefix}k101_findings WHERE signature = %s AND status = %s", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				$signature,
				Findings::STATUS_OPEN
			)
		);
	}

	/**
	 * Failed-login and blocked-IP counters for the last 24 hours.
	 *
	 * @return array{failed: int, blocked: int}
	 */
	private function get_login_stats() {
		global $wpdb;

		$since = gmdate( 'Y-m-d H:i:s', time() - DAY_IN_SECONDS );

		$failed = (int) $wpdb->get_var(
			$wpdb->prepare( "SELECT COUNT(*) FROM {$wpdb->prefix}k101_login_attempts WHERE success = 0 AND created_at >= %s", $since ) // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		);

		$blocked = (int) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(*) FROM (SELECT ip_address FROM {$wpdb->prefix}k101_login_attempts WHERE success = 0 AND created_at >= %s GROUP BY ip_address HAVING COUNT(*) >= 5) k101_blocked_ips", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				$since
			)
		);

		return array(
			'failed'  => $failed,
			'blocked' => (int) $blocked,
		);
	}
}
