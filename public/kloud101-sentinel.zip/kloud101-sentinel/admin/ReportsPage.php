<?php
/**
 * Reports screen: browse past scans and export a print-ready HTML or
 * CSV report for each.
 *
 * @package Kloud101Sentinel\Admin
 */

namespace Kloud101Sentinel\Admin;

use Kloud101Sentinel\Includes\Loader;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class ReportsPage
 *
 * Exports are streamed through admin-post.php (not admin-ajax.php)
 * because they need to send file-download headers directly rather
 * than a JSON envelope.
 */
class ReportsPage {

	/**
	 * @var array<string, object>
	 */
	private $modules;

	/**
	 * Constructor.
	 *
	 * @param array<string, object> $modules Live module instances.
	 */
	public function __construct( array $modules ) {
		$this->modules = $modules;
	}

	/**
	 * Register hooks.
	 *
	 * @param Loader $loader Shared hook loader.
	 */
	public function register( Loader $loader ) {
		$loader->add_action( 'admin_menu', $this, 'register_menu' );
		$loader->add_action( 'admin_post_kloud101_sentinel_export_report_csv', $this, 'handle_export_csv' );
		$loader->add_action( 'admin_post_kloud101_sentinel_view_report_html', $this, 'handle_view_html' );
	}

	/**
	 * Register the Reports submenu page.
	 */
	public function register_menu() {
		add_submenu_page(
			'kloud101-sentinel',
			__( 'Reports', 'kloud101-sentinel' ),
			__( 'Reports', 'kloud101-sentinel' ),
			'manage_kloud101_sentinel',
			'kloud101-sentinel-reports',
			array( $this, 'render_page' )
		);
	}

	/**
	 * Render the reports list.
	 */
	public function render_page() {
		if ( ! current_user_can( 'manage_kloud101_sentinel' ) ) {
			wp_die( esc_html__( 'You do not have permission to access this page.', 'kloud101-sentinel' ) );
		}

		$paged  = isset( $_GET['paged'] ) ? max( 1, (int) $_GET['paged'] ) : 1; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		/** @var \Kloud101Sentinel\Includes\Reports $reports_service */
		$reports_service = $this->modules['reports'];
		$data             = $reports_service->list_reports( $paged, 20 );
		?>
		<div class="wrap k101-wrap">
			<h1><?php esc_html_e( 'Scan Reports', 'kloud101-sentinel' ); ?></h1>

			<h2><?php esc_html_e( 'Recommendations', 'kloud101-sentinel' ); ?></h2>
			<ul class="k101-recommendations">
				<?php foreach ( $reports_service->get_recommendations() as $recommendation ) : ?>
					<li><?php echo esc_html( $recommendation ); ?></li>
				<?php endforeach; ?>
			</ul>

			<table class="widefat striped">
				<thead>
					<tr>
						<th><?php esc_html_e( 'ID', 'kloud101-sentinel' ); ?></th>
						<th><?php esc_html_e( 'Type', 'kloud101-sentinel' ); ?></th>
						<th><?php esc_html_e( 'Started', 'kloud101-sentinel' ); ?></th>
						<th><?php esc_html_e( 'Finished', 'kloud101-sentinel' ); ?></th>
						<th><?php esc_html_e( 'Findings', 'kloud101-sentinel' ); ?></th>
						<th><?php esc_html_e( 'Score', 'kloud101-sentinel' ); ?></th>
						<th><?php esc_html_e( 'Export', 'kloud101-sentinel' ); ?></th>
					</tr>
				</thead>
				<tbody>
					<?php if ( empty( $data['rows'] ) ) : ?>
						<tr><td colspan="7"><?php esc_html_e( 'No reports yet — run a scan first.', 'kloud101-sentinel' ); ?></td></tr>
					<?php else : ?>
						<?php foreach ( $data['rows'] as $report ) : ?>
							<?php $summary = $report->summary ? json_decode( $report->summary, true ) : array(); ?>
							<tr>
								<td><?php echo esc_html( $report->id ); ?></td>
								<td><?php echo esc_html( ucfirst( $report->type ) ); ?></td>
								<td><?php echo esc_html( $report->started_at ); ?></td>
								<td><?php echo esc_html( $report->finished_at ? $report->finished_at : __( 'In progress', 'kloud101-sentinel' ) ); ?></td>
								<td><?php echo esc_html( isset( $summary['findings'] ) ? $summary['findings'] : '—' ); ?></td>
								<td><?php echo esc_html( isset( $summary['security_score'] ) ? $summary['security_score'] . '/100' : '—' ); ?></td>
								<td>
									<a class="button button-small" target="_blank" href="<?php echo esc_url( $this->export_url( 'kloud101_sentinel_view_report_html', $report->id ) ); ?>"><?php esc_html_e( 'View HTML', 'kloud101-sentinel' ); ?></a>
									<a class="button button-small" href="<?php echo esc_url( $this->export_url( 'kloud101_sentinel_export_report_csv', $report->id ) ); ?>"><?php esc_html_e( 'CSV', 'kloud101-sentinel' ); ?></a>
								</td>
							</tr>
						<?php endforeach; ?>
					<?php endif; ?>
				</tbody>
			</table>

			<?php $this->render_pagination( $paged, (int) ceil( $data['total'] / 20 ) ); ?>
		</div>
		<?php
	}

	/**
	 * Build a nonce-protected admin-post.php export URL for one report.
	 *
	 * @param string $action    admin-post.php action name.
	 * @param int    $report_id Report ID.
	 * @return string
	 */
	private function export_url( $action, $report_id ) {
		return wp_nonce_url(
			add_query_arg(
				array( 'action' => $action, 'report_id' => $report_id ),
				admin_url( 'admin-post.php' )
			),
			'kloud101_sentinel_export_report_' . $report_id
		);
	}

	/**
	 * Handle the "View HTML" admin-post.php request.
	 */
	public function handle_view_html() {
		$report_id = $this->verify_and_get_report_id();

		/** @var \Kloud101Sentinel\Includes\Reports $reports_service */
		$reports_service = $this->modules['reports'];

		header( 'Content-Type: text/html; charset=utf-8' );
		// Every dynamic value inserted by render_html() is already run
		// through esc_html()/esc_attr() at the point of output (see
		// Reports::render_html()); wp_kses_post() would strip the
		// report's own <style> block since <style> isn't in its allowed
		// tag list, breaking the print-ready layout.
		echo $reports_service->render_html( $report_id ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		exit;
	}

	/**
	 * Handle the CSV export admin-post.php request.
	 */
	public function handle_export_csv() {
		$report_id = $this->verify_and_get_report_id();

		/** @var \Kloud101Sentinel\Includes\Reports $reports_service */
		$reports_service = $this->modules['reports'];

		nocache_headers();
		header( 'Content-Type: text/csv; charset=utf-8' );
		header( 'Content-Disposition: attachment; filename="kloud101-sentinel-report-' . $report_id . '.csv"' );
		$reports_service->export_csv( $report_id );
		exit;
	}

	/**
	 * Shared nonce/capability/report-id verification for both export
	 * handlers.
	 *
	 * @return int Verified report ID.
	 */
	private function verify_and_get_report_id() {
		if ( ! current_user_can( 'manage_kloud101_sentinel' ) ) {
			wp_die( esc_html__( 'You do not have permission to perform this action.', 'kloud101-sentinel' ) );
		}

		$report_id = isset( $_GET['report_id'] ) ? (int) $_GET['report_id'] : 0; // phpcs:ignore WordPress.Security.NonceVerification.Recommended

		check_admin_referer( 'kloud101_sentinel_export_report_' . $report_id );

		return $report_id;
	}

	/**
	 * Render simple prev/next pagination links.
	 *
	 * @param int $current     Current page.
	 * @param int $total_pages Total number of pages.
	 */
	private function render_pagination( $current, $total_pages ) {
		if ( $total_pages <= 1 ) {
			return;
		}
		?>
		<p class="k101-pagination">
			<?php if ( $current > 1 ) : ?>
				<a class="button" href="<?php echo esc_url( add_query_arg( 'paged', $current - 1 ) ); ?>">&laquo; <?php esc_html_e( 'Previous', 'kloud101-sentinel' ); ?></a>
			<?php endif; ?>
			<?php
			printf(
				/* translators: 1: current page, 2: total pages */
				esc_html__( 'Page %1$d of %2$d', 'kloud101-sentinel' ),
				(int) $current,
				(int) $total_pages
			);
			?>
			<?php if ( $current < $total_pages ) : ?>
				<a class="button" href="<?php echo esc_url( add_query_arg( 'paged', $current + 1 ) ); ?>"><?php esc_html_e( 'Next', 'kloud101-sentinel' ); ?> &raquo;</a>
			<?php endif; ?>
		</p>
		<?php
	}
}
