<?php
/**
 * Quarantine manager screen: view, restore, or permanently delete
 * quarantined files.
 *
 * @package Kloud101Sentinel\Admin
 */

namespace Kloud101Sentinel\Admin;

use Kloud101Sentinel\Includes\Loader;
use Kloud101Sentinel\Includes\Quarantine;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class QuarantinePage
 *
 * Every mutating action here (restore/delete) is a full page POST
 * through admin-post.php rather than AJAX — these are rare, high-
 * consequence actions where a full page reload showing a clear
 * success/error admin notice is more appropriate than a silent
 * background request.
 */
class QuarantinePage {

	/**
	 * @var array<string, object>
	 */
	private $modules;

	/**
	 * Constructor.
	 *
	 * @param array<string, object> $modules Live module instances.
	 */
	public function __construct( array $modules ) {
		$this->modules = $modules;
	}

	/**
	 * Register hooks.
	 *
	 * @param Loader $loader Shared hook loader.
	 */
	public function register( Loader $loader ) {
		$loader->add_action( 'admin_menu', $this, 'register_menu' );
		$loader->add_action( 'admin_post_kloud101_sentinel_restore_file', $this, 'handle_restore' );
		$loader->add_action( 'admin_post_kloud101_sentinel_delete_file', $this, 'handle_delete' );
		$loader->add_action( 'admin_notices', $this, 'render_result_notice' );
	}

	/**
	 * Register the Quarantine submenu page.
	 */
	public function register_menu() {
		add_submenu_page(
			'kloud101-sentinel',
			__( 'Quarantine', 'kloud101-sentinel' ),
			__( 'Quarantine', 'kloud101-sentinel' ),
			'manage_kloud101_sentinel',
			'kloud101-sentinel-quarantine',
			array( $this, 'render_page' )
		);
	}

	/**
	 * Render the quarantine list.
	 */
	public function render_page() {
		if ( ! current_user_can( 'manage_kloud101_sentinel' ) ) {
			wp_die( esc_html__( 'You do not have permission to access this page.', 'kloud101-sentinel' ) );
		}

		$paged = isset( $_GET['paged'] ) ? max( 1, (int) $_GET['paged'] ) : 1; // phpcs:ignore WordPress.Security.NonceVerification.Recommended

		/** @var Quarantine $quarantine */
		$quarantine = $this->modules['quarantine'];
		$data       = $quarantine->list_records( array( 'paged' => $paged, 'per_page' => 20 ) );
		?>
		<div class="wrap k101-wrap">
			<h1><?php esc_html_e( 'Quarantine Manager', 'kloud101-sentinel' ); ?></h1>
			<p class="description"><?php esc_html_e( 'Quarantined files are moved to a locked-down folder outside the web root\'s executable path. Nothing is ever deleted automatically — review each item and restore or permanently delete it.', 'kloud101-sentinel' ); ?></p>

			<table class="widefat striped">
				<thead>
					<tr>
						<th><?php esc_html_e( 'Original Path', 'kloud101-sentinel' ); ?></th>
						<th><?php esc_html_e( 'Reason', 'kloud101-sentinel' ); ?></th>
						<th><?php esc_html_e( 'Size', 'kloud101-sentinel' ); ?></th>
						<th><?php esc_html_e( 'Status', 'kloud101-sentinel' ); ?></th>
						<th><?php esc_html_e( 'Quarantined', 'kloud101-sentinel' ); ?></th>
						<th><?php esc_html_e( 'Actions', 'kloud101-sentinel' ); ?></th>
					</tr>
				</thead>
				<tbody>
					<?php if ( empty( $data['rows'] ) ) : ?>
						<tr><td colspan="6"><?php esc_html_e( 'Nothing is currently quarantined.', 'kloud101-sentinel' ); ?></td></tr>
					<?php else : ?>
						<?php foreach ( $data['rows'] as $record ) : ?>
							<tr>
								<td><code><?php echo esc_html( $record->original_path ); ?></code></td>
								<td><?php echo esc_html( $record->reason ); ?></td>
								<td><?php echo esc_html( size_format( (int) $record->file_size ) ); ?></td>
								<td><span class="k101-badge k101-badge-<?php echo esc_attr( $record->status ); ?>"><?php echo esc_html( ucfirst( $record->status ) ); ?></span></td>
								<td><?php echo esc_html( $record->quarantined_at ); ?></td>
								<td>
									<?php if ( Quarantine::STATUS_QUARANTINED === $record->status ) : ?>
										<a class="button button-small" href="<?php echo esc_url( $this->action_url( 'kloud101_sentinel_restore_file', $record->id ) ); ?>"><?php esc_html_e( 'Restore', 'kloud101-sentinel' ); ?></a>
										<a class="button button-small k101-confirm-delete" href="<?php echo esc_url( $this->action_url( 'kloud101_sentinel_delete_file', $record->id ) ); ?>"><?php esc_html_e( 'Delete Permanently', 'kloud101-sentinel' ); ?></a>
									<?php else : ?>
										&mdash;
									<?php endif; ?>
								</td>
							</tr>
						<?php endforeach; ?>
					<?php endif; ?>
				</tbody>
			</table>

			<?php $this->render_pagination( $paged, (int) ceil( $data['total'] / 20 ) ); ?>
		</div>
		<?php
	}

	/**
	 * Build a nonce-protected admin-post.php action URL for one record.
	 *
	 * @param string $action admin-post.php action name.
	 * @param int    $id     Quarantine record ID.
	 * @return string
	 */
	private function action_url( $action, $id ) {
		return wp_nonce_url(
			add_query_arg( array( 'action' => $action, 'id' => $id ), admin_url( 'admin-post.php' ) ),
			'kloud101_sentinel_quarantine_' . $id
		);
	}

	/**
	 * Handle a restore request.
	 */
	public function handle_restore() {
		$id = $this->verify_and_get_id();

		/** @var Quarantine $quarantine */
		$quarantine = $this->modules['quarantine'];
		$result     = $quarantine->restore( $id );

		$this->redirect_with_result( $result, __( 'File restored successfully.', 'kloud101-sentinel' ) );
	}

	/**
	 * Handle a permanent-delete request.
	 */
	public function handle_delete() {
		$id = $this->verify_and_get_id();

		/** @var Quarantine $quarantine */
		$quarantine = $this->modules['quarantine'];
		$result     = $quarantine->delete_permanently( $id );

		$this->redirect_with_result( $result, __( 'File permanently deleted.', 'kloud101-sentinel' ) );
	}

	/**
	 * Shared nonce/capability/id verification.
	 *
	 * @return int Verified quarantine record ID.
	 */
	private function verify_and_get_id() {
		if ( ! current_user_can( 'manage_kloud101_sentinel' ) ) {
			wp_die( esc_html__( 'You do not have permission to perform this action.', 'kloud101-sentinel' ) );
		}

		$id = isset( $_GET['id'] ) ? (int) $_GET['id'] : 0; // phpcs:ignore WordPress.Security.NonceVerification.Recommended

		check_admin_referer( 'kloud101_sentinel_quarantine_' . $id );

		return $id;
	}

	/**
	 * Redirect back to the quarantine list with a transient-backed
	 * success/error notice.
	 *
	 * @param true|\WP_Error $result          Result of the action.
	 * @param string         $success_message Message to show on success.
	 */
	private function redirect_with_result( $result, $success_message ) {
		$notice = is_wp_error( $result )
			? array( 'type' => 'error', 'message' => $result->get_error_message() )
			: array( 'type' => 'success', 'message' => $success_message );

		set_transient( 'kloud101_sentinel_quarantine_notice_' . get_current_user_id(), $notice, 30 );

		wp_safe_redirect( admin_url( 'admin.php?page=kloud101-sentinel-quarantine' ) );
		exit;
	}

	/**
	 * Render the one-time notice left by redirect_with_result().
	 */
	public function render_result_notice() {
		$key    = 'kloud101_sentinel_quarantine_notice_' . get_current_user_id();
		$notice = get_transient( $key );

		if ( ! $notice ) {
			return;
		}

		delete_transient( $key );

		printf(
			'<div class="notice notice-%1$s is-dismissible"><p>%2$s</p></div>',
			esc_attr( 'error' === $notice['type'] ? 'error' : 'success' ),
			esc_html( $notice['message'] )
		);
	}

	/**
	 * Render simple prev/next pagination links.
	 *
	 * @param int $current     Current page.
	 * @param int $total_pages Total number of pages.
	 */
	private function render_pagination( $current, $total_pages ) {
		if ( $total_pages <= 1 ) {
			return;
		}
		?>
		<p class="k101-pagination">
			<?php if ( $current > 1 ) : ?>
				<a class="button" href="<?php echo esc_url( add_query_arg( 'paged', $current - 1 ) ); ?>">&laquo; <?php esc_html_e( 'Previous', 'kloud101-sentinel' ); ?></a>
			<?php endif; ?>
			<?php
			printf(
				/* translators: 1: current page, 2: total pages */
				esc_html__( 'Page %1$d of %2$d', 'kloud101-sentinel' ),
				(int) $current,
				(int) $total_pages
			);
			?>
			<?php if ( $current < $total_pages ) : ?>
				<a class="button" href="<?php echo esc_url( add_query_arg( 'paged', $current + 1 ) ); ?>"><?php esc_html_e( 'Next', 'kloud101-sentinel' ); ?> &raquo;</a>
			<?php endif; ?>
		</p>
		<?php
	}
}
