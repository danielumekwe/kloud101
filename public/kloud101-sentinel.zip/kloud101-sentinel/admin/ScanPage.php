<?php
/**
 * Manual scan screen: larger scan controls plus recent scan history.
 *
 * @package Kloud101Sentinel\Admin
 */

namespace Kloud101Sentinel\Admin;

use Kloud101Sentinel\Includes\Loader;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class ScanPage
 *
 * Reuses the exact same `.k101-scan-trigger` / `#k101-scan-progress`
 * markup contract as the Dashboard's quick actions (see admin.js),
 * so both screens are driven by one shared script rather than two
 * near-duplicate implementations.
 */
class ScanPage {

	/**
	 * @var array<string, object>
	 */
	private $modules;

	/**
	 * Constructor.
	 *
	 * @param array<string, object> $modules Live module instances.
	 */
	public function __construct( array $modules ) {
		$this->modules = $modules;
	}

	/**
	 * Register hooks.
	 *
	 * @param Loader $loader Shared hook loader.
	 */
	public function register( Loader $loader ) {
		$loader->add_action( 'admin_menu', $this, 'register_menu' );
	}

	/**
	 * Register the Scan submenu page.
	 */
	public function register_menu() {
		add_submenu_page(
			'kloud101-sentinel',
			__( 'Run Scan', 'kloud101-sentinel' ),
			__( 'Run Scan', 'kloud101-sentinel' ),
			'manage_kloud101_sentinel',
			'kloud101-sentinel-scan',
			array( $this, 'render_page' )
		);
	}

	/**
	 * Render the scan screen.
	 */
	public function render_page() {
		if ( ! current_user_can( 'manage_kloud101_sentinel' ) ) {
			wp_die( esc_html__( 'You do not have permission to access this page.', 'kloud101-sentinel' ) );
		}

		$scan_types = array(
			'quick'     => array(
				'label'       => __( 'Quick Scan', 'kloud101-sentinel' ),
				'description' => __( 'Malware signature scan of active plugins and the active theme. Fastest option, ideal for a daily check.', 'kloud101-sentinel' ),
			),
			'full'      => array(
				'label'       => __( 'Full Scan', 'kloud101-sentinel' ),
				'description' => __( 'Complete scan: core/plugin/theme malware signatures, file integrity, uploads, cron table, database, and user reconciliation.', 'kloud101-sentinel' ),
			),
			'uploads'   => array(
				'label'       => __( 'Scan Uploads', 'kloud101-sentinel' ),
				'description' => __( 'Checks wp-content/uploads for executable files, disguised extensions, and image/PHP polyglots. Dangerous files are quarantined automatically.', 'kloud101-sentinel' ),
			),
			'integrity' => array(
				'label'       => __( 'Run Integrity Check', 'kloud101-sentinel' ),
				'description' => __( 'Compares WordPress core, plugin, and theme files against their last known-good hashes.', 'kloud101-sentinel' ),
			),
		);

		$recent = $this->get_recent_reports();
		?>
		<div class="wrap k101-wrap">
			<h1><?php esc_html_e( 'Run a Scan', 'kloud101-sentinel' ); ?></h1>

			<div class="k101-scan-options">
				<?php foreach ( $scan_types as $type => $info ) : ?>
					<div class="k101-scan-option">
						<h3><?php echo esc_html( $info['label'] ); ?></h3>
						<p><?php echo esc_html( $info['description'] ); ?></p>
						<button type="button" class="button button-primary k101-scan-trigger" data-scan-type="<?php echo esc_attr( $type ); ?>">
							<?php echo esc_html( $info['label'] ); ?>
						</button>
					</div>
				<?php endforeach; ?>
			</div>

			<div id="k101-scan-progress" class="k101-scan-progress" hidden>
				<div class="k101-progress-bar"><div class="k101-progress-fill"></div></div>
				<p class="k101-progress-status"></p>
			</div>

			<h2><?php esc_html_e( 'Recent Scans', 'kloud101-sentinel' ); ?></h2>
			<table class="widefat striped">
				<thead>
					<tr>
						<th><?php esc_html_e( 'Type', 'kloud101-sentinel' ); ?></th>
						<th><?php esc_html_e( 'Started', 'kloud101-sentinel' ); ?></th>
						<th><?php esc_html_e( 'Duration', 'kloud101-sentinel' ); ?></th>
						<th><?php esc_html_e( 'Findings', 'kloud101-sentinel' ); ?></th>
						<th><?php esc_html_e( 'Score', 'kloud101-sentinel' ); ?></th>
					</tr>
				</thead>
				<tbody>
					<?php if ( empty( $recent ) ) : ?>
						<tr><td colspan="5"><?php esc_html_e( 'No scans have run yet.', 'kloud101-sentinel' ); ?></td></tr>
					<?php else : ?>
						<?php foreach ( $recent as $report ) : ?>
							<?php $summary = $report->summary ? json_decode( $report->summary, true ) : array(); ?>
							<tr>
								<td><?php echo esc_html( ucfirst( $report->type ) ); ?></td>
								<td><?php echo esc_html( $report->started_at ); ?></td>
								<td><?php echo esc_html( $report->duration_seconds ? $report->duration_seconds . 's' : '—' ); ?></td>
								<td><?php echo esc_html( isset( $summary['findings'] ) ? $summary['findings'] : '—' ); ?></td>
								<td><?php echo esc_html( isset( $summary['security_score'] ) ? $summary['security_score'] . '/100' : '—' ); ?></td>
							</tr>
						<?php endforeach; ?>
					<?php endif; ?>
				</tbody>
			</table>
		</div>
		<?php
	}

	/**
	 * Fetch the 10 most recent report rows.
	 *
	 * @return array<int, object>
	 */
	private function get_recent_reports() {
		global $wpdb;

		return $wpdb->get_results( "SELECT * FROM {$wpdb->prefix}k101_reports ORDER BY id DESC LIMIT 10" ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
	}
}
