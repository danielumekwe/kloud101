<?php
/**
 * Plugin Name:       Kloud101 Sentinel
 * Plugin URI:        https://kloud101.com/sentinel
 * Description:       Enterprise-grade, fully offline WordPress security suite — malware scanning, file integrity monitoring, upload scanning, login protection, a lightweight firewall, one-click hardening, and quarantine management. No external API required.
 * Version:           1.0.0
 * Requires at least: 6.0
 * Requires PHP:      7.4
 * Author:            Kloud101
 * Author URI:        https://kloud101.com
 * License:            GPL v2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       kloud101-sentinel
 * Domain Path:       /languages
 * Network:           true
 *
 * @package Kloud101Sentinel
 */

// Exit if accessed directly — never allow this file to be loaded outside WordPress.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/*
 * ---------------------------------------------------------------------
 * Plugin constants
 * ---------------------------------------------------------------------
 * These are intentionally defined here (rather than discovered at
 * runtime) so every class in the plugin can rely on them being present
 * without re-computing paths/URLs on every request.
 */
define( 'KLOUD101_SENTINEL_VERSION', '1.0.0' );
define( 'KLOUD101_SENTINEL_DB_VERSION', '1.0.0' );
define( 'KLOUD101_SENTINEL_FILE', __FILE__ );
define( 'KLOUD101_SENTINEL_BASENAME', plugin_basename( __FILE__ ) );
define( 'KLOUD101_SENTINEL_DIR', plugin_dir_path( __FILE__ ) );
define( 'KLOUD101_SENTINEL_URL', plugin_dir_url( __FILE__ ) );

/*
 * Quarantine root. Stored one level ABOVE wp-content/uploads on purpose
 * so quarantined PHP payloads never sit inside a publicly-served,
 * uploads-scoped directory tree — see Includes\Quarantine for the
 * companion .htaccess / index.php deny rules written into this folder.
 */
if ( ! defined( 'KLOUD101_SENTINEL_QUARANTINE_DIR' ) ) {
	define( 'KLOUD101_SENTINEL_QUARANTINE_DIR', WP_CONTENT_DIR . '/kloud101-sentinel-quarantine/' );
}

/*
 * ---------------------------------------------------------------------
 * PSR-4 autoloader
 * ---------------------------------------------------------------------
 * The plugin ships no Composer vendor directory (shared hosting targets
 * cannot be relied on to run `composer install`), so a small, dependency
 * free PSR-4 autoloader is registered instead. It maps exactly two
 * namespace prefixes onto their matching directories:
 *
 *   Kloud101Sentinel\Includes\*  => includes/
 *   Kloud101Sentinel\Admin\*     => admin/
 */
spl_autoload_register(
	static function ( $class_name ) {
		$prefixes = array(
			'Kloud101Sentinel\\Includes\\' => KLOUD101_SENTINEL_DIR . 'includes/',
			'Kloud101Sentinel\\Admin\\'    => KLOUD101_SENTINEL_DIR . 'admin/',
		);

		foreach ( $prefixes as $prefix => $base_dir ) {
			if ( 0 !== strncmp( $prefix, $class_name, strlen( $prefix ) ) ) {
				continue;
			}

			$relative_class = substr( $class_name, strlen( $prefix ) );
			$file           = $base_dir . str_replace( '\\', '/', $relative_class ) . '.php';

			if ( file_exists( $file ) ) {
				require $file;
			}

			return;
		}
	}
);

use Kloud101Sentinel\Includes\Activator;
use Kloud101Sentinel\Includes\Deactivator;
use Kloud101Sentinel\Includes\Findings;
use Kloud101Sentinel\Includes\Loader;
use Kloud101Sentinel\Includes\Logger;
use Kloud101Sentinel\Includes\Utilities;

/**
 * Activation callback.
 *
 * WordPress requires this to be a plain function reference (static
 * method callback) registered from the main plugin file; it cannot be
 * delegated to an instance built later in the request lifecycle.
 *
 * @param bool $network_wide Whether the plugin is being network-activated.
 */
function kloud101_sentinel_activate( $network_wide ) {
	Activator::activate( $network_wide );
}
register_activation_hook( __FILE__, 'kloud101_sentinel_activate' );

/**
 * Deactivation callback. Clears scheduled cron events; deliberately
 * does NOT drop tables or delete quarantined files — that destructive
 * step only happens in uninstall.php, and only if the site owner has
 * opted in via the "Remove data on uninstall" setting.
 */
function kloud101_sentinel_deactivate() {
	Deactivator::deactivate();
}
register_deactivation_hook( __FILE__, 'kloud101_sentinel_deactivate' );

/**
 * Class Kloud101Sentinel_Plugin
 *
 * Root composition object for the plugin. It owns the hook Loader,
 * instantiates every feature module, and asks each one to register its
 * own WordPress hooks against that shared Loader. No feature module
 * calls add_action()/add_filter() directly — see Loader for why.
 */
final class Kloud101Sentinel_Plugin {

	/**
	 * Singleton instance.
	 *
	 * @var Kloud101Sentinel_Plugin|null
	 */
	private static $instance = null;

	/**
	 * Central hook registry shared by every module.
	 *
	 * @var Loader
	 */
	private $loader;

	/**
	 * Instantiated feature modules, keyed by short name, so admin pages
	 * and AJAX handlers can fetch a live instance instead of constructing
	 * their own (keeps state such as loaded settings/signatures singular
	 * per request).
	 *
	 * @var array<string, object>
	 */
	private $modules = array();

	/**
	 * Retrieve (and lazily build) the singleton instance.
	 *
	 * @return Kloud101Sentinel_Plugin
	 */
	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	/**
	 * Private constructor — use instance().
	 */
	private function __construct() {
		$this->loader = new Loader();
		$this->load_modules();
		$this->loader->run();
	}

	/**
	 * Build every feature module and let it register its own hooks.
	 *
	 * Order matters only loosely: Logger/Utilities are created first
	 * because every other module depends on them for structured logging
	 * and shared helpers.
	 */
	private function load_modules() {
		Kloud101Sentinel\Includes\Installer::maybe_upgrade();

		$logger    = new Logger();
		$utilities = new Utilities();
		$findings  = new Findings();

		$this->modules['logger']    = $logger;
		$this->modules['utilities'] = $utilities;
		$this->modules['findings']  = $findings;

		/*
		 * Modules are built in explicit dependency order rather than a
		 * uniform loop, because several scanners need more than the
		 * base (Logger, Utilities, Findings) trio — e.g. UploadScanner
		 * reuses MalwareScanner's signature engine on suspicious
		 * uploads, and both it and ThemeScanner may quarantine what
		 * they find.
		 */
		$simple_modules = array(
			'quarantine'        => Kloud101Sentinel\Includes\Quarantine::class,
			'malware_scanner'   => Kloud101Sentinel\Includes\MalwareScanner::class,
			'integrity_scanner' => Kloud101Sentinel\Includes\IntegrityScanner::class,
			'plugin_scanner'    => Kloud101Sentinel\Includes\PluginScanner::class,
			'cron_scanner'      => Kloud101Sentinel\Includes\CronScanner::class,
			'database_scanner'  => Kloud101Sentinel\Includes\DatabaseScanner::class,
			'user_scanner'      => Kloud101Sentinel\Includes\UserScanner::class,
			'login_protection'  => Kloud101Sentinel\Includes\LoginProtection::class,
			'firewall'          => Kloud101Sentinel\Includes\Firewall::class,
			'hardening'         => Kloud101Sentinel\Includes\Hardening::class,
			'scheduler'         => Kloud101Sentinel\Includes\Scheduler::class,
			'notifications'     => Kloud101Sentinel\Includes\Notifications::class,
			'reports'           => Kloud101Sentinel\Includes\Reports::class,
		);

		foreach ( $simple_modules as $key => $class_name ) {
			$module = new $class_name( $logger, $utilities, $findings );

			if ( method_exists( $module, 'register' ) ) {
				$module->register( $this->loader );
			}

			$this->modules[ $key ] = $module;
		}

		$upload_scanner = new Kloud101Sentinel\Includes\UploadScanner(
			$logger,
			$utilities,
			$findings,
			$this->modules['quarantine'],
			$this->modules['malware_scanner']
		);
		$this->modules['upload_scanner'] = $upload_scanner;

		$theme_scanner = new Kloud101Sentinel\Includes\ThemeScanner(
			$logger,
			$utilities,
			$findings,
			$this->modules['malware_scanner']
		);
		$this->modules['theme_scanner'] = $theme_scanner;

		// The Scanner orchestrator composes the individual scanners above,
		// so it is built last and receives them directly.
		$scanner = new Kloud101Sentinel\Includes\Scanner(
			$logger,
			$findings,
			$this->modules['malware_scanner'],
			$this->modules['integrity_scanner'],
			$this->modules['upload_scanner'],
			$this->modules['plugin_scanner'],
			$this->modules['theme_scanner'],
			$this->modules['cron_scanner'],
			$this->modules['database_scanner'],
			$this->modules['quarantine']
		);
		$scanner->register( $this->loader );
		$this->modules['scanner'] = $scanner;

		if ( is_admin() ) {
			$admin_pages = array(
				Kloud101Sentinel\Admin\Dashboard::class,
				Kloud101Sentinel\Admin\Settings::class,
				Kloud101Sentinel\Admin\ScanPage::class,
				Kloud101Sentinel\Admin\ReportsPage::class,
				Kloud101Sentinel\Admin\QuarantinePage::class,
				Kloud101Sentinel\Admin\LogsPage::class,
			);

			foreach ( $admin_pages as $class_name ) {
				$page = new $class_name( $this->modules );
				$page->register( $this->loader );
			}
		}
	}

	/**
	 * Fetch a loaded module instance by key (e.g. 'quarantine', 'scanner').
	 *
	 * @param string $key Module key.
	 * @return object|null
	 */
	public function get_module( $key ) {
		return isset( $this->modules[ $key ] ) ? $this->modules[ $key ] : null;
	}

	/**
	 * Prevent cloning of the singleton.
	 */
	private function __clone() {}

	/**
	 * Prevent unserializing of the singleton.
	 */
	public function __wakeup() {
		throw new \Exception( 'Cannot unserialize a singleton.' );
	}
}

/**
 * Bootstraps the plugin once all plugins are loaded, so it can safely
 * detect sibling plugins/themes during scans.
 */
function kloud101_sentinel() {
	return Kloud101Sentinel_Plugin::instance();
}
add_action( 'plugins_loaded', 'kloud101_sentinel', 20 );
