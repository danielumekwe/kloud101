<?php
/**
 * One-click WordPress security hardening toggles.
 *
 * @package Kloud101Sentinel\Includes
 */

namespace Kloud101Sentinel\Includes;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Hardening
 *
 * Every method here is independently safe to call multiple times
 * (idempotent) and independently safe to enable/disable — there is no
 * ordering dependency between them. Two families of technique are
 * used depending on what's actually toggleable at runtime:
 *
 *  - Filter/action based (XML-RPC, file-edit capability, version
 *    disclosure, REST API restriction) — applied on every request via
 *    register(), reflecting the current saved setting.
 *  - Filesystem based (uploads PHP execution block, directory
 *    browsing, wp-config.php/.htaccess protection, salt rotation) —
 *    applied once when the admin flips the toggle (Settings calls the
 *    matching apply_*() method directly), since they write files.
 */
class Hardening {

	/**
	 * @var Logger
	 */
	private $logger;

	/**
	 * @var Utilities
	 */
	private $utilities;

	/**
	 * @var Findings
	 */
	private $findings;

	/**
	 * Constructor.
	 *
	 * @param Logger    $logger    Shared logger.
	 * @param Utilities $utilities Shared helpers.
	 * @param Findings  $findings  Shared findings repository.
	 */
	public function __construct( Logger $logger, Utilities $utilities, Findings $findings ) {
		$this->logger    = $logger;
		$this->utilities = $utilities;
		$this->findings  = $findings;
	}

	/**
	 * Register the runtime (filter/action based) hardening hooks. These
	 * re-read settings on every request so a toggle change takes effect
	 * immediately without needing to "reapply" anything.
	 *
	 * @param Loader $loader Shared hook loader.
	 */
	public function register( Loader $loader ) {
		$loader->add_filter( 'xmlrpc_enabled', $this, 'filter_xmlrpc_enabled' );
		$loader->add_filter( 'map_meta_cap', $this, 'filter_file_edit_caps', 10, 2 );
		$loader->add_action( 'wp_head', $this, 'maybe_hide_generator', 1 );
		$loader->add_filter( 'the_generator', $this, 'filter_generator_tag' );
		$loader->add_filter( 'rest_authentication_errors', $this, 'filter_rest_authentication' );
	}

	/**
	 * Current settings, defaults filled in.
	 *
	 * @return array<string, mixed>
	 */
	private function settings() {
		return wp_parse_args( get_option( 'kloud101_sentinel_settings', array() ), Installer::default_settings() );
	}

	/**
	 * Disable XML-RPC entirely when the setting is enabled.
	 *
	 * @param bool $enabled Current xmlrpc_enabled value.
	 * @return bool
	 */
	public function filter_xmlrpc_enabled( $enabled ) {
		return $this->settings()['hardening_disable_xmlrpc'] ? false : $enabled;
	}

	/**
	 * Strip the theme/plugin editor capabilities when file-edit
	 * hardening is enabled — functionally equivalent to
	 * DISALLOW_FILE_EDIT, but toggleable at runtime (the constant must
	 * be defined before WordPress loads, which a plugin cannot do for
	 * an already-booted request).
	 *
	 * @param string[] $caps Required primitive capabilities.
	 * @param string   $cap  Requested meta capability.
	 * @return string[]
	 */
	public function filter_file_edit_caps( $caps, $cap ) {
		if ( ! $this->settings()['hardening_disable_file_edit'] ) {
			return $caps;
		}

		if ( in_array( $cap, array( 'edit_plugins', 'edit_themes', 'edit_files' ), true ) ) {
			$caps[] = 'do_not_allow';
		}

		return $caps;
	}

	/**
	 * Remove the wp_generator meta tag output when version hiding is on.
	 */
	public function maybe_hide_generator() {
		if ( $this->settings()['hardening_hide_wp_version'] ) {
			remove_action( 'wp_head', 'wp_generator' );
		}
	}

	/**
	 * Blank out the generator tag for feeds/other contexts that call
	 * the_generator() directly rather than through the wp_head action.
	 *
	 * @param string $generator Generator markup.
	 * @return string
	 */
	public function filter_generator_tag( $generator ) {
		return $this->settings()['hardening_hide_wp_version'] ? '' : $generator;
	}

	/**
	 * When REST API restriction is enabled, require an authenticated
	 * user for every route except an explicitly whitelisted set of
	 * namespaces (filterable, so plugins that depend on public REST
	 * endpoints keep working after an administrator opts in).
	 *
	 * @param \WP_Error|null|bool $result Existing authentication result.
	 * @return \WP_Error|null|bool
	 */
	public function filter_rest_authentication( $result ) {
		if ( ! empty( $result ) ) {
			return $result;
		}

		if ( ! $this->settings()['hardening_restrict_rest_api'] || is_user_logged_in() ) {
			return $result;
		}

		$route = isset( $GLOBALS['wp']->query_vars['rest_route'] ) ? $GLOBALS['wp']->query_vars['rest_route'] : '';

		/**
		 * REST route prefixes that remain publicly accessible even when
		 * REST API restriction is enabled (e.g. "/oembed/1.0").
		 *
		 * @param string[] $whitelist Route prefixes.
		 */
		$whitelist = apply_filters( 'kloud101_sentinel_rest_public_routes', array( '/oembed/1.0', '/contact-form-7/v1' ) );

		foreach ( $whitelist as $prefix ) {
			if ( 0 === strpos( $route, $prefix ) ) {
				return $result;
			}
		}

		return new \WP_Error( 'rest_forbidden', __( 'REST API access requires authentication on this site.', 'kloud101-sentinel' ), array( 'status' => 401 ) );
	}

	/**
	 * Write (or refresh) a marker-delimited .htaccess block denying PHP
	 * execution inside wp-content/uploads. No-op on non-Apache servers,
	 * but harmless to leave in place.
	 *
	 * @return bool
	 */
	public function apply_block_php_in_uploads() {
		$upload_dir = wp_upload_dir();
		$rules      = "<FilesMatch \"\\.(?:php|php\\d|phtml|phar|pht)$\">\nRequire all denied\n</FilesMatch>\n";

		return $this->write_marked_htaccess( trailingslashit( $upload_dir['basedir'] ) . '.htaccess', 'Kloud101 Sentinel Block PHP', $rules );
	}

	/**
	 * Write a marker-delimited .htaccess block disabling directory
	 * listing at the site root.
	 *
	 * @return bool
	 */
	public function apply_disable_directory_browsing() {
		return $this->write_marked_htaccess( ABSPATH . '.htaccess', 'Kloud101 Sentinel Disable Browsing', "Options -Indexes\n" );
	}

	/**
	 * Write a marker-delimited .htaccess block denying direct access to
	 * wp-config.php, and reduce its file permissions to owner-read-only
	 * where the hosting environment allows it.
	 *
	 * @return bool
	 */
	public function apply_protect_wp_config() {
		$rules = "<Files wp-config.php>\nRequire all denied\n</Files>\n";
		$ok    = $this->write_marked_htaccess( ABSPATH . '.htaccess', 'Kloud101 Sentinel Protect wp-config', $rules );

		$wp_config_path = ABSPATH . 'wp-config.php';
		if ( file_exists( $wp_config_path ) ) {
			@chmod( $wp_config_path, 0440 ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged, WordPress.WP.AlternativeFunctions.file_system_operations_chmod
		}

		return $ok;
	}

	/**
	 * Reduce the root .htaccess file's own permissions so it can't be
	 * casually overwritten by a compromised, lower-privileged process.
	 *
	 * @return bool
	 */
	public function apply_protect_htaccess() {
		$path = ABSPATH . '.htaccess';

		if ( ! file_exists( $path ) ) {
			return false;
		}

		return (bool) @chmod( $path, 0444 ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged, WordPress.WP.AlternativeFunctions.file_system_operations_chmod
	}

	/**
	 * Check whether the site is using the default "wp_" table prefix
	 * and record a low-severity finding if so (informational hardening
	 * suggestion, not something this plugin can safely fix in place —
	 * changing the live prefix requires a full DB migration).
	 *
	 * @return bool True if the finding was recorded (prefix is default).
	 */
	public function check_database_prefix() {
		global $wpdb;

		if ( 'wp_' !== $wpdb->prefix ) {
			return false;
		}

		$this->findings->record(
			array(
				'type'        => 'hardening',
				'severity'    => Findings::SEVERITY_LOW,
				'file_path'   => '',
				'signature'   => 'default_db_prefix',
				'description' => __( 'The database is using the default "wp_" table prefix. Changing it requires a full migration and is not done automatically.', 'kloud101-sentinel' ),
			)
		);

		return true;
	}

	/**
	 * Rotate the secret authentication keys/salts in wp-config.php.
	 * Prefers fetching fresh, high-quality randomness from the official
	 * WordPress.org salt API, but falls back to locally generated
	 * random strings if the site has no outbound connectivity — salt
	 * rotation must work fully offline.
	 *
	 * @return true|\WP_Error
	 */
	public function rotate_salts() {
		$keys = array( 'AUTH_KEY', 'SECURE_AUTH_KEY', 'LOGGED_IN_KEY', 'NONCE_KEY', 'AUTH_SALT', 'SECURE_AUTH_SALT', 'LOGGED_IN_SALT', 'NONCE_SALT' );

		$new_values = $this->fetch_salts_from_wordpress_org( $keys );

		if ( null === $new_values ) {
			$new_values = array();
			foreach ( $keys as $key ) {
				$new_values[ $key ] = wp_generate_password( 64, true, true );
			}
		}

		$wp_config_path = ABSPATH . 'wp-config.php';

		if ( ! is_writable( $wp_config_path ) ) {
			return new \WP_Error( 'kloud101_sentinel_not_writable', __( 'wp-config.php is not writable — cannot rotate salts.', 'kloud101-sentinel' ) );
		}

		$contents = file_get_contents( $wp_config_path ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents

		if ( false === $contents ) {
			return new \WP_Error( 'kloud101_sentinel_read_failed', __( 'Could not read wp-config.php.', 'kloud101-sentinel' ) );
		}

		// Back up the original before any modification.
		file_put_contents( $wp_config_path . '.k101-bak', $contents ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents

		foreach ( $new_values as $key => $value ) {
			$escaped_value = addslashes( $value );
			$pattern       = '/define\(\s*[\'"]' . preg_quote( $key, '/' ) . '[\'"]\s*,\s*[\'"].*?[\'"]\s*\)\s*;/s';
			$replacement   = "define( '{$key}', '{$escaped_value}' );";

			if ( preg_match( $pattern, $contents ) ) {
				$contents = preg_replace( $pattern, $replacement, $contents, 1 );
			} else {
				// Key not present yet (unusual, but possible on a
				// hand-edited wp-config.php): insert it just before the
				// "That's all, stop editing" marker if present, else
				// after the opening PHP tag.
				if ( false !== strpos( $contents, "/* That's all, stop editing" ) ) {
					$contents = str_replace( "/* That's all, stop editing", $replacement . "\n\n/* That's all, stop editing", $contents );
				} else {
					$contents = preg_replace( '/^<\?php/', "<?php\n" . $replacement, $contents, 1 );
				}
			}
		}

		$written = file_put_contents( $wp_config_path, $contents ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents

		if ( false === $written ) {
			return new \WP_Error( 'kloud101_sentinel_write_failed', __( 'Could not write updated wp-config.php.', 'kloud101-sentinel' ) );
		}

		$this->logger->action( 'hardening', 'Rotated authentication keys/salts in wp-config.php.' );

		return true;
	}

	/**
	 * Fetch fresh salts from the WordPress.org secret-key API.
	 *
	 * @param string[] $keys Constant names to extract.
	 * @return array<string, string>|null Null if unreachable.
	 */
	private function fetch_salts_from_wordpress_org( array $keys ) {
		$response = wp_remote_get( 'https://api.wordpress.org/secret-key/1.1/salt/', array( 'timeout' => 8 ) );

		if ( is_wp_error( $response ) || 200 !== (int) wp_remote_retrieve_response_code( $response ) ) {
			return null;
		}

		$body   = wp_remote_retrieve_body( $response );
		$values = array();

		foreach ( $keys as $key ) {
			if ( preg_match( "/define\\(\\s*'" . preg_quote( $key, '/' ) . "'\\s*,\\s*'(.*?)'\\s*\\);/", $body, $match ) ) {
				$values[ $key ] = stripslashes( $match[1] );
			}
		}

		return count( $values ) === count( $keys ) ? $values : null;
	}

	/**
	 * Reset a conservative, safe subset of file/directory permissions:
	 * wp-config.php, the root .htaccess, and the top-level wp-content
	 * subdirectories. Deliberately does not recurse through every
	 * plugin/theme file — many plugins rely on specific permissions for
	 * their own cache/upload subdirectories, and a blanket recursive
	 * chmod is a common cause of "hardening" plugins breaking sites.
	 *
	 * @return array{files_updated: int, errors: string[]}
	 */
	public function reset_permissions() {
		$updated = 0;
		$errors  = array();

		$file_targets = array(
			ABSPATH . 'wp-config.php' => 0640,
			ABSPATH . '.htaccess'    => 0644,
		);

		foreach ( $file_targets as $path => $mode ) {
			if ( ! file_exists( $path ) ) {
				continue;
			}

			if ( @chmod( $path, $mode ) ) { // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged, WordPress.WP.AlternativeFunctions.file_system_operations_chmod
				++$updated;
			} else {
				$errors[] = sprintf( 'Could not chmod %s', $path );
			}
		}

		$directory_targets = array( WP_CONTENT_DIR, WP_CONTENT_DIR . '/plugins', WP_CONTENT_DIR . '/themes', WP_CONTENT_DIR . '/uploads' );

		foreach ( $directory_targets as $dir ) {
			if ( ! is_dir( $dir ) ) {
				continue;
			}

			if ( @chmod( $dir, 0755 ) ) { // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged, WordPress.WP.AlternativeFunctions.file_system_operations_chmod
				++$updated;
			} else {
				$errors[] = sprintf( 'Could not chmod %s', $dir );
			}
		}

		$this->logger->action( 'hardening', sprintf( 'Reset permissions on %d path(s).', $updated ), array( 'errors' => $errors ) );

		return array(
			'files_updated' => $updated,
			'errors'        => $errors,
		);
	}

	/**
	 * Write (or refresh) a WordPress "marker" block into an .htaccess
	 * file using insert_with_markers(), which safely no-ops on servers
	 * that don't use Apache (the file simply won't be read by nginx/
	 * LiteSpeed, but writing it never harms anything).
	 *
	 * @param string $path    Absolute path to the .htaccess file.
	 * @param string $marker  Unique marker name for this rule block.
	 * @param string $rules   Raw Apache directives (newline separated).
	 * @return bool
	 */
	private function write_marked_htaccess( $path, $marker, $rules ) {
		if ( ! function_exists( 'insert_with_markers' ) ) {
			require_once ABSPATH . 'wp-admin/includes/misc.php';
		}

		$lines = array_filter( array_map( 'rtrim', explode( "\n", $rules ) ) );

		return (bool) insert_with_markers( $path, $marker, $lines );
	}
}
