<?php
/**
 * Admin notices and email alerts for security-relevant events.
 *
 * @package Kloud101Sentinel\Includes
 */

namespace Kloud101Sentinel\Includes;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Notifications
 *
 * Listens to the small set of generic events every other module
 * already fires (`kloud101_sentinel_finding_recorded`,
 * `kloud101_sentinel_scan_completed`, `kloud101_sentinel_login_lockout`)
 * rather than being hard-wired to any specific scanner, so a future
 * module automatically gets notification coverage for free.
 */
class Notifications {

	/**
	 * @var Logger
	 */
	private $logger;

	/**
	 * @var Utilities
	 */
	private $utilities;

	/**
	 * @var Findings
	 */
	private $findings;

	/**
	 * Constructor.
	 *
	 * @param Logger    $logger    Shared logger.
	 * @param Utilities $utilities Shared helpers.
	 * @param Findings  $findings  Shared findings repository.
	 */
	public function __construct( Logger $logger, Utilities $utilities, Findings $findings ) {
		$this->logger    = $logger;
		$this->utilities = $utilities;
		$this->findings  = $findings;
	}

	/**
	 * Register hooks.
	 *
	 * @param Loader $loader Shared hook loader.
	 */
	public function register( Loader $loader ) {
		$loader->add_action( 'admin_notices', $this, 'render_admin_notices' );
		$loader->add_action( 'kloud101_sentinel_finding_recorded', $this, 'on_finding_recorded', 10, 2 );
		$loader->add_action( 'kloud101_sentinel_scan_completed', $this, 'on_scan_completed', 10, 2 );
		$loader->add_action( 'kloud101_sentinel_login_lockout', $this, 'on_login_lockout', 10, 2 );
	}

	/**
	 * Current settings, defaults filled in.
	 *
	 * @return array<string, mixed>
	 */
	private function settings() {
		return wp_parse_args( get_option( 'kloud101_sentinel_settings', array() ), Installer::default_settings() );
	}

	/**
	 * Show a dismissible admin notice on every wp-admin screen when
	 * there is at least one open critical finding. Deliberately does
	 * not fire for lower severities — this is meant to be an urgent,
	 * rare interruption, not routine noise the administrator learns to
	 * ignore.
	 */
	public function render_admin_notices() {
		if ( ! current_user_can( 'manage_kloud101_sentinel' ) ) {
			return;
		}

		$counts = $this->findings->counts_by_severity();

		if ( empty( $counts[ Findings::SEVERITY_CRITICAL ] ) ) {
			return;
		}

		printf(
			'<div class="notice notice-error"><p>%s</p></div>',
			wp_kses_post(
				sprintf(
					/* translators: 1: count, 2: dashboard URL */
					_n(
						'<strong>Kloud101 Sentinel:</strong> %1$d critical security finding requires attention. <a href="%2$s">View dashboard &rarr;</a>',
						'<strong>Kloud101 Sentinel:</strong> %1$d critical security findings require attention. <a href="%2$s">View dashboard &rarr;</a>',
						$counts[ Findings::SEVERITY_CRITICAL ],
						'kloud101-sentinel'
					),
					$counts[ Findings::SEVERITY_CRITICAL ],
					esc_url( admin_url( 'admin.php?page=kloud101-sentinel' ) )
				)
			)
		);
	}

	/**
	 * Email the administrator immediately for a critical or high
	 * severity finding, if email notifications are enabled. Medium/low
	 * findings are intentionally left to the scan-completion digest
	 * rather than triggering their own email.
	 *
	 * @param int   $id   Finding ID.
	 * @param array $data Finding data.
	 */
	public function on_finding_recorded( $id, array $data ) {
		$settings = $this->settings();

		if ( empty( $settings['email_notifications'] ) ) {
			return;
		}

		if ( ! in_array( $data['severity'], array( Findings::SEVERITY_CRITICAL, Findings::SEVERITY_HIGH ), true ) ) {
			return;
		}

		$this->send_email(
			$settings['notification_email'],
			sprintf( '[%s] Security finding: %s', get_bloginfo( 'name' ), ucfirst( $data['severity'] ) ),
			sprintf(
				"A %s severity finding was recorded on %s:\n\nType: %s\nSignature: %s\nFile/Location: %s\nDescription: %s\n\nReview it at: %s",
				$data['severity'],
				home_url(),
				$data['type'],
				$data['signature'],
				$data['file_path'],
				$data['description'],
				admin_url( 'admin.php?page=kloud101-sentinel-reports' )
			)
		);
	}

	/**
	 * Send a completion digest once a scan (manual or scheduled)
	 * finishes.
	 *
	 * @param int   $report_id Report ID.
	 * @param array $summary   Scan summary data.
	 */
	public function on_scan_completed( $report_id, array $summary ) {
		$settings = $this->settings();

		if ( empty( $settings['email_notifications'] ) ) {
			return;
		}

		$severity = $summary['severity'];

		$this->send_email(
			$settings['notification_email'],
			sprintf( '[%s] Scan complete: %d finding(s), score %d/100', get_bloginfo( 'name' ), $summary['findings'], $summary['security_score'] ),
			sprintf(
				"Scan #%d completed on %s.\n\nSecurity score: %d/100\nCritical: %d\nHigh: %d\nMedium: %d\nLow: %d\n\nView details: %s",
				$report_id,
				home_url(),
				$summary['security_score'],
				$severity[ Findings::SEVERITY_CRITICAL ],
				$severity[ Findings::SEVERITY_HIGH ],
				$severity[ Findings::SEVERITY_MEDIUM ],
				$severity[ Findings::SEVERITY_LOW ],
				admin_url( 'admin.php?page=kloud101-sentinel-reports' )
			)
		);
	}

	/**
	 * Alert on an IP being locked out for brute-forcing logins.
	 *
	 * @param string $ip    Offending IP.
	 * @param int    $count Failed attempt count.
	 */
	public function on_login_lockout( $ip, $count ) {
		$settings = $this->settings();

		if ( empty( $settings['email_notifications'] ) ) {
			return;
		}

		$this->send_email(
			$settings['notification_email'],
			sprintf( '[%s] Login lockout triggered', get_bloginfo( 'name' ) ),
			sprintf( "IP address %s was locked out after %d failed login attempts on %s.", $ip, $count, home_url() )
		);
	}

	/**
	 * Send a plain-text notification email, guarding against an empty
	 * recipient (e.g. a site with admin_email cleared).
	 *
	 * @param string $to      Recipient email.
	 * @param string $subject Subject line.
	 * @param string $message Body text.
	 */
	private function send_email( $to, $subject, $message ) {
		if ( empty( $to ) || ! is_email( $to ) ) {
			return;
		}

		wp_mail( $to, $subject, $message );
	}
}
