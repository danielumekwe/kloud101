<?php
/**
 * Shared, stateless helper functions used across every scanner and
 * admin page.
 *
 * @package Kloud101Sentinel\Includes
 */

namespace Kloud101Sentinel\Includes;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Utilities
 *
 * Deliberately has no constructor dependencies and no side effects on
 * instantiation — every method is safe to call from any context
 * (admin, cron, AJAX, CLI) without bootstrapping the rest of the plugin.
 */
class Utilities {

	/**
	 * Convert a byte count into a human-readable string (e.g. "12.4 MB").
	 *
	 * @param int $bytes    Byte count.
	 * @param int $decimals Decimal precision.
	 * @return string
	 */
	public static function format_bytes( $bytes, $decimals = 2 ) {
		$bytes = max( 0, (int) $bytes );
		$units = array( 'B', 'KB', 'MB', 'GB', 'TB' );
		$power = $bytes > 0 ? (int) floor( log( $bytes, 1024 ) ) : 0;
		$power = min( $power, count( $units ) - 1 );

		return sprintf( '%s %s', number_format( $bytes / ( 1024 ** $power ), $decimals ), $units[ $power ] );
	}

	/**
	 * Recursively compute a directory's total size in bytes.
	 *
	 * Results are cached in a transient because walking large uploads
	 * directories on shared hosting is expensive — never call this
	 * synchronously on a front-end request.
	 *
	 * @param string $dir       Absolute directory path.
	 * @param int    $ttl       Cache lifetime in seconds. Default 6 hours.
	 * @return int Size in bytes.
	 */
	public static function get_directory_size( $dir, $ttl = 6 * HOUR_IN_SECONDS ) {
		$cache_key = 'k101_dirsize_' . md5( $dir );
		$cached    = get_transient( $cache_key );

		if ( false !== $cached ) {
			return (int) $cached;
		}

		$size = 0;

		if ( is_dir( $dir ) ) {
			try {
				$iterator = new \RecursiveIteratorIterator(
					new \RecursiveDirectoryIterator( $dir, \FilesystemIterator::SKIP_DOTS ),
					\RecursiveIteratorIterator::CATCH_GET_CHILD
				);

				foreach ( $iterator as $file ) {
					if ( $file->isFile() ) {
						$size += $file->getSize();
					}
				}
			} catch ( \Exception $e ) {
				// Unreadable subdirectories are skipped rather than fatal.
				$size = $size;
			}
		}

		set_transient( $cache_key, $size, $ttl );

		return $size;
	}

	/**
	 * Best-effort client IP resolution.
	 *
	 * Only trusts X-Forwarded-For / X-Real-IP when the site explicitly
	 * declares it sits behind a proxy (filterable), otherwise falls back
	 * to REMOTE_ADDR — trusting forwarded headers unconditionally would
	 * let an attacker spoof their way past IP-based rate limiting.
	 *
	 * @return string
	 */
	public static function get_client_ip() {
		$trust_proxy = apply_filters( 'kloud101_sentinel_trust_proxy_headers', false );
		$remote_addr = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '';

		if ( $trust_proxy ) {
			foreach ( array( 'HTTP_X_REAL_IP', 'HTTP_X_FORWARDED_FOR' ) as $header ) {
				if ( ! empty( $_SERVER[ $header ] ) ) {
					$value = sanitize_text_field( wp_unslash( $_SERVER[ $header ] ) );
					$parts = explode( ',', $value );
					$ip    = trim( $parts[0] );

					if ( filter_var( $ip, FILTER_VALIDATE_IP ) ) {
						return $ip;
					}
				}
			}
		}

		return filter_var( $remote_addr, FILTER_VALIDATE_IP ) ? $remote_addr : '0.0.0.0';
	}

	/**
	 * Resolve WP_Filesystem, initializing it with direct-access
	 * credentials when possible. Returns null if the filesystem cannot
	 * be initialized (caller must handle gracefully rather than fatal).
	 *
	 * @return \WP_Filesystem_Base|null
	 */
	public static function get_filesystem() {
		global $wp_filesystem;

		if ( ! function_exists( 'WP_Filesystem' ) ) {
			require_once ABSPATH . 'wp-admin/includes/file.php';
		}

		if ( empty( $wp_filesystem ) ) {
			WP_Filesystem();
		}

		return $wp_filesystem instanceof \WP_Filesystem_Base ? $wp_filesystem : null;
	}

	/**
	 * Compute the sha256 hash of a file's contents.
	 *
	 * @param string $path Absolute file path.
	 * @return string|null Null if the file cannot be read.
	 */
	public static function hash_file( $path ) {
		if ( ! is_readable( $path ) || ! is_file( $path ) ) {
			return null;
		}

		$hash = @hash_file( 'sha256', $path );

		return false !== $hash ? $hash : null;
	}

	/**
	 * Confirm $path is actually inside $base_dir, resolving symlinks and
	 * ".." segments first. Used before any destructive filesystem
	 * operation (quarantine move, delete) to prevent path traversal.
	 *
	 * @param string $path     Path to validate.
	 * @param string $base_dir Directory $path must be contained within.
	 * @return bool
	 */
	public static function is_path_within( $path, $base_dir ) {
		$real_path = realpath( $path );
		$real_base = realpath( $base_dir );

		if ( false === $real_path || false === $real_base ) {
			return false;
		}

		return 0 === strpos( $real_path, rtrim( $real_base, '/\\' ) . DIRECTORY_SEPARATOR )
			|| $real_path === $real_base;
	}

	/**
	 * Recursively iterate PHP-relevant files under a directory, skipping
	 * the plugin's own quarantine folder and any path a filter opts out.
	 *
	 * @param string $dir       Absolute directory to walk.
	 * @param array  $extensions Lower-cased extensions to include (without the dot). Empty = all files.
	 * @return \Generator<string>
	 */
	public static function iterate_files( $dir, array $extensions = array() ) {
		if ( ! is_dir( $dir ) ) {
			return;
		}

		$iterator = new \RecursiveIteratorIterator(
			new \RecursiveDirectoryIterator( $dir, \FilesystemIterator::SKIP_DOTS ),
			\RecursiveIteratorIterator::CATCH_GET_CHILD
		);

		foreach ( $iterator as $file ) {
			if ( ! $file->isFile() ) {
				continue;
			}

			$path = $file->getPathname();

			if ( false !== strpos( $path, 'kloud101-sentinel-quarantine' ) ) {
				continue;
			}

			if ( ! empty( $extensions ) ) {
				$ext = strtolower( $file->getExtension() );

				if ( ! in_array( $ext, $extensions, true ) ) {
					continue;
				}
			}

			yield $path;
		}
	}

	/**
	 * Approximate current PHP process memory usage, formatted.
	 *
	 * @return string
	 */
	public static function get_memory_usage() {
		return self::format_bytes( memory_get_usage( true ) );
	}

	/**
	 * Generate a cryptographically random token for nonces/tokens that
	 * live outside of the WordPress nonce system (e.g. quarantine
	 * receipt IDs).
	 *
	 * @param int $length Byte length before hex-encoding.
	 * @return string
	 */
	public static function random_token( $length = 16 ) {
		return bin2hex( random_bytes( $length ) );
	}

	/**
	 * Server software string, safe for display (Site Health, dashboard).
	 *
	 * @return string
	 */
	public static function get_server_software() {
		return isset( $_SERVER['SERVER_SOFTWARE'] )
			? sanitize_text_field( wp_unslash( $_SERVER['SERVER_SOFTWARE'] ) )
			: __( 'Unknown', 'kloud101-sentinel' );
	}
}
