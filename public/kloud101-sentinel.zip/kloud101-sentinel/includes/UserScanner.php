<?php
/**
 * Real-time and reconciliation-based monitoring of user accounts:
 * new administrators, privilege escalation, deleted admins, and
 * password resets.
 *
 * @package Kloud101Sentinel\Includes
 */

namespace Kloud101Sentinel\Includes;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class UserScanner
 *
 * Runs in two modes: real-time (WordPress hooks fire the instant an
 * account is created/promoted/deleted, so those events are recorded
 * immediately rather than waiting for the next scheduled scan) and
 * reconciliation (scan() re-derives the current administrator list
 * from the database and diffs it against the last known baseline —
 * this is the safety net that catches an admin account created by
 * directly manipulating the database, bypassing every WordPress hook).
 */
class UserScanner {

	const BASELINE_OPTION = 'kloud101_sentinel_admin_baseline';

	/**
	 * @var Logger
	 */
	private $logger;

	/**
	 * @var Utilities
	 */
	private $utilities;

	/**
	 * @var Findings
	 */
	private $findings;

	/**
	 * Constructor.
	 *
	 * @param Logger    $logger    Shared logger.
	 * @param Utilities $utilities Shared helpers.
	 * @param Findings  $findings  Shared findings repository.
	 */
	public function __construct( Logger $logger, Utilities $utilities, Findings $findings ) {
		$this->logger    = $logger;
		$this->utilities = $utilities;
		$this->findings  = $findings;
	}

	/**
	 * Register real-time hooks.
	 *
	 * @param Loader $loader Shared hook loader.
	 */
	public function register( Loader $loader ) {
		$loader->add_action( 'user_register', $this, 'on_user_register', 10, 1 );
		$loader->add_action( 'set_user_role', $this, 'on_set_user_role', 10, 3 );
		$loader->add_action( 'delete_user', $this, 'on_delete_user', 10, 1 );
		$loader->add_action( 'after_password_reset', $this, 'on_password_reset', 10, 1 );
	}

	/**
	 * Fires immediately when any new user account is created.
	 *
	 * @param int $user_id New user ID.
	 */
	public function on_user_register( $user_id ) {
		$user = get_userdata( $user_id );

		if ( ! $user ) {
			return;
		}

		if ( in_array( 'administrator', (array) $user->roles, true ) ) {
			$this->record_new_admin( $user );
		}

		$this->logger->info( 'user_scanner', sprintf( 'New user account created: %s (ID %d)', $user->user_login, $user_id ) );
	}

	/**
	 * Fires when a user's role set changes. Used to detect privilege
	 * escalation to administrator from a lower role.
	 *
	 * @param int    $user_id  User ID.
	 * @param string $role     New primary role.
	 * @param array  $old_roles Previous roles.
	 */
	public function on_set_user_role( $user_id, $role, $old_roles ) {
		if ( 'administrator' !== $role || in_array( 'administrator', (array) $old_roles, true ) ) {
			return;
		}

		$user = get_userdata( $user_id );

		if ( ! $user ) {
			return;
		}

		$this->findings->record(
			array(
				'type'        => 'user',
				'severity'    => Findings::SEVERITY_CRITICAL,
				'file_path'   => sprintf( 'user:%d', $user_id ),
				'signature'   => 'privilege_escalation',
				'description' => sprintf(
					__( 'User "%1$s" (ID %2$d) was promoted to Administrator from role(s): %3$s.', 'kloud101-sentinel' ),
					$user->user_login,
					$user_id,
					implode( ', ', $old_roles )
				),
			)
		);

		$this->add_to_baseline( $user_id );

		$this->logger->warning( 'user_scanner', sprintf( 'Privilege escalation: %s promoted to administrator.', $user->user_login ) );
	}

	/**
	 * Fires just before a user is deleted. Records the event if the
	 * account being removed was an administrator (informational, not
	 * automatically a threat — but worth an audit trail entry).
	 *
	 * @param int $user_id User ID about to be deleted.
	 */
	public function on_delete_user( $user_id ) {
		$user = get_userdata( $user_id );

		if ( ! $user || ! in_array( 'administrator', (array) $user->roles, true ) ) {
			return;
		}

		$this->findings->record(
			array(
				'type'        => 'user',
				'severity'    => Findings::SEVERITY_MEDIUM,
				'file_path'   => sprintf( 'user:%d', $user_id ),
				'signature'   => 'administrator_deleted',
				'description' => sprintf( __( 'Administrator account "%s" (ID %d) was deleted.', 'kloud101-sentinel' ), $user->user_login, $user_id ),
			)
		);

		$this->remove_from_baseline( $user_id );
	}

	/**
	 * Fires after any user's password is reset. Logged for the audit
	 * trail; a spike in resets across many accounts in a short window
	 * is exactly the kind of thing the Reports/Notifications digest
	 * should surface to the administrator.
	 *
	 * @param \WP_User $user User whose password was reset.
	 */
	public function on_password_reset( $user ) {
		$this->logger->action( 'user_scanner', sprintf( 'Password reset for user "%s" (ID %d).', $user->user_login, $user->ID ) );
	}

	/**
	 * Reconciliation pass: re-derive the administrator list from the
	 * database right now and diff it against the stored baseline,
	 * catching accounts that became administrators without ever firing
	 * a WordPress hook (direct database edits).
	 *
	 * @param int $scan_id Owning report ID.
	 * @return int Findings recorded.
	 */
	public function scan( $scan_id ) {
		$current_admin_ids = get_users( array( 'role' => 'administrator', 'fields' => 'ID' ) );
		$current_admin_ids = array_map( 'intval', $current_admin_ids );
		$baseline          = get_option( self::BASELINE_OPTION, null );

		if ( null === $baseline ) {
			// First run: establish the baseline silently, no findings.
			update_option( self::BASELINE_OPTION, $current_admin_ids, false );
			return 0;
		}

		$new_admins = array_diff( $current_admin_ids, $baseline );
		$count      = 0;

		foreach ( $new_admins as $user_id ) {
			$user = get_userdata( $user_id );

			$this->findings->record(
				array(
					'scan_id'     => $scan_id,
					'type'        => 'user',
					'severity'    => Findings::SEVERITY_CRITICAL,
					'file_path'   => sprintf( 'user:%d', $user_id ),
					'signature'   => 'undetected_administrator',
					'description' => sprintf(
						__( 'Administrator account "%s" (ID %d) exists but was never observed being created or promoted — check for direct database tampering.', 'kloud101-sentinel' ),
						$user ? $user->user_login : '(unknown)',
						$user_id
					),
				)
			);
			++$count;
		}

		update_option( self::BASELINE_OPTION, $current_admin_ids, false );

		return $count;
	}

	/**
	 * Record a "new administrator" finding and add the user to baseline.
	 *
	 * @param \WP_User $user New administrator.
	 */
	private function record_new_admin( \WP_User $user ) {
		$this->findings->record(
			array(
				'type'        => 'user',
				'severity'    => Findings::SEVERITY_HIGH,
				'file_path'   => sprintf( 'user:%d', $user->ID ),
				'signature'   => 'new_administrator',
				'description' => sprintf( __( 'New user account "%s" (ID %d) was created directly with the Administrator role.', 'kloud101-sentinel' ), $user->user_login, $user->ID ),
			)
		);

		$this->add_to_baseline( $user->ID );
	}

	/**
	 * Add a user ID to the stored administrator baseline.
	 *
	 * @param int $user_id User ID.
	 */
	private function add_to_baseline( $user_id ) {
		$baseline = get_option( self::BASELINE_OPTION, array() );

		if ( ! in_array( (int) $user_id, $baseline, true ) ) {
			$baseline[] = (int) $user_id;
			update_option( self::BASELINE_OPTION, $baseline, false );
		}
	}

	/**
	 * Remove a user ID from the stored administrator baseline.
	 *
	 * @param int $user_id User ID.
	 */
	private function remove_from_baseline( $user_id ) {
		$baseline = get_option( self::BASELINE_OPTION, array() );
		$baseline = array_values( array_diff( $baseline, array( (int) $user_id ) ) );
		update_option( self::BASELINE_OPTION, $baseline, false );
	}
}
