<?php
/**
 * Database-level malware/tamper detection: suspicious wp_options
 * entries, injected content in posts, and hidden administrator
 * accounts.
 *
 * @package Kloud101Sentinel\Includes
 */

namespace Kloud101Sentinel\Includes;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class DatabaseScanner
 *
 * File-based scanners cannot see malware that lives entirely inside
 * the database — a common technique once a site is compromised is to
 * inject spam/redirect payloads directly into `wp_options` (autoloaded
 * so it runs on every request) or into post content, without touching
 * the filesystem at all.
 */
class DatabaseScanner {

	/**
	 * @var Logger
	 */
	private $logger;

	/**
	 * @var Utilities
	 */
	private $utilities;

	/**
	 * @var Findings
	 */
	private $findings;

	/**
	 * Constructor.
	 *
	 * @param Logger    $logger    Shared logger.
	 * @param Utilities $utilities Shared helpers.
	 * @param Findings  $findings  Shared findings repository.
	 */
	public function __construct( Logger $logger, Utilities $utilities, Findings $findings ) {
		$this->logger    = $logger;
		$this->utilities = $utilities;
		$this->findings  = $findings;
	}

	/**
	 * Run every database-related check.
	 *
	 * @param int $scan_id Owning report ID.
	 * @return int Findings recorded.
	 */
	public function scan( $scan_id ) {
		$count  = 0;
		$count += $this->scan_options( $scan_id );
		$count += $this->scan_post_content( $scan_id );
		$count += $this->detect_hidden_admins( $scan_id );

		return $count;
	}

	/**
	 * Suspicious content patterns shared by the options and post-content
	 * scans below.
	 *
	 * @return string
	 */
	private function suspicious_pattern() {
		return '/<script[^>]*>.*?(?:eval|unescape|fromCharCode|document\.write)\s*\(|<iframe[^>]+(?:display\s*:\s*none|width\s*=\s*["\']?0)|base64_decode\s*\(\s*[\'"][A-Za-z0-9+\/=]{80,}/is';
	}

	/**
	 * Scan autoloaded wp_options values for injected scripts, hidden
	 * iframes, or encoded payloads. Restricted to autoload='yes' rows
	 * because those load on every single request — a compromise there
	 * has the biggest blast radius and is also the most common target.
	 *
	 * @param int $scan_id Owning report ID.
	 * @return int Findings recorded.
	 */
	private function scan_options( $scan_id ) {
		global $wpdb;

		$rows = $wpdb->get_results(
			"SELECT option_id, option_name, option_value FROM {$wpdb->options} WHERE autoload = 'yes'" // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
		);

		$pattern = $this->suspicious_pattern();
		$count   = 0;

		foreach ( $rows as $row ) {
			if ( ! is_string( $row->option_value ) || '' === $row->option_value ) {
				continue;
			}

			if ( preg_match( $pattern, $row->option_value ) ) {
				$this->findings->record(
					array(
						'scan_id'     => $scan_id,
						'type'        => 'database',
						'severity'    => Findings::SEVERITY_CRITICAL,
						'file_path'   => 'wp_options:' . $row->option_name,
						'signature'   => 'suspicious_autoload_option',
						'description' => sprintf( __( 'Autoloaded option "%s" contains a hidden script/iframe injection or an encoded payload.', 'kloud101-sentinel' ), $row->option_name ),
					)
				);
				++$count;
			}
		}

		return $count;
	}

	/**
	 * Scan published/draft post content for the same class of injected
	 * script/iframe payloads. Limited to a sane batch size per run via
	 * a filter so this stays usable on sites with very large content
	 * tables — full coverage is achieved across successive scheduled
	 * scans rather than one giant query.
	 *
	 * @param int $scan_id Owning report ID.
	 * @return int Findings recorded.
	 */
	private function scan_post_content( $scan_id ) {
		global $wpdb;

		$limit = (int) apply_filters( 'kloud101_sentinel_db_scan_post_limit', 500 );

		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT ID, post_title, post_content FROM {$wpdb->posts} WHERE post_status IN ('publish','draft','pending','future') ORDER BY post_modified DESC LIMIT %d", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				$limit
			)
		);

		$pattern = $this->suspicious_pattern();
		$count   = 0;

		foreach ( $rows as $row ) {
			if ( preg_match( $pattern, $row->post_content ) ) {
				$this->findings->record(
					array(
						'scan_id'     => $scan_id,
						'type'        => 'database',
						'severity'    => Findings::SEVERITY_HIGH,
						'file_path'   => sprintf( 'wp_posts:%d', $row->ID ),
						'signature'   => 'suspicious_post_content',
						'description' => sprintf( __( 'Post "%1$s" (ID %2$d) contains a hidden script/iframe injection or an encoded payload.', 'kloud101-sentinel' ), $row->post_title, $row->ID ),
					)
				);
				++$count;
			}
		}

		return $count;
	}

	/**
	 * Cross-check the number of administrator-capable usermeta rows
	 * against the number of administrators WordPress itself reports via
	 * get_users(). A mismatch suggests a user account with
	 * administrator capabilities that has been hidden from the Users
	 * screen (e.g. via a corrupted/tampered user_status or a
	 * capabilities blob injected straight into wp_usermeta).
	 *
	 * @param int $scan_id Owning report ID.
	 * @return int Findings recorded.
	 */
	private function detect_hidden_admins( $scan_id ) {
		global $wpdb;

		$meta_key    = $wpdb->prefix . 'capabilities';
		$raw_count   = (int) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(*) FROM {$wpdb->usermeta} WHERE meta_key = %s AND meta_value LIKE %s", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				$meta_key,
				'%"administrator"%'
			)
		);

		$known_admins = count( get_users( array( 'role' => 'administrator', 'fields' => 'ID' ) ) );

		if ( $raw_count > $known_admins ) {
			$this->findings->record(
				array(
					'scan_id'     => $scan_id,
					'type'        => 'database',
					'severity'    => Findings::SEVERITY_CRITICAL,
					'file_path'   => 'wp_usermeta',
					'signature'   => 'hidden_administrator',
					'description' => sprintf(
						__( 'Found %1$d user(s) with administrator capabilities in the database, but only %2$d are visible via the standard Users API — a user account may have been tampered with to hide it.', 'kloud101-sentinel' ),
						$raw_count,
						$known_admins
					),
				)
			);

			return 1;
		}

		return 0;
	}
}
