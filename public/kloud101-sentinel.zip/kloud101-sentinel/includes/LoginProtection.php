<?php
/**
 * Brute-force login protection: attempt limiting, temporary lockouts,
 * permanent IP blacklist/whitelist, session monitoring, force logout,
 * password strength checks, and a Two-Factor Authentication extension
 * point.
 *
 * @package Kloud101Sentinel\Includes
 */

namespace Kloud101Sentinel\Includes;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class LoginProtection
 *
 * Rate limiting is IP-based (using k101_login_attempts as a rolling
 * window) rather than username-based, because username-based limiting
 * is trivially bypassed by an attacker rotating usernames, while IP
 * limiting still meaningfully slows down a single-source brute force
 * without requiring a CAPTCHA/2FA dependency to be useful out of the box.
 */
class LoginProtection {

	/**
	 * @var Logger
	 */
	private $logger;

	/**
	 * @var Utilities
	 */
	private $utilities;

	/**
	 * @var Findings
	 */
	private $findings;

	/**
	 * Constructor.
	 *
	 * @param Logger    $logger    Shared logger.
	 * @param Utilities $utilities Shared helpers.
	 * @param Findings  $findings  Shared findings repository.
	 */
	public function __construct( Logger $logger, Utilities $utilities, Findings $findings ) {
		$this->logger    = $logger;
		$this->utilities = $utilities;
		$this->findings  = $findings;
	}

	/**
	 * Register hooks.
	 *
	 * @param Loader $loader Shared hook loader.
	 */
	public function register( Loader $loader ) {
		$loader->add_filter( 'authenticate', $this, 'block_locked_out_ip', 1, 1 );
		$loader->add_action( 'wp_login_failed', $this, 'on_login_failed', 10, 2 );
		$loader->add_action( 'wp_login', $this, 'on_login_success', 10, 2 );
		$loader->add_filter( 'user_profile_update_errors', $this, 'check_password_strength', 10, 3 );
	}

	/**
	 * Fetch current plugin settings (with defaults filled in).
	 *
	 * @return array<string, mixed>
	 */
	private function settings() {
		return wp_parse_args( get_option( 'kloud101_sentinel_settings', array() ), Installer::default_settings() );
	}

	/**
	 * Short-circuit authentication entirely for a permanently
	 * blacklisted IP, or an IP currently inside its temporary lockout
	 * window. Whitelisted IPs always bypass this check.
	 *
	 * @param \WP_User|\WP_Error|null $user Value passed through the authenticate filter chain.
	 * @return \WP_User|\WP_Error|null
	 */
	public function block_locked_out_ip( $user ) {
		$ip       = Utilities::get_client_ip();
		$settings = $this->settings();

		if ( in_array( $ip, (array) $settings['login_whitelist'], true ) ) {
			return $user;
		}

		if ( in_array( $ip, (array) $settings['login_blacklist'], true ) ) {
			return new \WP_Error( 'kloud101_sentinel_blacklisted', __( '<strong>Error:</strong> Your IP address has been blocked.', 'kloud101-sentinel' ) );
		}

		$lockout_until = $this->get_lockout_expiry( $ip, (int) $settings['login_max_attempts'], (int) $settings['login_lockout_minutes'] );

		if ( $lockout_until > time() ) {
			$minutes_left = (int) ceil( ( $lockout_until - time() ) / MINUTE_IN_SECONDS );

			return new \WP_Error(
				'kloud101_sentinel_locked_out',
				sprintf(
					/* translators: %d: minutes remaining */
					__( '<strong>Error:</strong> Too many failed login attempts. Try again in %d minute(s).', 'kloud101-sentinel' ),
					$minutes_left
				)
			);
		}

		return $user;
	}

	/**
	 * Record a failed login attempt.
	 *
	 * @param string        $username Attempted username.
	 * @param \WP_Error|null $error   Authentication error (WP 5.6+).
	 */
	public function on_login_failed( $username, $error = null ) {
		global $wpdb;

		$ip = Utilities::get_client_ip();

		$wpdb->insert(
			$wpdb->prefix . 'k101_login_attempts',
			array(
				'ip_address' => $ip,
				'username'   => sanitize_user( $username ),
				'success'    => 0,
				'user_agent' => isset( $_SERVER['HTTP_USER_AGENT'] ) ? substr( sanitize_text_field( wp_unslash( $_SERVER['HTTP_USER_AGENT'] ) ), 0, 255 ) : '',
				'created_at' => current_time( 'mysql', true ),
			),
			array( '%s', '%s', '%d', '%s', '%s' )
		);

		$settings     = $this->settings();
		$recent_count = $this->count_recent_failures( $ip, (int) $settings['login_lockout_minutes'] );

		if ( $recent_count >= (int) $settings['login_max_attempts'] ) {
			$this->findings->record(
				array(
					'type'        => 'login',
					'severity'    => Findings::SEVERITY_HIGH,
					'file_path'   => '',
					'signature'   => 'brute_force_lockout',
					'description' => sprintf(
						/* translators: 1: IP address, 2: attempt count */
						__( 'IP %1$s locked out after %2$d failed login attempts.', 'kloud101-sentinel' ),
						$ip,
						$recent_count
					),
				)
			);

			$this->logger->warning( 'login_protection', sprintf( 'IP %s locked out after %d failed attempts.', $ip, $recent_count ) );

			/**
			 * Fires when an IP is locked out for brute-forcing logins —
			 * Notifications listens to this to email the administrator.
			 *
			 * @param string $ip    Offending IP address.
			 * @param int    $count Failed attempt count in the window.
			 */
			do_action( 'kloud101_sentinel_login_lockout', $ip, $recent_count );
		}
	}

	/**
	 * Clear the failure count for this IP on a successful login.
	 *
	 * @param string   $user_login Username that logged in.
	 * @param \WP_User $user       User object.
	 */
	public function on_login_success( $user_login, $user ) {
		$ip = Utilities::get_client_ip();

		global $wpdb;
		$wpdb->insert(
			$wpdb->prefix . 'k101_login_attempts',
			array(
				'ip_address' => $ip,
				'username'   => sanitize_user( $user_login ),
				'success'    => 1,
				'user_agent' => isset( $_SERVER['HTTP_USER_AGENT'] ) ? substr( sanitize_text_field( wp_unslash( $_SERVER['HTTP_USER_AGENT'] ) ), 0, 255 ) : '',
				'created_at' => current_time( 'mysql', true ),
			),
			array( '%s', '%s', '%d', '%s', '%s' )
		);

		/**
		 * Extension point for Two-Factor Authentication providers. No
		 * provider ships with the plugin; registering one here via the
		 * 'kloud101_sentinel_two_factor_providers' filter lets an addon
		 * (or a future Sentinel Cloud connector) require an additional
		 * challenge without modifying this class.
		 */
		$providers = apply_filters( 'kloud101_sentinel_two_factor_providers', array(), $user );

		if ( ! empty( $providers ) ) {
			do_action( 'kloud101_sentinel_two_factor_challenge', $user, $providers );
		}
	}

	/**
	 * Count failed login attempts from an IP within the lockout window.
	 *
	 * @param string $ip               IP address.
	 * @param int    $lockout_minutes  Window size in minutes.
	 * @return int
	 */
	private function count_recent_failures( $ip, $lockout_minutes ) {
		global $wpdb;

		return (int) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(*) FROM {$wpdb->prefix}k101_login_attempts WHERE ip_address = %s AND success = 0 AND created_at >= %s", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				$ip,
				gmdate( 'Y-m-d H:i:s', time() - ( max( 1, $lockout_minutes ) * MINUTE_IN_SECONDS ) )
			)
		);
	}

	/**
	 * Compute the timestamp until which an IP remains locked out, or 0
	 * if it is not currently locked out.
	 *
	 * @param string $ip              IP address.
	 * @param int    $max_attempts    Attempts allowed before lockout.
	 * @param int    $lockout_minutes Lockout duration in minutes.
	 * @return int Unix timestamp, or 0.
	 */
	private function get_lockout_expiry( $ip, $max_attempts, $lockout_minutes ) {
		global $wpdb;

		$last_failure = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT MAX(created_at) FROM {$wpdb->prefix}k101_login_attempts WHERE ip_address = %s AND success = 0", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				$ip
			)
		);

		if ( ! $last_failure ) {
			return 0;
		}

		$recent_count = $this->count_recent_failures( $ip, $lockout_minutes );

		if ( $recent_count < $max_attempts ) {
			return 0;
		}

		return strtotime( $last_failure . ' UTC' ) + ( $lockout_minutes * MINUTE_IN_SECONDS );
	}

	/**
	 * Force-terminate every active session for a user (e.g. after
	 * discovering a compromised account). Exposed for admin pages/
	 * remote-action handlers to call.
	 *
	 * @param int $user_id User ID.
	 */
	public function force_logout_user( $user_id ) {
		$sessions = \WP_Session_Tokens::get_instance( $user_id );
		$sessions->destroy_all();

		$this->logger->action( 'login_protection', sprintf( 'Force-logged-out all sessions for user ID %d.', $user_id ) );
	}

	/**
	 * Add an IP to the permanent blacklist.
	 *
	 * @param string $ip IP address.
	 */
	public function add_to_blacklist( $ip ) {
		$settings                    = get_option( 'kloud101_sentinel_settings', array() );
		$settings['login_blacklist'] = array_unique( array_merge( (array) ( $settings['login_blacklist'] ?? array() ), array( $ip ) ) );
		update_option( 'kloud101_sentinel_settings', $settings );

		$this->logger->action( 'login_protection', sprintf( 'IP %s added to permanent blacklist.', $ip ) );
	}

	/**
	 * Remove an IP from the permanent blacklist.
	 *
	 * @param string $ip IP address.
	 */
	public function remove_from_blacklist( $ip ) {
		$settings                    = get_option( 'kloud101_sentinel_settings', array() );
		$settings['login_blacklist'] = array_values( array_diff( (array) ( $settings['login_blacklist'] ?? array() ), array( $ip ) ) );
		update_option( 'kloud101_sentinel_settings', $settings );
	}

	/**
	 * Basic server-side password strength gate for profile updates.
	 * Requires at least 12 characters with a mix of upper/lower case,
	 * a digit, and a symbol — rejecting the change (rather than merely
	 * warning) if a new password is being set and fails the check.
	 *
	 * @param \WP_Error $errors WordPress errors object.
	 * @param bool      $update Whether this is an existing user being updated.
	 * @param \stdClass $user   User object being saved (by reference upstream).
	 * @return \WP_Error
	 */
	public function check_password_strength( $errors, $update, $user ) {
		if ( empty( $_POST['pass1'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Missing
			return $errors;
		}

		$password = (string) wp_unslash( $_POST['pass1'] ); // phpcs:ignore WordPress.Security.NonceVerification.Missing, WordPress.Security.ValidatedSanitizedInput.MissingUnslash

		$is_strong = strlen( $password ) >= 12
			&& preg_match( '/[a-z]/', $password )
			&& preg_match( '/[A-Z]/', $password )
			&& preg_match( '/[0-9]/', $password )
			&& preg_match( '/[^a-zA-Z0-9]/', $password );

		if ( ! $is_strong ) {
			$errors->add(
				'kloud101_sentinel_weak_password',
				__( '<strong>Error:</strong> Password must be at least 12 characters and include upper case, lower case, a number, and a symbol.', 'kloud101-sentinel' )
			);
		}

		return $errors;
	}
}
