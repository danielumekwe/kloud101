<?php
/**
 * Database schema and default-option installation/upgrade logic.
 *
 * @package Kloud101Sentinel\Includes
 */

namespace Kloud101Sentinel\Includes;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Installer
 *
 * Pure, side-effect-scoped installation routines. Kept separate from
 * Activator so the same table-creation logic can also run during a
 * version-upgrade request (via maybe_upgrade()), not only on the
 * WordPress `register_activation_hook`.
 */
class Installer {

	/**
	 * Create (or, via dbDelta, non-destructively update) every custom
	 * table the plugin needs for a single site.
	 */
	public static function create_tables() {
		global $wpdb;

		require_once ABSPATH . 'wp-admin/includes/upgrade.php';

		$charset_collate = $wpdb->get_charset_collate();
		$prefix           = $wpdb->prefix;

		$sql = array();

		$sql[] = "CREATE TABLE {$prefix}k101_findings (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			scan_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
			type VARCHAR(32) NOT NULL,
			severity VARCHAR(16) NOT NULL,
			file_path TEXT NULL,
			signature VARCHAR(191) NULL,
			description TEXT NULL,
			status VARCHAR(16) NOT NULL DEFAULT 'open',
			detected_at DATETIME NOT NULL,
			resolved_at DATETIME NULL,
			PRIMARY KEY  (id),
			KEY scan_id (scan_id),
			KEY type (type),
			KEY severity (severity),
			KEY status (status)
		) {$charset_collate};";

		$sql[] = "CREATE TABLE {$prefix}k101_logs (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			level VARCHAR(16) NOT NULL,
			source VARCHAR(64) NOT NULL,
			message TEXT NOT NULL,
			context LONGTEXT NULL,
			created_at DATETIME NOT NULL,
			PRIMARY KEY  (id),
			KEY level (level),
			KEY source (source),
			KEY created_at (created_at)
		) {$charset_collate};";

		$sql[] = "CREATE TABLE {$prefix}k101_login_attempts (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			ip_address VARCHAR(45) NOT NULL,
			username VARCHAR(191) NULL,
			success TINYINT(1) NOT NULL DEFAULT 0,
			user_agent VARCHAR(255) NULL,
			created_at DATETIME NOT NULL,
			PRIMARY KEY  (id),
			KEY ip_address (ip_address),
			KEY created_at (created_at)
		) {$charset_collate};";

		$sql[] = "CREATE TABLE {$prefix}k101_quarantine (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			original_path TEXT NOT NULL,
			quarantine_path TEXT NOT NULL,
			sha256 VARCHAR(64) NULL,
			file_size BIGINT UNSIGNED NOT NULL DEFAULT 0,
			reason VARCHAR(255) NULL,
			status VARCHAR(16) NOT NULL DEFAULT 'quarantined',
			quarantined_at DATETIME NOT NULL,
			restored_at DATETIME NULL,
			deleted_at DATETIME NULL,
			PRIMARY KEY  (id),
			KEY status (status)
		) {$charset_collate};";

		$sql[] = "CREATE TABLE {$prefix}k101_file_hashes (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			relative_path VARCHAR(500) NOT NULL,
			file_type VARCHAR(16) NOT NULL,
			sha256 VARCHAR(64) NOT NULL,
			file_size BIGINT UNSIGNED NOT NULL DEFAULT 0,
			mtime INT UNSIGNED NOT NULL DEFAULT 0,
			updated_at DATETIME NOT NULL,
			PRIMARY KEY  (id),
			UNIQUE KEY relative_path_type (relative_path(190), file_type),
			KEY file_type (file_type)
		) {$charset_collate};";

		$sql[] = "CREATE TABLE {$prefix}k101_reports (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			type VARCHAR(32) NOT NULL,
			summary LONGTEXT NULL,
			started_at DATETIME NOT NULL,
			finished_at DATETIME NULL,
			duration_seconds INT UNSIGNED NULL,
			PRIMARY KEY  (id),
			KEY type (type),
			KEY started_at (started_at)
		) {$charset_collate};";

		foreach ( $sql as $statement ) {
			dbDelta( $statement );
		}
	}

	/**
	 * Register the custom capability used to gate every admin page and
	 * AJAX handler, granting it to Administrator by default.
	 */
	public static function add_capabilities() {
		$role = get_role( 'administrator' );

		if ( $role && ! $role->has_cap( 'manage_kloud101_sentinel' ) ) {
			$role->add_cap( 'manage_kloud101_sentinel' );
		}
	}

	/**
	 * Seed default plugin settings if they do not already exist. Never
	 * overwrites an existing option (idempotent on repeated activation).
	 */
	public static function seed_default_options() {
		if ( false === get_option( 'kloud101_sentinel_settings' ) ) {
			add_option( 'kloud101_sentinel_settings', self::default_settings() );
		}

		if ( false === get_option( 'kloud101_sentinel_db_version' ) ) {
			add_option( 'kloud101_sentinel_db_version', KLOUD101_SENTINEL_DB_VERSION );
		}

		if ( false === get_option( 'kloud101_sentinel_activated_at' ) ) {
			add_option( 'kloud101_sentinel_activated_at', time() );
		}
	}

	/**
	 * Canonical default settings array. Also used by Settings::sanitize()
	 * to fill in any keys missing from submitted form data.
	 *
	 * @return array<string, mixed>
	 */
	public static function default_settings() {
		return array(
			'scan_frequency'            => 'daily',
			'scan_uploads_on_schedule'  => true,
			'enable_wordpress_org_lookups' => true,
			'email_notifications'      => true,
			'notification_email'       => get_option( 'admin_email' ),
			'login_max_attempts'       => 5,
			'login_lockout_minutes'    => 30,
			'login_whitelist'          => array(),
			'login_blacklist'          => array(),
			'firewall_enabled'         => true,
			'firewall_block_sqli'      => true,
			'firewall_block_xss'       => true,
			'firewall_block_traversal' => true,
			'firewall_block_bad_bots'  => true,
			'hardening_disable_xmlrpc'      => false,
			'hardening_disable_file_edit'   => false,
			'hardening_block_php_uploads'   => false,
			'hardening_hide_wp_version'      => true,
			'hardening_disable_dir_browsing' => false,
			'hardening_restrict_rest_api'    => false,
			'log_retention_days'       => 90,
			'remove_data_on_uninstall' => false,
		);
	}

	/**
	 * Run on every request (cheap version comparison) to catch schema
	 * changes shipped in a plugin update without requiring a full
	 * deactivate/reactivate cycle from the site owner.
	 */
	public static function maybe_upgrade() {
		$installed_version = get_option( 'kloud101_sentinel_db_version' );

		if ( $installed_version === KLOUD101_SENTINEL_DB_VERSION ) {
			return;
		}

		self::create_tables();
		self::add_capabilities();
		update_option( 'kloud101_sentinel_db_version', KLOUD101_SENTINEL_DB_VERSION );
	}
}
