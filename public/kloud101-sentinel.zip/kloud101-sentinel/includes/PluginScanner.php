<?php
/**
 * Plugin inventory and risk analysis: abandoned, vulnerable, unknown,
 * duplicate, hidden, and recently-modified plugin detection.
 *
 * @package Kloud101Sentinel\Includes
 */

namespace Kloud101Sentinel\Includes;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class PluginScanner
 *
 * Everything here operates on plugin *metadata* (headers, directory
 * layout, file modification times), not file content — content-level
 * backdoor detection for plugin PHP files is IntegrityScanner's
 * (hash drift) and MalwareScanner's (signatures) job, both of which
 * already cover wp-content/plugins.
 */
class PluginScanner {

	/**
	 * @var Logger
	 */
	private $logger;

	/**
	 * @var Utilities
	 */
	private $utilities;

	/**
	 * @var Findings
	 */
	private $findings;

	/**
	 * Constructor.
	 *
	 * @param Logger    $logger    Shared logger.
	 * @param Utilities $utilities Shared helpers.
	 * @param Findings  $findings  Shared findings repository.
	 */
	public function __construct( Logger $logger, Utilities $utilities, Findings $findings ) {
		$this->logger    = $logger;
		$this->utilities = $utilities;
		$this->findings  = $findings;
	}

	/**
	 * Run every plugin-related check.
	 *
	 * @param int $scan_id Owning report ID.
	 * @return int Number of findings recorded.
	 */
	public function scan( $scan_id ) {
		if ( ! function_exists( 'get_plugins' ) ) {
			require_once ABSPATH . 'wp-admin/includes/plugin.php';
		}

		$count  = 0;
		$count += $this->detect_duplicates( $scan_id );
		$count += $this->detect_hidden_plugins( $scan_id );
		$count += $this->detect_recently_modified( $scan_id );
		$count += $this->detect_known_vulnerable( $scan_id );
		$count += $this->detect_abandoned( $scan_id );

		return $count;
	}

	/**
	 * Structured inventory used by the Dashboard/Reports (not itself a
	 * source of findings).
	 *
	 * @return array<string, mixed>
	 */
	public function get_inventory() {
		if ( ! function_exists( 'get_plugins' ) ) {
			require_once ABSPATH . 'wp-admin/includes/plugin.php';
		}

		$all_plugins    = get_plugins();
		$active_plugins = get_option( 'active_plugins', array() );

		return array(
			'total'    => count( $all_plugins ),
			'active'   => count( $active_plugins ),
			'inactive' => count( $all_plugins ) - count( $active_plugins ),
			'plugins'  => $all_plugins,
		);
	}

	/**
	 * Flag multiple installed plugins that declare the same "Name"
	 * header in different folders (e.g. a legitimate "Akismet" next to
	 * a folder named "akismet-pro" impersonating it).
	 *
	 * @param int $scan_id Owning report ID.
	 * @return int Findings recorded.
	 */
	private function detect_duplicates( $scan_id ) {
		$all_plugins = get_plugins();
		$by_name     = array();

		foreach ( $all_plugins as $plugin_file => $data ) {
			$name = trim( $data['Name'] );

			if ( '' === $name ) {
				continue;
			}

			$by_name[ $name ][] = $plugin_file;
		}

		$count = 0;

		foreach ( $by_name as $name => $files ) {
			if ( count( $files ) > 1 ) {
				$this->findings->record(
					array(
						'scan_id'     => $scan_id,
						'type'        => 'plugin',
						'severity'    => Findings::SEVERITY_MEDIUM,
						'file_path'   => implode( ', ', $files ),
						'signature'   => 'duplicate_plugin_name',
						'description' => sprintf( __( 'Multiple installed plugins declare the same name "%s": %s', 'kloud101-sentinel' ), $name, implode( ', ', $files ) ),
					)
				);
				++$count;
			}
		}

		return $count;
	}

	/**
	 * Flag directories inside wp-content/plugins that WordPress itself
	 * does not recognize as a valid plugin (no file with a readable
	 * plugin header) but that still contain PHP — these are invisible
	 * to the Plugins screen entirely, which makes them a favorite
	 * hiding spot for planted backdoors.
	 *
	 * @param int $scan_id Owning report ID.
	 * @return int Findings recorded.
	 */
	private function detect_hidden_plugins( $scan_id ) {
		$known_dirs = array();

		foreach ( array_keys( get_plugins() ) as $plugin_file ) {
			$parts = explode( '/', $plugin_file );
			if ( count( $parts ) > 1 ) {
				$known_dirs[ $parts[0] ] = true;
			}
		}

		$count = 0;

		if ( ! is_dir( WP_PLUGIN_DIR ) ) {
			return $count;
		}

		foreach ( scandir( WP_PLUGIN_DIR ) as $entry ) {
			if ( '.' === $entry || '..' === $entry || ! is_dir( WP_PLUGIN_DIR . '/' . $entry ) ) {
				continue;
			}

			if ( isset( $known_dirs[ $entry ] ) ) {
				continue;
			}

			$has_php = false;
			foreach ( Utilities::iterate_files( WP_PLUGIN_DIR . '/' . $entry, array( 'php' ) ) as $unused_path ) {
				$has_php = true;
				break;
			}

			if ( $has_php ) {
				$this->findings->record(
					array(
						'scan_id'     => $scan_id,
						'type'        => 'plugin',
						'severity'    => Findings::SEVERITY_HIGH,
						'file_path'   => 'wp-content/plugins/' . $entry,
						'signature'   => 'hidden_plugin_directory',
						'description' => sprintf( __( 'Directory "%s" in wp-content/plugins contains PHP files but has no recognizable plugin header — it is invisible on the Plugins screen.', 'kloud101-sentinel' ), $entry ),
					)
				);
				++$count;
			}
		}

		return $count;
	}

	/**
	 * Compare each plugin file's mtime against the last recorded
	 * snapshot (stored as a site option, not a DB table, since it is a
	 * simple path => timestamp map). First run silently establishes the
	 * baseline. A file whose mtime advanced without a corresponding
	 * plugin version bump is suspicious — legitimate updates change the
	 * version header at the same time.
	 *
	 * @param int $scan_id Owning report ID.
	 * @return int Findings recorded.
	 */
	private function detect_recently_modified( $scan_id ) {
		$option_key   = 'kloud101_sentinel_plugin_mtimes';
		$previous     = get_option( $option_key, array() );
		$current      = array();
		$count        = 0;
		$all_versions = wp_list_pluck( get_plugins(), 'Version' );

		foreach ( array_keys( get_plugins() ) as $plugin_file ) {
			$plugin_dir = dirname( WP_PLUGIN_DIR . '/' . $plugin_file );

			foreach ( Utilities::iterate_files( $plugin_dir, array( 'php' ) ) as $absolute_path ) {
				$relative       = str_replace( ABSPATH, '', $absolute_path );
				$mtime          = (int) filemtime( $absolute_path );
				$current[ $relative ] = $mtime;

				if ( ! empty( $previous ) && isset( $previous[ $relative ] ) && $previous[ $relative ] !== $mtime ) {
					$version_unchanged = isset( $all_versions[ $plugin_file ] );

					if ( $version_unchanged ) {
						$this->findings->record(
							array(
								'scan_id'     => $scan_id,
								'type'        => 'plugin',
								'severity'    => Findings::SEVERITY_MEDIUM,
								'file_path'   => $relative,
								'signature'   => 'plugin_file_modified',
								'description' => sprintf( __( 'Plugin file "%s" was modified without an accompanying plugin update.', 'kloud101-sentinel' ), $relative ),
							)
						);
						++$count;
					}
				}
			}
		}

		if ( ! empty( $previous ) ) {
			update_option( $option_key, $current, false );
		} else {
			add_option( $option_key, $current, '', false );
		}

		return $count;
	}

	/**
	 * Check installed plugin versions against a small, filterable list
	 * of known-vulnerable slug => affected-version-range entries. This
	 * plugin ships no live vulnerability feed; the filter exists so a
	 * site owner (or a future Kloud101 Sentinel Cloud connector) can
	 * supply an up-to-date list without changing this class.
	 *
	 * @param int $scan_id Owning report ID.
	 * @return int Findings recorded.
	 */
	private function detect_known_vulnerable( $scan_id ) {
		/**
		 * Filters the known-vulnerable plugin list.
		 *
		 * @param array $vulnerable Map of slug => array{max_version: string, advisory: string}.
		 */
		$vulnerable = apply_filters( 'kloud101_sentinel_known_vulnerable_plugins', array() );

		if ( empty( $vulnerable ) ) {
			return 0;
		}

		$count = 0;

		foreach ( get_plugins() as $plugin_file => $data ) {
			$slug = strtok( $plugin_file, '/' );

			if ( ! isset( $vulnerable[ $slug ] ) ) {
				continue;
			}

			$entry = $vulnerable[ $slug ];

			if ( version_compare( $data['Version'], $entry['max_version'], '<=' ) ) {
				$this->findings->record(
					array(
						'scan_id'     => $scan_id,
						'type'        => 'plugin',
						'severity'    => Findings::SEVERITY_HIGH,
						'file_path'   => $plugin_file,
						'signature'   => 'known_vulnerable_plugin',
						'description' => sprintf(
							__( '%1$s v%2$s matches a known-vulnerable version range (<= %3$s). %4$s', 'kloud101-sentinel' ),
							$data['Name'],
							$data['Version'],
							$entry['max_version'],
							isset( $entry['advisory'] ) ? $entry['advisory'] : ''
						),
					)
				);
				++$count;
			}
		}

		return $count;
	}

	/**
	 * Best-effort abandonment check via the WordPress.org plugins API —
	 * gated behind the "WordPress.org lookups" setting (Settings >
	 * Scanning), which the administrator must explicitly opt into, and
	 * skipped silently if disabled or unreachable. A plugin not updated
	 * in 2+ years is flagged as "abandoned" (low severity — a hygiene
	 * note, not a confirmed vulnerability).
	 *
	 * @param int $scan_id Owning report ID.
	 * @return int Findings recorded.
	 */
	private function detect_abandoned( $scan_id ) {
		$settings = wp_parse_args( get_option( 'kloud101_sentinel_settings', array() ), Installer::default_settings() );

		if ( empty( $settings['enable_wordpress_org_lookups'] ) ) {
			return 0;
		}

		if ( ! apply_filters( 'kloud101_sentinel_enable_wordpress_org_lookups', true ) ) {
			return 0;
		}

		$count = 0;

		foreach ( array_keys( get_plugins() ) as $plugin_file ) {
			$slug = strtok( $plugin_file, '/' );

			// Only meaningful for plugins installed from the .org repo;
			// skip anything living outside its own slug-named directory.
			if ( false === strpos( $plugin_file, '/' ) ) {
				continue;
			}

			$response = wp_remote_post(
				'https://api.wordpress.org/plugins/info/1.2/',
				array(
					'timeout' => 5,
					'body'    => array(
						'action'  => 'plugin_information',
						'request' => serialize( (object) array( 'slug' => $slug, 'fields' => array( 'last_updated' => true ) ) ), // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.serialize_serialize
					),
				)
			);

			if ( is_wp_error( $response ) || 200 !== (int) wp_remote_retrieve_response_code( $response ) ) {
				continue;
			}

			$body = json_decode( wp_remote_retrieve_body( $response ), true );

			if ( empty( $body['last_updated'] ) ) {
				continue;
			}

			$last_updated = strtotime( $body['last_updated'] );

			if ( false !== $last_updated && $last_updated < ( time() - ( 2 * YEAR_IN_SECONDS ) ) ) {
				$this->findings->record(
					array(
						'scan_id'     => $scan_id,
						'type'        => 'plugin',
						'severity'    => Findings::SEVERITY_LOW,
						'file_path'   => $plugin_file,
						'signature'   => 'abandoned_plugin',
						'description' => sprintf( __( 'Plugin "%1$s" has not been updated on WordPress.org since %2$s and may be abandoned.', 'kloud101-sentinel' ), $slug, $body['last_updated'] ),
					)
				);
				++$count;
			}
		}

		return $count;
	}
}
