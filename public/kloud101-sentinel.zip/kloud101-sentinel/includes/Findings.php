<?php
/**
 * Shared repository for scan findings across every scanner type
 * (malware, integrity, upload, plugin, theme, cron, database, user).
 *
 * @package Kloud101Sentinel\Includes
 */

namespace Kloud101Sentinel\Includes;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Findings
 *
 * A single table (`k101_findings`) backs every scanner so the
 * dashboard, reports, and severity scoring only ever have to query one
 * place. Individual scanners never touch $wpdb for findings directly —
 * they call record() here, keeping the schema and any future migration
 * of it in exactly one class.
 */
class Findings {

	const SEVERITY_CRITICAL = 'critical';
	const SEVERITY_HIGH     = 'high';
	const SEVERITY_MEDIUM   = 'medium';
	const SEVERITY_LOW      = 'low';

	const STATUS_OPEN        = 'open';
	const STATUS_RESOLVED    = 'resolved';
	const STATUS_IGNORED     = 'ignored';
	const STATUS_QUARANTINED = 'quarantined';

	/**
	 * Record a new finding.
	 *
	 * @param array $data {
	 *     @type int    $scan_id     Owning scan/report ID. 0 if ad-hoc.
	 *     @type string $type        Scanner type: malware|integrity|upload|plugin|theme|cron|database|user.
	 *     @type string $severity    One of the SEVERITY_* constants.
	 *     @type string $file_path   Relative or absolute file path, if applicable.
	 *     @type string $signature   Signature/rule identifier that matched.
	 *     @type string $description Human-readable explanation.
	 * }
	 * @return int Finding ID.
	 */
	public function record( array $data ) {
		global $wpdb;

		$defaults = array(
			'scan_id'     => 0,
			'type'        => 'malware',
			'severity'    => self::SEVERITY_MEDIUM,
			'file_path'   => '',
			'signature'   => '',
			'description' => '',
		);
		$data     = wp_parse_args( $data, $defaults );

		$wpdb->insert(
			$wpdb->prefix . 'k101_findings',
			array(
				'scan_id'     => (int) $data['scan_id'],
				'type'        => $data['type'],
				'severity'    => $data['severity'],
				'file_path'   => $data['file_path'],
				'signature'   => $data['signature'],
				'description' => $data['description'],
				'status'      => self::STATUS_OPEN,
				'detected_at' => current_time( 'mysql', true ),
			),
			array( '%d', '%s', '%s', '%s', '%s', '%s', '%s', '%s' )
		);

		$id = (int) $wpdb->insert_id;

		/**
		 * Fires whenever any scanner records a finding, regardless of
		 * type — Notifications listens here so every scanner gets
		 * admin-notice/email coverage without registering its own hook.
		 *
		 * @param int   $id   New finding ID.
		 * @param array $data Normalized finding data (see record()'s docblock).
		 */
		do_action( 'kloud101_sentinel_finding_recorded', $id, $data );

		return $id;
	}

	/**
	 * Mark a finding resolved (e.g. file was quarantined or the
	 * underlying issue was fixed).
	 *
	 * @param int    $id     Finding ID.
	 * @param string $status Target status. Default 'resolved'.
	 */
	public function set_status( $id, $status = self::STATUS_RESOLVED ) {
		global $wpdb;

		$wpdb->update(
			$wpdb->prefix . 'k101_findings',
			array(
				'status'      => $status,
				'resolved_at' => current_time( 'mysql', true ),
			),
			array( 'id' => $id ),
			array( '%s', '%s' ),
			array( '%d' )
		);
	}

	/**
	 * List findings with optional filters.
	 *
	 * @param array $args {
	 *     @type string $type     Restrict to one scanner type.
	 *     @type string $severity Restrict to one severity.
	 *     @type string $status   Restrict to one status. Default 'open'.
	 *     @type int    $scan_id  Restrict to one owning report/scan ID.
	 *     @type int    $paged    1-indexed page number.
	 *     @type int    $per_page Rows per page.
	 * }
	 * @return array{rows: array<int, object>, total: int}
	 */
	public function list_findings( array $args = array() ) {
		global $wpdb;

		$args = wp_parse_args(
			$args,
			array(
				'type'     => '',
				'severity' => '',
				'status'   => '',
				'scan_id'  => 0,
				'paged'    => 1,
				'per_page' => 20,
			)
		);

		$where  = array( '1=1' );
		$params = array();

		foreach ( array( 'type', 'severity', 'status' ) as $column ) {
			if ( ! empty( $args[ $column ] ) ) {
				$where[]  = "{$column} = %s"; // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				$params[] = $args[ $column ];
			}
		}

		if ( ! empty( $args['scan_id'] ) ) {
			$where[]  = 'scan_id = %d';
			$params[] = (int) $args['scan_id'];
		}

		$where_sql = implode( ' AND ', $where );
		$table     = $wpdb->prefix . 'k101_findings';
		$offset    = max( 0, ( (int) $args['paged'] - 1 ) * (int) $args['per_page'] );

		$count_sql = "SELECT COUNT(*) FROM {$table} WHERE {$where_sql}"; // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$total     = (int) ( empty( $params ) ? $wpdb->get_var( $count_sql ) : $wpdb->get_var( $wpdb->prepare( $count_sql, $params ) ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.PreparedSQL.NotPrepared

		$rows_sql   = "SELECT * FROM {$table} WHERE {$where_sql} ORDER BY detected_at DESC, id DESC LIMIT %d OFFSET %d"; // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$row_params = array_merge( $params, array( (int) $args['per_page'], $offset ) );

		return array(
			'rows'  => (array) $wpdb->get_results( $wpdb->prepare( $rows_sql, $row_params ) ), // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
			'total' => $total,
		);
	}

	/**
	 * Count open findings grouped by severity — powers the dashboard's
	 * "Critical / High / Medium / Low" cards and overall score.
	 *
	 * @return array<string, int>
	 */
	public function counts_by_severity() {
		global $wpdb;

		$table   = $wpdb->prefix . 'k101_findings';
		$results = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT severity, COUNT(*) as total FROM {$table} WHERE status = %s GROUP BY severity", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				self::STATUS_OPEN
			)
		);

		$counts = array(
			self::SEVERITY_CRITICAL => 0,
			self::SEVERITY_HIGH     => 0,
			self::SEVERITY_MEDIUM   => 0,
			self::SEVERITY_LOW      => 0,
		);

		foreach ( $results as $row ) {
			if ( isset( $counts[ $row->severity ] ) ) {
				$counts[ $row->severity ] = (int) $row->total;
			}
		}

		return $counts;
	}

	/**
	 * Compute an overall 0-100 security score from open finding counts.
	 * Weighted so a single critical finding drags the score down hard,
	 * matching how an administrator would intuitively rate "one active
	 * backdoor" vs. "a dozen low-severity hardening suggestions".
	 *
	 * @return int
	 */
	public function calculate_security_score() {
		$counts = $this->counts_by_severity();

		$penalty = ( $counts[ self::SEVERITY_CRITICAL ] * 25 )
			+ ( $counts[ self::SEVERITY_HIGH ] * 12 )
			+ ( $counts[ self::SEVERITY_MEDIUM ] * 5 )
			+ ( $counts[ self::SEVERITY_LOW ] * 2 );

		return (int) max( 0, 100 - $penalty );
	}

	/**
	 * Total number of open findings (used for the "Active Threats" card).
	 *
	 * @return int
	 */
	public function count_open() {
		global $wpdb;

		return (int) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(*) FROM {$wpdb->prefix}k101_findings WHERE status = %s", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				self::STATUS_OPEN
			)
		);
	}
}
