<?php
/**
 * File quarantine engine: isolates dangerous files without ever
 * deleting them outright, and supports restoring or permanently
 * deleting them later under administrator control.
 *
 * @package Kloud101Sentinel\Includes
 */

namespace Kloud101Sentinel\Includes;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Quarantine
 *
 * Design invariant: nothing in this plugin ever calls unlink() on a
 * suspect file directly. Every scanner that wants a file removed from
 * its live location routes through quarantine_file(), which moves
 * (never copies-then-deletes-original silently) the file into a
 * locked-down holding directory and records enough metadata to restore
 * it byte-for-byte later.
 */
class Quarantine {

	/**
	 * @var Logger
	 */
	private $logger;

	/**
	 * @var Utilities
	 */
	private $utilities;

	/**
	 * @var Findings
	 */
	private $findings;

	const STATUS_QUARANTINED = 'quarantined';
	const STATUS_RESTORED    = 'restored';
	const STATUS_DELETED     = 'deleted';

	/**
	 * Constructor.
	 *
	 * @param Logger    $logger    Shared logger.
	 * @param Utilities $utilities Shared helpers.
	 * @param Findings  $findings  Shared findings repository.
	 */
	public function __construct( Logger $logger, Utilities $utilities, Findings $findings ) {
		$this->logger    = $logger;
		$this->utilities = $utilities;
		$this->findings  = $findings;
	}

	/**
	 * Register WordPress hooks. Quarantine itself is a passive engine
	 * invoked by other scanners, but it hooks admin_init once to ensure
	 * the holding directory still exists/is locked down even if it was
	 * deleted out-of-band (e.g. by a hosting backup restore).
	 *
	 * @param Loader $loader Shared hook loader.
	 */
	public function register( Loader $loader ) {
		$loader->add_action( 'admin_init', $this, 'ensure_directory_locked_down' );
	}

	/**
	 * Recreate the quarantine directory and its deny rules if missing.
	 */
	public function ensure_directory_locked_down() {
		if ( ! file_exists( KLOUD101_SENTINEL_QUARANTINE_DIR ) ) {
			wp_mkdir_p( KLOUD101_SENTINEL_QUARANTINE_DIR );
		}

		$index = KLOUD101_SENTINEL_QUARANTINE_DIR . 'index.php';
		if ( ! file_exists( $index ) ) {
			file_put_contents( $index, "<?php\n// Silence is golden.\n" ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents
		}

		$htaccess = KLOUD101_SENTINEL_QUARANTINE_DIR . '.htaccess';
		if ( ! file_exists( $htaccess ) ) {
			file_put_contents( $htaccess, "Require all denied\nDeny from all\n" ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents
		}
	}

	/**
	 * Move a file from its live location into quarantine.
	 *
	 * @param string $absolute_path Absolute path of the offending file.
	 * @param string $reason        Human-readable reason (finding summary).
	 * @param string $type          Origin scanner, e.g. 'malware', 'upload'.
	 * @param int    $finding_id    Optional linked k101_findings row to mark quarantined.
	 * @return int|\WP_Error Quarantine record ID, or WP_Error on failure.
	 */
	public function quarantine_file( $absolute_path, $reason, $type = 'malware', $finding_id = 0 ) {
		global $wpdb;

		if ( ! is_file( $absolute_path ) || ! is_readable( $absolute_path ) ) {
			return new \WP_Error( 'k101_missing_file', __( 'File does not exist or is not readable.', 'kloud101-sentinel' ) );
		}

		// Never allow the quarantine directory itself, or anything
		// outside WP_CONTENT_DIR/ABSPATH, to be "quarantined" — that
		// would either be a no-op loop or an attempt to move something
		// outside the plugin's intended blast radius.
		if ( ! Utilities::is_path_within( $absolute_path, ABSPATH ) ) {
			return new \WP_Error( 'k101_out_of_scope', __( 'File is outside the WordPress installation and cannot be quarantined.', 'kloud101-sentinel' ) );
		}

		$this->ensure_directory_locked_down();

		$hash          = Utilities::hash_file( $absolute_path );
		$file_size     = filesize( $absolute_path );
		$unique_name   = gmdate( 'Ymd-His' ) . '-' . Utilities::random_token( 6 ) . '.quarantined';
		$quarantine_to = KLOUD101_SENTINEL_QUARANTINE_DIR . $unique_name;

		$filesystem = Utilities::get_filesystem();
		$moved      = $filesystem
			? $filesystem->move( $absolute_path, $quarantine_to, true )
			: @rename( $absolute_path, $quarantine_to ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged

		if ( ! $moved ) {
			$this->logger->error( 'quarantine', 'Failed to move file to quarantine', array( 'path' => $absolute_path ) );

			return new \WP_Error( 'k101_move_failed', __( 'Could not move the file into quarantine (check filesystem permissions).', 'kloud101-sentinel' ) );
		}

		$relative_path = str_replace( ABSPATH, '', $absolute_path );

		$wpdb->insert(
			$wpdb->prefix . 'k101_quarantine',
			array(
				'original_path'   => $relative_path,
				'quarantine_path' => $unique_name,
				'sha256'          => $hash,
				'file_size'       => (int) $file_size,
				'reason'          => $reason,
				'status'          => self::STATUS_QUARANTINED,
				'quarantined_at'  => current_time( 'mysql', true ),
			),
			array( '%s', '%s', '%s', '%d', '%s', '%s', '%s' )
		);

		$id = (int) $wpdb->insert_id;

		if ( $finding_id > 0 ) {
			$this->findings->set_status( $finding_id, Findings::STATUS_QUARANTINED );
		}

		$this->logger->action(
			'quarantine',
			sprintf( 'Quarantined file: %s', $relative_path ),
			array(
				'id'     => $id,
				'type'   => $type,
				'reason' => $reason,
				'sha256' => $hash,
			)
		);

		return $id;
	}

	/**
	 * Restore a previously quarantined file back to its original path.
	 *
	 * @param int  $id    Quarantine record ID.
	 * @param bool $force Overwrite an existing file at the destination.
	 * @return true|\WP_Error
	 */
	public function restore( $id, $force = false ) {
		global $wpdb;

		$record = $this->get( $id );

		if ( ! $record ) {
			return new \WP_Error( 'k101_not_found', __( 'Quarantine record not found.', 'kloud101-sentinel' ) );
		}

		if ( self::STATUS_QUARANTINED !== $record->status ) {
			return new \WP_Error( 'k101_invalid_status', __( 'This item is not currently quarantined.', 'kloud101-sentinel' ) );
		}

		$source      = KLOUD101_SENTINEL_QUARANTINE_DIR . $record->quarantine_path;
		$destination = ABSPATH . ltrim( $record->original_path, '/\\' );

		if ( ! is_file( $source ) ) {
			return new \WP_Error( 'k101_missing_source', __( 'Quarantined file is missing from disk.', 'kloud101-sentinel' ) );
		}

		if ( file_exists( $destination ) && ! $force ) {
			return new \WP_Error( 'k101_destination_exists', __( 'A file already exists at the original location. Restore with force to overwrite.', 'kloud101-sentinel' ) );
		}

		wp_mkdir_p( dirname( $destination ) );

		$filesystem = Utilities::get_filesystem();
		$moved      = $filesystem
			? $filesystem->move( $source, $destination, true )
			: @rename( $source, $destination ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged

		if ( ! $moved ) {
			return new \WP_Error( 'k101_restore_failed', __( 'Could not restore the file (check filesystem permissions).', 'kloud101-sentinel' ) );
		}

		$wpdb->update(
			$wpdb->prefix . 'k101_quarantine',
			array(
				'status'      => self::STATUS_RESTORED,
				'restored_at' => current_time( 'mysql', true ),
			),
			array( 'id' => $id ),
			array( '%s', '%s' ),
			array( '%d' )
		);

		$this->logger->action( 'quarantine', sprintf( 'Restored file: %s', $record->original_path ), array( 'id' => $id ) );

		return true;
	}

	/**
	 * Permanently delete a quarantined file's isolated copy.
	 *
	 * @param int $id Quarantine record ID.
	 * @return true|\WP_Error
	 */
	public function delete_permanently( $id ) {
		global $wpdb;

		$record = $this->get( $id );

		if ( ! $record ) {
			return new \WP_Error( 'k101_not_found', __( 'Quarantine record not found.', 'kloud101-sentinel' ) );
		}

		$path = KLOUD101_SENTINEL_QUARANTINE_DIR . $record->quarantine_path;

		if ( is_file( $path ) ) {
			@unlink( $path ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
		}

		$wpdb->update(
			$wpdb->prefix . 'k101_quarantine',
			array(
				'status'     => self::STATUS_DELETED,
				'deleted_at' => current_time( 'mysql', true ),
			),
			array( 'id' => $id ),
			array( '%s', '%s' ),
			array( '%d' )
		);

		$this->logger->action( 'quarantine', sprintf( 'Permanently deleted quarantined file: %s', $record->original_path ), array( 'id' => $id ) );

		return true;
	}

	/**
	 * Fetch a single quarantine record.
	 *
	 * @param int $id Record ID.
	 * @return object|null
	 */
	public function get( $id ) {
		global $wpdb;

		return $wpdb->get_row(
			$wpdb->prepare( "SELECT * FROM {$wpdb->prefix}k101_quarantine WHERE id = %d", $id ) // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		);
	}

	/**
	 * List quarantine records, optionally filtered by status.
	 *
	 * @param array $args {
	 *     @type string $status   Filter by status. Empty = all.
	 *     @type int    $paged    1-indexed page number.
	 *     @type int    $per_page Rows per page.
	 * }
	 * @return array{rows: array<int, object>, total: int}
	 */
	public function list_records( array $args = array() ) {
		global $wpdb;

		$args   = wp_parse_args( $args, array( 'status' => '', 'paged' => 1, 'per_page' => 20 ) );
		$table  = $wpdb->prefix . 'k101_quarantine';
		$offset = max( 0, ( (int) $args['paged'] - 1 ) * (int) $args['per_page'] );

		if ( ! empty( $args['status'] ) ) {
			$total = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$table} WHERE status = %s", $args['status'] ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			$rows  = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$table} WHERE status = %s ORDER BY id DESC LIMIT %d OFFSET %d", $args['status'], (int) $args['per_page'], $offset ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		} else {
			$total = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$table}" ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
			$rows  = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$table} ORDER BY id DESC LIMIT %d OFFSET %d", (int) $args['per_page'], $offset ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		}

		return array(
			'rows'  => $rows ? $rows : array(),
			'total' => $total,
		);
	}

	/**
	 * Count currently quarantined files (used by the dashboard card).
	 *
	 * @return int
	 */
	public function count_active() {
		global $wpdb;

		return (int) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(*) FROM {$wpdb->prefix}k101_quarantine WHERE status = %s", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				self::STATUS_QUARANTINED
			)
		);
	}
}
