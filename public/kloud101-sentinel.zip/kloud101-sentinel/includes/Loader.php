<?php
/**
 * Central WordPress hook registry.
 *
 * @package Kloud101Sentinel\Includes
 */

namespace Kloud101Sentinel\Includes;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Loader
 *
 * Every feature module receives this object and calls add_action()/
 * add_filter() on it instead of calling the WordPress functions
 * directly. Centralizing registration means:
 *
 *  - the whole hook map for the plugin can be inspected/debugged in one
 *    place (see get_actions()/get_filters()),
 *  - modules stay unit-testable without a loaded WordPress instance,
 *    since registering "I want to hook X" is just an array push until
 *    run() is called.
 */
class Loader {

	/**
	 * Registered actions awaiting attachment to WordPress.
	 *
	 * @var array<int, array<string, mixed>>
	 */
	protected $actions = array();

	/**
	 * Registered filters awaiting attachment to WordPress.
	 *
	 * @var array<int, array<string, mixed>>
	 */
	protected $filters = array();

	/**
	 * Queue an action.
	 *
	 * @param string   $hook          WordPress action name.
	 * @param object   $component     Object the callback lives on.
	 * @param string   $callback      Method name on $component.
	 * @param int      $priority      Hook priority. Default 10.
	 * @param int      $accepted_args Number of accepted args. Default 1.
	 */
	public function add_action( $hook, $component, $callback, $priority = 10, $accepted_args = 1 ) {
		$this->actions = $this->add( $this->actions, $hook, $component, $callback, $priority, $accepted_args );
	}

	/**
	 * Queue a filter.
	 *
	 * @param string $hook          WordPress filter name.
	 * @param object $component     Object the callback lives on.
	 * @param string $callback      Method name on $component.
	 * @param int    $priority      Hook priority. Default 10.
	 * @param int    $accepted_args Number of accepted args. Default 1.
	 */
	public function add_filter( $hook, $component, $callback, $priority = 10, $accepted_args = 1 ) {
		$this->filters = $this->add( $this->filters, $hook, $component, $callback, $priority, $accepted_args );
	}

	/**
	 * Shared implementation for add_action()/add_filter().
	 *
	 * @param array  $hooks         Existing collection (actions or filters).
	 * @param string $hook          Hook name.
	 * @param object $component     Object the callback lives on.
	 * @param string $callback      Method name.
	 * @param int    $priority      Priority.
	 * @param int    $accepted_args Accepted argument count.
	 * @return array Updated collection.
	 */
	private function add( $hooks, $hook, $component, $callback, $priority, $accepted_args ) {
		$hooks[] = array(
			'hook'          => $hook,
			'component'     => $component,
			'callback'      => $callback,
			'priority'      => $priority,
			'accepted_args' => $accepted_args,
		);

		return $hooks;
	}

	/**
	 * Attach every queued action/filter to WordPress. Called once, at
	 * the end of the plugin's bootstrap.
	 */
	public function run() {
		foreach ( $this->filters as $hook ) {
			add_filter( $hook['hook'], array( $hook['component'], $hook['callback'] ), $hook['priority'], $hook['accepted_args'] );
		}

		foreach ( $this->actions as $hook ) {
			add_action( $hook['hook'], array( $hook['component'], $hook['callback'] ), $hook['priority'], $hook['accepted_args'] );
		}
	}

	/**
	 * Expose the queued actions (used by Site Health / debug tooling).
	 *
	 * @return array<int, array<string, mixed>>
	 */
	public function get_actions() {
		return $this->actions;
	}

	/**
	 * Expose the queued filters (used by Site Health / debug tooling).
	 *
	 * @return array<int, array<string, mixed>>
	 */
	public function get_filters() {
		return $this->filters;
	}
}
