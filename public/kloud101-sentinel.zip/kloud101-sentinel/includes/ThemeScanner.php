<?php
/**
 * Theme security analysis: modified themes, hidden PHP, backdoors,
 * encoded payloads, and fake/hidden theme directories.
 *
 * @package Kloud101Sentinel\Includes
 */

namespace Kloud101Sentinel\Includes;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class ThemeScanner
 *
 * Reuses MalwareScanner's signature engine against every theme PHP
 * file (a theme is just as capable of hosting a webshell as a plugin),
 * and adds theme-specific checks: PHP hidden inside asset files
 * (images/fonts/CSS that a theme wouldn't normally execute) and
 * directories under wp-content/themes that WordPress does not
 * recognize as a valid theme.
 */
class ThemeScanner {

	/**
	 * @var Logger
	 */
	private $logger;

	/**
	 * @var Utilities
	 */
	private $utilities;

	/**
	 * @var Findings
	 */
	private $findings;

	/**
	 * @var MalwareScanner
	 */
	private $malware_scanner;

	/**
	 * Constructor.
	 *
	 * @param Logger         $logger          Shared logger.
	 * @param Utilities      $utilities       Shared helpers.
	 * @param Findings       $findings        Shared findings repository.
	 * @param MalwareScanner $malware_scanner Signature engine, reused for theme PHP content.
	 */
	public function __construct( Logger $logger, Utilities $utilities, Findings $findings, MalwareScanner $malware_scanner ) {
		$this->logger          = $logger;
		$this->utilities       = $utilities;
		$this->findings        = $findings;
		$this->malware_scanner = $malware_scanner;
	}

	/**
	 * Run every theme-related check.
	 *
	 * @param int $scan_id Owning report ID.
	 * @return int Findings recorded.
	 */
	public function scan( $scan_id ) {
		$count  = 0;
		$count += $this->scan_theme_php_files( $scan_id );
		$count += $this->detect_hidden_theme_directories( $scan_id );
		$count += $this->detect_embedded_php_in_assets( $scan_id );

		return $count;
	}

	/**
	 * Run the malware signature engine against every PHP file in every
	 * installed theme (active or not).
	 *
	 * @param int $scan_id Owning report ID.
	 * @return int Findings recorded.
	 */
	private function scan_theme_php_files( $scan_id ) {
		$count = 0;

		foreach ( wp_get_themes() as $theme ) {
			foreach ( Utilities::iterate_files( $theme->get_stylesheet_directory(), array( 'php' ) ) as $absolute_path ) {
				$count += $this->malware_scanner->scan_and_record( $absolute_path, $scan_id );
			}
		}

		return $count;
	}

	/**
	 * Flag directories under wp-content/themes that WordPress does not
	 * recognize as a valid theme (no readable style.css header) but
	 * still contain PHP — a favorite hiding spot for a planted backdoor
	 * that never shows up on the Appearance screen.
	 *
	 * @param int $scan_id Owning report ID.
	 * @return int Findings recorded.
	 */
	private function detect_hidden_theme_directories( $scan_id ) {
		$known_dirs = array();

		foreach ( wp_get_themes() as $theme ) {
			$known_dirs[ $theme->get_stylesheet() ] = true;
		}

		$theme_root = get_theme_root();
		$count      = 0;

		if ( ! is_dir( $theme_root ) ) {
			return $count;
		}

		foreach ( scandir( $theme_root ) as $entry ) {
			if ( '.' === $entry || '..' === $entry || ! is_dir( $theme_root . '/' . $entry ) ) {
				continue;
			}

			if ( isset( $known_dirs[ $entry ] ) ) {
				continue;
			}

			$has_php = false;
			foreach ( Utilities::iterate_files( $theme_root . '/' . $entry, array( 'php' ) ) as $unused_path ) {
				$has_php = true;
				break;
			}

			if ( $has_php ) {
				$this->findings->record(
					array(
						'scan_id'     => $scan_id,
						'type'        => 'theme',
						'severity'    => Findings::SEVERITY_HIGH,
						'file_path'   => 'wp-content/themes/' . $entry,
						'signature'   => 'hidden_theme_directory',
						'description' => sprintf( __( 'Directory "%s" in wp-content/themes contains PHP files but has no valid theme stylesheet header — it is invisible on the Appearance screen.', 'kloud101-sentinel' ), $entry ),
					)
				);
				++$count;
			}
		}

		return $count;
	}

	/**
	 * Detect PHP opening tags hidden inside non-PHP theme asset files
	 * (images, fonts, CSS) — these never execute directly, but they are
	 * a common technique for smuggling a backdoor payload past a
	 * PHP-only integrity scan, to be later `include()`d by a compromised
	 * theme file.
	 *
	 * @param int $scan_id Owning report ID.
	 * @return int Findings recorded.
	 */
	private function detect_embedded_php_in_assets( $scan_id ) {
		$asset_extensions = array( 'jpg', 'jpeg', 'png', 'gif', 'ico', 'css', 'woff', 'woff2', 'ttf' );
		$count            = 0;

		foreach ( wp_get_themes() as $theme ) {
			foreach ( Utilities::iterate_files( $theme->get_stylesheet_directory(), $asset_extensions ) as $absolute_path ) {
				$contents = @file_get_contents( $absolute_path, false, null, 0, 65536 ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents, WordPress.PHP.NoSilencedErrors.Discouraged

				if ( false === $contents || ! preg_match( '/<\?php|eval\s*\(|base64_decode\s*\(/i', $contents ) ) {
					continue;
				}

				$relative_path = str_replace( ABSPATH, '', $absolute_path );

				$this->findings->record(
					array(
						'scan_id'     => $scan_id,
						'type'        => 'theme',
						'severity'    => Findings::SEVERITY_CRITICAL,
						'file_path'   => $relative_path,
						'signature'   => 'embedded_php_in_asset',
						'description' => sprintf( __( 'Theme asset file "%s" contains embedded PHP code, despite its non-PHP extension.', 'kloud101-sentinel' ), $relative_path ),
					)
				);
				++$count;
			}
		}

		return $count;
	}
}
