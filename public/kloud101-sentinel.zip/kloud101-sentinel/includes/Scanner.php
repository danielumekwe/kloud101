<?php
/**
 * Scan orchestrator: composes every individual scanner into
 * resumable, batch-processed "quick", "full", "uploads", and
 * "integrity" scan types, driven either by AJAX (manual, from the
 * admin dashboard) or WP-Cron (scheduled).
 *
 * @package Kloud101Sentinel\Includes
 */

namespace Kloud101Sentinel\Includes;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Scanner
 *
 * Shared hosting cannot be trusted to let a single PHP request scan an
 * entire filesystem within max_execution_time, so every scan is
 * modeled as a queue of small "tasks" (one file to malware-scan, or
 * one scanner "step" such as "compare core integrity") persisted in a
 * transient. process_batch() drains a bounded number of tasks per
 * call — the admin's browser polls it repeatedly for a manual scan,
 * and the scheduled cron entry point loops it internally with its own
 * wall-clock budget, rescheduling a continuation event if it runs out
 * of time before the queue is empty.
 */
class Scanner {

	const TYPE_QUICK     = 'quick';
	const TYPE_FULL      = 'full';
	const TYPE_UPLOADS   = 'uploads';
	const TYPE_INTEGRITY = 'integrity';

	/**
	 * @var Logger
	 */
	private $logger;

	/**
	 * @var Findings
	 */
	private $findings;

	/**
	 * @var MalwareScanner
	 */
	private $malware_scanner;

	/**
	 * @var IntegrityScanner
	 */
	private $integrity_scanner;

	/**
	 * @var UploadScanner
	 */
	private $upload_scanner;

	/**
	 * @var PluginScanner
	 */
	private $plugin_scanner;

	/**
	 * @var ThemeScanner
	 */
	private $theme_scanner;

	/**
	 * @var CronScanner
	 */
	private $cron_scanner;

	/**
	 * @var DatabaseScanner
	 */
	private $database_scanner;

	/**
	 * @var Quarantine
	 */
	private $quarantine;

	/**
	 * Number of tasks processed per batch call. Kept small and
	 * filterable since shared-hosting CPU budgets vary widely.
	 *
	 * @var int
	 */
	private $batch_size;

	/**
	 * Constructor.
	 *
	 * @param Logger           $logger            Shared logger.
	 * @param Findings         $findings          Shared findings repository.
	 * @param MalwareScanner   $malware_scanner   Signature engine.
	 * @param IntegrityScanner $integrity_scanner Core/plugin/theme hash comparison.
	 * @param UploadScanner    $upload_scanner    Uploads directory scanner.
	 * @param PluginScanner    $plugin_scanner    Plugin metadata analysis.
	 * @param ThemeScanner     $theme_scanner     Theme analysis.
	 * @param CronScanner      $cron_scanner      WP-Cron table analysis.
	 * @param DatabaseScanner  $database_scanner  Database-level analysis.
	 * @param Quarantine       $quarantine        Quarantine engine (for dashboard counts).
	 */
	public function __construct(
		Logger $logger,
		Findings $findings,
		MalwareScanner $malware_scanner,
		IntegrityScanner $integrity_scanner,
		UploadScanner $upload_scanner,
		PluginScanner $plugin_scanner,
		ThemeScanner $theme_scanner,
		CronScanner $cron_scanner,
		DatabaseScanner $database_scanner,
		Quarantine $quarantine
	) {
		$this->logger            = $logger;
		$this->findings           = $findings;
		$this->malware_scanner    = $malware_scanner;
		$this->integrity_scanner  = $integrity_scanner;
		$this->upload_scanner     = $upload_scanner;
		$this->plugin_scanner     = $plugin_scanner;
		$this->theme_scanner      = $theme_scanner;
		$this->cron_scanner       = $cron_scanner;
		$this->database_scanner   = $database_scanner;
		$this->quarantine         = $quarantine;
		$this->batch_size         = (int) apply_filters( 'kloud101_sentinel_scan_batch_size', 25 );
	}

	/**
	 * Register hooks: the scheduled cron entry point, its continuation
	 * event, and the two AJAX endpoints the dashboard/scan page poll.
	 *
	 * @param Loader $loader Shared hook loader.
	 */
	public function register( Loader $loader ) {
		$loader->add_action( 'kloud101_sentinel_scheduled_scan', $this, 'run_scheduled_scan' );
		$loader->add_action( 'kloud101_sentinel_continue_scan', $this, 'continue_scan', 10, 1 );
		$loader->add_action( 'wp_ajax_kloud101_sentinel_start_scan', $this, 'ajax_start_scan' );
		$loader->add_action( 'wp_ajax_kloud101_sentinel_scan_batch', $this, 'ajax_process_batch' );
	}

	/**
	 * AJAX: begin a new scan and return its report ID + task count.
	 */
	public function ajax_start_scan() {
		check_ajax_referer( 'kloud101_sentinel_admin', 'nonce' );

		if ( ! current_user_can( 'manage_kloud101_sentinel' ) ) {
			wp_send_json_error( array( 'message' => __( 'Insufficient permissions.', 'kloud101-sentinel' ) ), 403 );
		}

		$type = isset( $_POST['scan_type'] ) ? sanitize_key( wp_unslash( $_POST['scan_type'] ) ) : self::TYPE_QUICK;

		if ( ! in_array( $type, array( self::TYPE_QUICK, self::TYPE_FULL, self::TYPE_UPLOADS, self::TYPE_INTEGRITY ), true ) ) {
			wp_send_json_error( array( 'message' => __( 'Invalid scan type.', 'kloud101-sentinel' ) ), 400 );
		}

		$state = $this->start_scan( $type );

		wp_send_json_success( $state );
	}

	/**
	 * AJAX: process the next batch of tasks for an in-progress scan.
	 */
	public function ajax_process_batch() {
		check_ajax_referer( 'kloud101_sentinel_admin', 'nonce' );

		if ( ! current_user_can( 'manage_kloud101_sentinel' ) ) {
			wp_send_json_error( array( 'message' => __( 'Insufficient permissions.', 'kloud101-sentinel' ) ), 403 );
		}

		$report_id = isset( $_POST['report_id'] ) ? (int) $_POST['report_id'] : 0;

		if ( $report_id <= 0 ) {
			wp_send_json_error( array( 'message' => __( 'Invalid report ID.', 'kloud101-sentinel' ) ), 400 );
		}

		$state = $this->process_batch( $report_id );

		wp_send_json_success( $state );
	}

	/**
	 * Create a report row and build the task queue for a scan type.
	 *
	 * @param string $type One of the TYPE_* constants.
	 * @return array{report_id: int, total: int, processed: int, done: bool}
	 */
	public function start_scan( $type ) {
		global $wpdb;

		$wpdb->insert(
			$wpdb->prefix . 'k101_reports',
			array(
				'type'       => $type,
				'started_at' => current_time( 'mysql', true ),
			),
			array( '%s', '%s' )
		);
		$report_id = (int) $wpdb->insert_id;

		$queue = $this->build_task_queue( $type );

		set_transient( "k101_scan_queue_{$report_id}", $queue, DAY_IN_SECONDS );
		set_transient(
			"k101_scan_meta_{$report_id}",
			array(
				'type'      => $type,
				'total'     => count( $queue ),
				'processed' => 0,
				'findings'  => 0,
			),
			DAY_IN_SECONDS
		);

		$this->logger->info( 'scanner', sprintf( 'Started "%s" scan (report #%d, %d task(s)).', $type, $report_id, count( $queue ) ) );

		return array(
			'report_id' => $report_id,
			'total'     => count( $queue ),
			'processed' => 0,
			'done'      => 0 === count( $queue ),
		);
	}

	/**
	 * Build the ordered list of tasks for a given scan type. Each task
	 * is either a file to run through MalwareScanner, or a "step" that
	 * runs one whole scanner module in a single call.
	 *
	 * @param string $type One of the TYPE_* constants.
	 * @return array<int, array{kind: string, path?: string, step?: string}>
	 */
	private function build_task_queue( $type ) {
		$tasks = array();

		if ( self::TYPE_UPLOADS === $type ) {
			$tasks[] = array( 'kind' => 'step', 'step' => 'upload_scan' );
			return $tasks;
		}

		if ( self::TYPE_INTEGRITY === $type ) {
			$tasks[] = array( 'kind' => 'step', 'step' => 'integrity_core' );
			$tasks[] = array( 'kind' => 'step', 'step' => 'integrity_plugin' );
			$tasks[] = array( 'kind' => 'step', 'step' => 'integrity_theme' );
			return $tasks;
		}

		if ( self::TYPE_QUICK === $type ) {
			foreach ( $this->active_plugin_php_files() as $path ) {
				$tasks[] = array( 'kind' => 'file', 'path' => $path );
			}

			foreach ( Utilities::iterate_files( get_stylesheet_directory(), array( 'php' ) ) as $path ) {
				$tasks[] = array( 'kind' => 'file', 'path' => $path );
			}

			return $tasks;
		}

		// TYPE_FULL: every core + plugin PHP file individually (for
		// progress granularity), plus one step per remaining scanner.
		// Theme PHP content is covered by the theme_scan step itself,
		// so it is not duplicated here as file tasks.
		foreach ( Utilities::iterate_files( ABSPATH . 'wp-admin', array( 'php' ) ) as $path ) {
			$tasks[] = array( 'kind' => 'file', 'path' => $path );
		}
		foreach ( Utilities::iterate_files( ABSPATH . 'wp-includes', array( 'php' ) ) as $path ) {
			$tasks[] = array( 'kind' => 'file', 'path' => $path );
		}
		foreach ( Utilities::iterate_files( WP_PLUGIN_DIR, array( 'php' ) ) as $path ) {
			$tasks[] = array( 'kind' => 'file', 'path' => $path );
		}

		foreach ( array( 'integrity_core', 'integrity_plugin', 'integrity_theme', 'theme_scan', 'upload_scan', 'plugin_scan', 'cron_scan', 'database_scan', 'user_scan' ) as $step ) {
			$tasks[] = array( 'kind' => 'step', 'step' => $step );
		}

		return $tasks;
	}

	/**
	 * PHP files belonging only to *active* plugins — used for the
	 * "quick scan" so it stays fast on sites with many installed-but-
	 * inactive plugins.
	 *
	 * @return \Generator<string>
	 */
	private function active_plugin_php_files() {
		foreach ( (array) get_option( 'active_plugins', array() ) as $plugin_file ) {
			$plugin_dir = WP_PLUGIN_DIR . '/' . dirname( $plugin_file );

			if ( ! is_dir( $plugin_dir ) ) {
				continue;
			}

			foreach ( Utilities::iterate_files( $plugin_dir, array( 'php' ) ) as $path ) {
				yield $path;
			}
		}
	}

	/**
	 * Process up to $this->batch_size tasks from a scan's queue.
	 *
	 * @param int $report_id Report ID.
	 * @return array{report_id: int, total: int, processed: int, findings: int, done: bool}
	 */
	public function process_batch( $report_id ) {
		$queue = get_transient( "k101_scan_queue_{$report_id}" );
		$meta  = get_transient( "k101_scan_meta_{$report_id}" );

		if ( false === $queue || false === $meta ) {
			return array(
				'report_id' => $report_id,
				'total'     => 0,
				'processed' => 0,
				'findings'  => 0,
				'done'      => true,
			);
		}

		$batch = array_splice( $queue, 0, $this->batch_size );

		foreach ( $batch as $task ) {
			$meta['findings'] += $this->run_task( $task, $report_id );
			++$meta['processed'];
		}

		$done = empty( $queue );

		if ( $done ) {
			$this->finish_scan( $report_id, $meta );
			delete_transient( "k101_scan_queue_{$report_id}" );
			delete_transient( "k101_scan_meta_{$report_id}" );
		} else {
			set_transient( "k101_scan_queue_{$report_id}", $queue, DAY_IN_SECONDS );
			set_transient( "k101_scan_meta_{$report_id}", $meta, DAY_IN_SECONDS );
		}

		return array(
			'report_id' => $report_id,
			'total'     => $meta['total'],
			'processed' => $meta['processed'],
			'findings'  => $meta['findings'],
			'done'      => $done,
		);
	}

	/**
	 * Execute a single task.
	 *
	 * @param array $task      Task definition from build_task_queue().
	 * @param int   $report_id Owning report ID.
	 * @return int Number of findings recorded by this task.
	 */
	private function run_task( array $task, $report_id ) {
		if ( 'file' === $task['kind'] ) {
			return $this->malware_scanner->scan_and_record( $task['path'], $report_id );
		}

		switch ( $task['step'] ) {
			case 'integrity_core':
				return $this->integrity_scanner->compare( IntegrityScanner::TYPE_CORE, $report_id );

			case 'integrity_plugin':
				return $this->integrity_scanner->compare( IntegrityScanner::TYPE_PLUGIN, $report_id );

			case 'integrity_theme':
				return $this->integrity_scanner->compare( IntegrityScanner::TYPE_THEME, $report_id );

			case 'theme_scan':
				return $this->theme_scanner->scan( $report_id );

			case 'upload_scan':
				return $this->upload_scanner->scan( $report_id );

			case 'plugin_scan':
				return $this->plugin_scanner->scan( $report_id );

			case 'cron_scan':
				return $this->cron_scanner->scan( $report_id );

			case 'database_scan':
				return $this->database_scanner->scan( $report_id );

			case 'user_scan':
				return $this->user_scan_step( $report_id );

			default:
				return 0;
		}
	}

	/**
	 * UserScanner's reconciliation pass is invoked via the module
	 * registry rather than a direct constructor dependency, since
	 * Scanner does not otherwise need anything from it — fetched
	 * lazily through the main plugin singleton to avoid growing this
	 * class's constructor for a single call site.
	 *
	 * @param int $report_id Owning report ID.
	 * @return int Findings recorded.
	 */
	private function user_scan_step( $report_id ) {
		$plugin = function_exists( 'kloud101_sentinel' ) ? kloud101_sentinel() : null;
		$module = $plugin ? $plugin->get_module( 'user_scanner' ) : null;

		return $module ? $module->scan( $report_id ) : 0;
	}

	/**
	 * Finalize a completed report: record finish time, duration, and a
	 * severity-count summary snapshot.
	 *
	 * @param int   $report_id Report ID.
	 * @param array $meta      Accumulated scan meta.
	 */
	private function finish_scan( $report_id, array $meta ) {
		global $wpdb;

		$report = $wpdb->get_row( $wpdb->prepare( "SELECT started_at FROM {$wpdb->prefix}k101_reports WHERE id = %d", $report_id ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$started = $report ? strtotime( $report->started_at . ' UTC' ) : time();
		$duration = max( 0, time() - $started );

		$summary = array(
			'total_tasks'   => $meta['total'],
			'findings'      => $meta['findings'],
			'severity'      => $this->findings->counts_by_severity(),
			'security_score' => $this->findings->calculate_security_score(),
		);

		$wpdb->update(
			$wpdb->prefix . 'k101_reports',
			array(
				'finished_at'      => current_time( 'mysql', true ),
				'duration_seconds' => $duration,
				'summary'          => wp_json_encode( $summary ),
			),
			array( 'id' => $report_id ),
			array( '%s', '%d', '%s' ),
			array( '%d' )
		);

		$this->logger->info( 'scanner', sprintf( 'Scan #%d finished in %ds with %d finding(s).', $report_id, $duration, $meta['findings'] ) );

		/**
		 * Fires when any scan (manual or scheduled) completes —
		 * Notifications listens to this to send a completion digest.
		 *
		 * @param int   $report_id Report ID.
		 * @param array $summary   Summary data.
		 */
		do_action( 'kloud101_sentinel_scan_completed', $report_id, $summary );
	}

	/**
	 * WP-Cron entry point for scheduled scans. Runs a full scan to
	 * completion within a wall-clock budget; if the site is large
	 * enough that the queue isn't drained in time, schedules a single
	 * continuation event rather than risking a PHP timeout.
	 */
	public function run_scheduled_scan() {
		$state       = $this->start_scan( self::TYPE_FULL );
		$this->drain_with_time_budget( $state['report_id'] );
	}

	/**
	 * Continuation handler for a scan that ran out of time budget on a
	 * previous invocation.
	 *
	 * @param int $report_id Report ID to resume.
	 */
	public function continue_scan( $report_id ) {
		$this->drain_with_time_budget( (int) $report_id );
	}

	/**
	 * Repeatedly call process_batch() until the queue is empty or a
	 * wall-clock budget is exhausted, in which case a single WP-Cron
	 * event is scheduled to pick up where this run left off.
	 *
	 * @param int $report_id Report ID.
	 */
	private function drain_with_time_budget( $report_id ) {
		$budget_seconds = (int) apply_filters( 'kloud101_sentinel_scan_time_budget', 45 );
		$deadline       = microtime( true ) + $budget_seconds;

		do {
			$state = $this->process_batch( $report_id );
		} while ( ! $state['done'] && microtime( true ) < $deadline );

		if ( ! $state['done'] ) {
			wp_schedule_single_event( time() + MINUTE_IN_SECONDS, 'kloud101_sentinel_continue_scan', array( $report_id ) );
		}
	}
}
