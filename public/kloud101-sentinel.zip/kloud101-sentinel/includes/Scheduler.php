<?php
/**
 * WP-Cron schedule management: custom intervals, rescheduling the
 * recurring scan when its frequency setting changes, and daily
 * housekeeping.
 *
 * @package Kloud101Sentinel\Includes
 */

namespace Kloud101Sentinel\Includes;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Scheduler
 *
 * Deliberately does not itself know how to run a scan — that is
 * Scanner's job, hooked directly to 'kloud101_sentinel_scheduled_scan'.
 * Scheduler only owns *when* that hook fires (registering the "weekly"/
 * "monthly" cron intervals WordPress core lacks, and re-scheduling the
 * event whenever the administrator changes the frequency setting) and
 * the separate daily maintenance hook (log pruning).
 */
class Scheduler {

	/**
	 * @var Logger
	 */
	private $logger;

	/**
	 * @var Utilities
	 */
	private $utilities;

	/**
	 * @var Findings
	 */
	private $findings;

	/**
	 * Constructor.
	 *
	 * @param Logger    $logger    Shared logger.
	 * @param Utilities $utilities Shared helpers.
	 * @param Findings  $findings  Shared findings repository.
	 */
	public function __construct( Logger $logger, Utilities $utilities, Findings $findings ) {
		$this->logger    = $logger;
		$this->utilities = $utilities;
		$this->findings  = $findings;
	}

	/**
	 * Register hooks.
	 *
	 * @param Loader $loader Shared hook loader.
	 */
	public function register( Loader $loader ) {
		$loader->add_filter( 'cron_schedules', $this, 'register_custom_schedules' );
		$loader->add_action( 'update_option_kloud101_sentinel_settings', $this, 'maybe_reschedule', 10, 2 );
		$loader->add_action( 'kloud101_sentinel_daily_maintenance', $this, 'run_daily_maintenance' );
	}

	/**
	 * Add "weekly" and "monthly" cron intervals — WordPress core only
	 * ships hourly, twicedaily, and daily.
	 *
	 * @param array $schedules Existing schedules.
	 * @return array
	 */
	public function register_custom_schedules( $schedules ) {
		if ( ! isset( $schedules['weekly'] ) ) {
			$schedules['weekly'] = array(
				'interval' => 7 * DAY_IN_SECONDS,
				'display'  => __( 'Once Weekly', 'kloud101-sentinel' ),
			);
		}

		if ( ! isset( $schedules['monthly'] ) ) {
			$schedules['monthly'] = array(
				'interval' => 30 * DAY_IN_SECONDS,
				'display'  => __( 'Once Monthly', 'kloud101-sentinel' ),
			);
		}

		return $schedules;
	}

	/**
	 * Re-schedule the recurring scan event whenever the saved scan
	 * frequency actually changes, so a setting change takes effect
	 * without requiring plugin deactivation/reactivation.
	 *
	 * @param array $old_value Previous settings array.
	 * @param array $new_value New settings array.
	 */
	public function maybe_reschedule( $old_value, $new_value ) {
		$old_frequency = isset( $old_value['scan_frequency'] ) ? $old_value['scan_frequency'] : '';
		$new_frequency = isset( $new_value['scan_frequency'] ) ? $new_value['scan_frequency'] : 'daily';

		if ( $old_frequency === $new_frequency ) {
			return;
		}

		wp_clear_scheduled_hook( 'kloud101_sentinel_scheduled_scan' );
		wp_schedule_event( time() + HOUR_IN_SECONDS, $this->map_frequency_to_recurrence( $new_frequency ), 'kloud101_sentinel_scheduled_scan' );

		$this->logger->action( 'scheduler', sprintf( 'Rescheduled recurring scan: %s -> %s.', $old_frequency ? $old_frequency : '(none)', $new_frequency ) );
	}

	/**
	 * Map a human setting value to a registered WP-Cron recurrence key.
	 *
	 * @param string $frequency One of 'daily', 'weekly', 'monthly'.
	 * @return string
	 */
	private function map_frequency_to_recurrence( $frequency ) {
		$map = array(
			'daily'   => 'daily',
			'weekly'  => 'weekly',
			'monthly' => 'monthly',
		);

		return isset( $map[ $frequency ] ) ? $map[ $frequency ] : 'daily';
	}

	/**
	 * Daily housekeeping: prune old log entries per the configured
	 * retention window.
	 */
	public function run_daily_maintenance() {
		$settings = wp_parse_args( get_option( 'kloud101_sentinel_settings', array() ), Installer::default_settings() );

		$this->logger->prune( (int) $settings['log_retention_days'] );
	}
}
