<?php
/**
 * Report retrieval and export (print-ready HTML and CSV) for
 * completed scans.
 *
 * @package Kloud101Sentinel\Includes
 */

namespace Kloud101Sentinel\Includes;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Reports
 *
 * Read-only relative to Scanner: it never mutates k101_reports or
 * k101_findings, it only assembles what's already there into a
 * human-readable shape for the Reports admin page (HTML) or a
 * spreadsheet-friendly export (CSV).
 */
class Reports {

	/**
	 * @var Logger
	 */
	private $logger;

	/**
	 * @var Utilities
	 */
	private $utilities;

	/**
	 * @var Findings
	 */
	private $findings;

	/**
	 * Constructor.
	 *
	 * @param Logger    $logger    Shared logger.
	 * @param Utilities $utilities Shared helpers.
	 * @param Findings  $findings  Shared findings repository.
	 */
	public function __construct( Logger $logger, Utilities $utilities, Findings $findings ) {
		$this->logger    = $logger;
		$this->utilities = $utilities;
		$this->findings  = $findings;
	}

	/**
	 * Fetch a single report row, with its summary JSON decoded.
	 *
	 * @param int $report_id Report ID.
	 * @return object|null
	 */
	public function get_report( $report_id ) {
		global $wpdb;

		$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}k101_reports WHERE id = %d", $report_id ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared

		if ( $row && $row->summary ) {
			$row->summary = json_decode( $row->summary, true );
		}

		return $row;
	}

	/**
	 * List reports, most recent first.
	 *
	 * @param int $paged    1-indexed page number.
	 * @param int $per_page Rows per page.
	 * @return array{rows: array<int, object>, total: int}
	 */
	public function list_reports( $paged = 1, $per_page = 20 ) {
		global $wpdb;

		$table  = $wpdb->prefix . 'k101_reports';
		$offset = max( 0, ( (int) $paged - 1 ) * (int) $per_page );

		$total = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$table}" ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
		$rows  = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$table} ORDER BY started_at DESC LIMIT %d OFFSET %d", (int) $per_page, $offset ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared

		return array(
			'rows'  => $rows ? $rows : array(),
			'total' => $total,
		);
	}

	/**
	 * Derive a short list of security recommendations from currently
	 * open findings and the saved hardening settings — a lightweight,
	 * rule-based substitute for a full policy engine.
	 *
	 * @return string[]
	 */
	public function get_recommendations() {
		$settings        = wp_parse_args( get_option( 'kloud101_sentinel_settings', array() ), Installer::default_settings() );
		$recommendations = array();

		if ( empty( $settings['hardening_disable_xmlrpc'] ) ) {
			$recommendations[] = __( 'Consider disabling XML-RPC if you do not use the Jetpack or WordPress mobile apps.', 'kloud101-sentinel' );
		}

		if ( empty( $settings['hardening_hide_wp_version'] ) ) {
			$recommendations[] = __( 'Hide the WordPress version number to make automated vulnerability targeting slightly harder.', 'kloud101-sentinel' );
		}

		if ( empty( $settings['hardening_block_php_uploads'] ) ) {
			$recommendations[] = __( 'Block PHP execution inside wp-content/uploads to neutralize most upload-based webshells even if one is planted.', 'kloud101-sentinel' );
		}

		if ( empty( $settings['firewall_enabled'] ) ) {
			$recommendations[] = __( 'Enable the built-in firewall to block common SQL injection, XSS, and path traversal probes.', 'kloud101-sentinel' );
		}

		global $wpdb;
		if ( 'wp_' === $wpdb->prefix ) {
			$recommendations[] = __( 'Your database is using the default "wp_" table prefix; a custom prefix adds a small amount of friction against generic SQL injection payloads.', 'kloud101-sentinel' );
		}

		$counts = $this->findings->counts_by_severity();
		if ( $counts[ Findings::SEVERITY_CRITICAL ] > 0 ) {
			$recommendations[] = __( 'You have open CRITICAL findings — review and resolve or quarantine them as a priority before addressing lower-severity items.', 'kloud101-sentinel' );
		}

		return $recommendations;
	}

	/**
	 * Render a self-contained, print-ready HTML report for one scan.
	 * "Print-ready" here means it includes its own <style> block and
	 * has no dependency on the admin theme, so "Print to PDF" from the
	 * browser produces a clean document.
	 *
	 * @param int $report_id Report ID.
	 * @return string HTML markup.
	 */
	public function render_html( $report_id ) {
		$report = $this->get_report( $report_id );

		if ( ! $report ) {
			return '<p>' . esc_html__( 'Report not found.', 'kloud101-sentinel' ) . '</p>';
		}

		$findings_data = $this->findings->list_findings( array( 'scan_id' => $report_id, 'status' => '', 'per_page' => 5000 ) );
		$findings_rows = $findings_data['rows'];

		$summary = is_array( $report->summary ) ? $report->summary : array();

		ob_start();
		?>
		<div class="k101-report">
			<style>
				.k101-report { font-family: -apple-system, Segoe UI, Roboto, sans-serif; color: #1d2327; max-width: 900px; }
				.k101-report h1 { font-size: 20px; margin-bottom: 4px; }
				.k101-report .k101-meta { color: #646970; font-size: 13px; margin-bottom: 20px; }
				.k101-report table { width: 100%; border-collapse: collapse; margin-bottom: 24px; }
				.k101-report th, .k101-report td { text-align: left; padding: 8px 10px; border-bottom: 1px solid #dcdcde; font-size: 13px; }
				.k101-report th { background: #f6f7f7; }
				.k101-severity-critical { color: #b32d2e; font-weight: 600; }
				.k101-severity-high { color: #d54e21; font-weight: 600; }
				.k101-severity-medium { color: #996800; font-weight: 600; }
				.k101-severity-low { color: #2271b1; font-weight: 600; }
			</style>
			<h1><?php esc_html_e( 'Kloud101 Sentinel Security Report', 'kloud101-sentinel' ); ?></h1>
			<p class="k101-meta">
				<?php
				printf(
					/* translators: 1: site URL, 2: scan type, 3: date */
					esc_html__( 'Site: %1$s | Scan type: %2$s | Started: %3$s', 'kloud101-sentinel' ),
					esc_html( home_url() ),
					esc_html( $report->type ),
					esc_html( $report->started_at )
				);
				?>
			</p>

			<table>
				<tr><th><?php esc_html_e( 'Security Score', 'kloud101-sentinel' ); ?></th><td><?php echo esc_html( isset( $summary['security_score'] ) ? $summary['security_score'] . '/100' : '—' ); ?></td></tr>
				<tr><th><?php esc_html_e( 'Total Findings', 'kloud101-sentinel' ); ?></th><td><?php echo esc_html( isset( $summary['findings'] ) ? $summary['findings'] : count( $findings_rows ) ); ?></td></tr>
				<tr><th><?php esc_html_e( 'Scan Duration', 'kloud101-sentinel' ); ?></th><td><?php echo esc_html( $report->duration_seconds ? $report->duration_seconds . 's' : '—' ); ?></td></tr>
				<tr><th><?php esc_html_e( 'Server Software', 'kloud101-sentinel' ); ?></th><td><?php echo esc_html( Utilities::get_server_software() ); ?></td></tr>
				<tr><th><?php esc_html_e( 'WordPress Version', 'kloud101-sentinel' ); ?></th><td><?php echo esc_html( get_bloginfo( 'version' ) ); ?></td></tr>
				<tr><th><?php esc_html_e( 'PHP Version', 'kloud101-sentinel' ); ?></th><td><?php echo esc_html( PHP_VERSION ); ?></td></tr>
			</table>

			<h2><?php esc_html_e( 'Findings', 'kloud101-sentinel' ); ?></h2>
			<table>
				<thead>
					<tr>
						<th><?php esc_html_e( 'Severity', 'kloud101-sentinel' ); ?></th>
						<th><?php esc_html_e( 'Type', 'kloud101-sentinel' ); ?></th>
						<th><?php esc_html_e( 'Location', 'kloud101-sentinel' ); ?></th>
						<th><?php esc_html_e( 'Description', 'kloud101-sentinel' ); ?></th>
					</tr>
				</thead>
				<tbody>
					<?php if ( empty( $findings_rows ) ) : ?>
						<tr><td colspan="4"><?php esc_html_e( 'No findings recorded for this scan.', 'kloud101-sentinel' ); ?></td></tr>
					<?php else : ?>
						<?php foreach ( $findings_rows as $finding ) : ?>
							<tr>
								<td class="k101-severity-<?php echo esc_attr( $finding->severity ); ?>"><?php echo esc_html( ucfirst( $finding->severity ) ); ?></td>
								<td><?php echo esc_html( ucfirst( $finding->type ) ); ?></td>
								<td><?php echo esc_html( $finding->file_path ); ?></td>
								<td><?php echo esc_html( $finding->description ); ?></td>
							</tr>
						<?php endforeach; ?>
					<?php endif; ?>
				</tbody>
			</table>

			<h2><?php esc_html_e( 'Recommendations', 'kloud101-sentinel' ); ?></h2>
			<ul>
				<?php foreach ( $this->get_recommendations() as $recommendation ) : ?>
					<li><?php echo esc_html( $recommendation ); ?></li>
				<?php endforeach; ?>
			</ul>
		</div>
		<?php

		return ob_get_clean();
	}

	/**
	 * Stream a CSV export of a single report's findings to the current
	 * output buffer. Caller is responsible for sending headers.
	 *
	 * @param int $report_id Report ID.
	 */
	public function export_csv( $report_id ) {
		global $wpdb;

		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT severity, type, file_path, signature, description, detected_at FROM {$wpdb->prefix}k101_findings WHERE scan_id = %d ORDER BY detected_at DESC", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				$report_id
			)
		);

		$output = fopen( 'php://output', 'w' );
		fputcsv( $output, array( 'Severity', 'Type', 'Location', 'Signature', 'Description', 'Detected At (UTC)' ) );

		foreach ( $rows as $row ) {
			fputcsv( $output, array( $row->severity, $row->type, $row->file_path, $row->signature, $row->description, $row->detected_at ) );
		}

		fclose( $output );
	}
}
