<?php
/**
 * Plugin deactivation routine.
 *
 * @package Kloud101Sentinel\Includes
 */

namespace Kloud101Sentinel\Includes;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Deactivator
 *
 * Intentionally minimal: deactivation must be safely reversible by
 * simply reactivating the plugin, so it only clears scheduled cron
 * events. Tables, options, and quarantined files are left untouched —
 * that destructive path lives solely in uninstall.php, gated behind an
 * explicit opt-in setting.
 */
class Deactivator {

	/**
	 * Run on plugin deactivation.
	 */
	public static function deactivate() {
		wp_clear_scheduled_hook( 'kloud101_sentinel_scheduled_scan' );
		wp_clear_scheduled_hook( 'kloud101_sentinel_daily_maintenance' );
	}
}
