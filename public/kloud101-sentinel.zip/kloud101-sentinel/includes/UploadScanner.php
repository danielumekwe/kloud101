<?php
/**
 * Scans wp-content/uploads for executable, disguised, or otherwise
 * dangerous files and quarantines them automatically.
 *
 * @package Kloud101Sentinel\Includes
 */

namespace Kloud101Sentinel\Includes;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class UploadScanner
 *
 * The uploads directory is the single most common malware entry point
 * on WordPress (arbitrary file upload vulnerabilities in outdated
 * plugins/themes). Unlike core/plugin/theme integrity checking, a
 * dangerous upload should never simply be "reported" — by definition
 * nothing legitimate should ever be a PHP file inside uploads/, so
 * matches here are quarantined immediately rather than waiting for
 * manual review.
 */
class UploadScanner {

	/**
	 * @var Logger
	 */
	private $logger;

	/**
	 * @var Utilities
	 */
	private $utilities;

	/**
	 * @var Findings
	 */
	private $findings;

	/**
	 * @var Quarantine
	 */
	private $quarantine;

	/**
	 * @var MalwareScanner
	 */
	private $malware_scanner;

	/**
	 * Extensions that must never execute if served from uploads/. This
	 * list, not the presence of malware signatures, is the primary
	 * trigger for auto-quarantine — an attacker-planted webshell often
	 * contains no recognizable signature at all.
	 *
	 * @var string[]
	 */
	private $disallowed_extensions = array(
		'php', 'php2', 'php3', 'php4', 'php5', 'php7', 'phtml', 'phar',
		'pht', 'cgi', 'pl', 'py', 'asp', 'aspx', 'jsp', 'exe', 'sh', 'dll',
	);

	/**
	 * Constructor.
	 *
	 * @param Logger         $logger          Shared logger.
	 * @param Utilities      $utilities       Shared helpers.
	 * @param Findings       $findings        Shared findings repository.
	 * @param Quarantine     $quarantine      Quarantine engine.
	 * @param MalwareScanner $malware_scanner Signature engine, reused for SVG/media content inspection.
	 */
	public function __construct( Logger $logger, Utilities $utilities, Findings $findings, Quarantine $quarantine, MalwareScanner $malware_scanner ) {
		$this->logger          = $logger;
		$this->utilities       = $utilities;
		$this->findings        = $findings;
		$this->quarantine      = $quarantine;
		$this->malware_scanner = $malware_scanner;
	}

	/**
	 * Scan the entire uploads directory.
	 *
	 * @param int $scan_id Owning report ID.
	 * @return int Number of findings recorded.
	 */
	public function scan( $scan_id ) {
		$upload_dir = wp_upload_dir();
		$base_dir   = $upload_dir['basedir'];

		$finding_count = 0;

		foreach ( Utilities::iterate_files( $base_dir ) as $absolute_path ) {
			$finding_count += $this->scan_single_file( $absolute_path, $scan_id );
		}

		return $finding_count;
	}

	/**
	 * Inspect a single uploaded file, quarantining it immediately if it
	 * is disallowed by extension, disguised via a double extension, or
	 * a polyglot (image-labelled file that is actually a script).
	 *
	 * @param string $absolute_path Absolute file path.
	 * @param int    $scan_id       Owning report ID.
	 * @return int Number of findings recorded for this file.
	 */
	public function scan_single_file( $absolute_path, $scan_id ) {
		$relative_path = str_replace( ABSPATH, '', $absolute_path );
		$filename      = basename( $absolute_path );
		$extension     = strtolower( pathinfo( $filename, PATHINFO_EXTENSION ) );

		$verdict = $this->classify( $absolute_path, $filename, $extension );

		if ( null === $verdict ) {
			return 0;
		}

		list( $severity, $signature, $description ) = $verdict;

		$finding_id = $this->findings->record(
			array(
				'scan_id'     => $scan_id,
				'type'        => 'upload',
				'severity'    => $severity,
				'file_path'   => $relative_path,
				'signature'   => $signature,
				'description' => $description,
			)
		);

		$result = $this->quarantine->quarantine_file( $absolute_path, $description, 'upload', $finding_id );

		if ( is_wp_error( $result ) ) {
			$this->logger->error( 'upload_scanner', $result->get_error_message(), array( 'path' => $relative_path ) );
		} else {
			$this->logger->warning( 'upload_scanner', sprintf( 'Auto-quarantined dangerous upload: %s', $relative_path ), array( 'signature' => $signature ) );
		}

		return 1;
	}

	/**
	 * Determine whether a file should be quarantined and why.
	 *
	 * @param string $absolute_path Absolute path.
	 * @param string $filename      Base filename.
	 * @param string $extension    Lower-cased extension.
	 * @return array{0: string, 1: string, 2: string}|null [severity, signature, description] or null if clean.
	 */
	private function classify( $absolute_path, $filename, $extension ) {
		if ( in_array( $extension, $this->disallowed_extensions, true ) ) {
			return array(
				Findings::SEVERITY_CRITICAL,
				'disallowed_extension',
				sprintf( __( 'Executable file type ("%s") found inside the uploads directory, where only media should live.', 'kloud101-sentinel' ), $extension ),
			);
		}

		// Double extension, e.g. "invoice.php.jpg" or "shell.phtml.png" —
		// attackers rely on lax server configs executing the *first*
		// extension while WordPress's own check only looks at the last.
		if ( preg_match( '/\.(php\d?|phtml|phar|pht|cgi|asp|aspx|jsp|exe)\.[a-z0-9]{2,5}$/i', $filename ) ) {
			return array(
				Findings::SEVERITY_CRITICAL,
				'double_extension',
				sprintf( __( 'Filename "%s" hides an executable extension behind a second, benign-looking extension.', 'kloud101-sentinel' ), $filename ),
			);
		}

		if ( 'svg' === $extension && $this->svg_contains_script( $absolute_path ) ) {
			return array(
				Findings::SEVERITY_HIGH,
				'malicious_svg',
				sprintf( __( 'SVG file "%s" contains inline <script> or event-handler JavaScript.', 'kloud101-sentinel' ), $filename ),
			);
		}

		if ( $this->is_image_extension( $extension ) && $this->has_embedded_php( $absolute_path ) ) {
			return array(
				Findings::SEVERITY_CRITICAL,
				'polyglot_image',
				sprintf( __( 'File "%s" has an image extension but contains PHP code (image/PHP polyglot).', 'kloud101-sentinel' ), $filename ),
			);
		}

		return null;
	}

	/**
	 * Whether a filename extension belongs to a normal image type.
	 *
	 * @param string $extension Lower-cased extension.
	 * @return bool
	 */
	private function is_image_extension( $extension ) {
		return in_array( $extension, array( 'jpg', 'jpeg', 'png', 'gif', 'webp', 'bmp', 'ico' ), true );
	}

	/**
	 * Detect a PHP opening tag or common obfuscation calls hidden
	 * inside a file whose extension claims it is a plain image.
	 *
	 * @param string $absolute_path Absolute path.
	 * @return bool
	 */
	private function has_embedded_php( $absolute_path ) {
		$contents = @file_get_contents( $absolute_path, false, null, 0, 65536 ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents, WordPress.PHP.NoSilencedErrors.Discouraged

		if ( false === $contents ) {
			return false;
		}

		return (bool) preg_match( '/<\?php|<\?=|eval\s*\(|base64_decode\s*\(/i', $contents );
	}

	/**
	 * Detect inline JavaScript inside an SVG file (script tags, inline
	 * event handlers, or javascript: URIs) — SVG is XML and can carry
	 * an XSS payload that executes in the context of whoever views it.
	 *
	 * @param string $absolute_path Absolute path.
	 * @return bool
	 */
	private function svg_contains_script( $absolute_path ) {
		$contents = @file_get_contents( $absolute_path, false, null, 0, 131072 ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents, WordPress.PHP.NoSilencedErrors.Discouraged

		if ( false === $contents ) {
			return false;
		}

		return (bool) preg_match( '/<script|on(?:load|error|click|mouseover)\s*=|javascript:/i', $contents );
	}
}
