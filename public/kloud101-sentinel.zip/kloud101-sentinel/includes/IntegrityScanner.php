<?php
/**
 * File integrity monitoring for WordPress core, plugins, and themes.
 *
 * @package Kloud101Sentinel\Includes
 */

namespace Kloud101Sentinel\Includes;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class IntegrityScanner
 *
 * Maintains a sha256 baseline of every core/plugin/theme file in the
 * `k101_file_hashes` table and reports new, deleted, or modified files
 * against it. Core files additionally get a best-effort cross-check
 * against the official WordPress.org checksums API when the site has
 * outbound internet access — this is optional enrichment, never a
 * requirement, so the plugin still fully functions on a fully
 * air-gapped host using the local baseline alone.
 */
class IntegrityScanner {

	const TYPE_CORE   = 'core';
	const TYPE_PLUGIN = 'plugin';
	const TYPE_THEME  = 'theme';

	/**
	 * @var Logger
	 */
	private $logger;

	/**
	 * @var Utilities
	 */
	private $utilities;

	/**
	 * @var Findings
	 */
	private $findings;

	/**
	 * Constructor.
	 *
	 * @param Logger    $logger    Shared logger.
	 * @param Utilities $utilities Shared helpers.
	 * @param Findings  $findings  Shared findings repository.
	 */
	public function __construct( Logger $logger, Utilities $utilities, Findings $findings ) {
		$this->logger    = $logger;
		$this->utilities = $utilities;
		$this->findings  = $findings;
	}

	/**
	 * Build (or rebuild) the baseline hash table for one file type.
	 * Rebuilding should only happen explicitly (e.g. after the admin
	 * confirms a set of changes are legitimate) — never automatically
	 * after every scan, or genuine tampering would silently become the
	 * new "normal".
	 *
	 * @param string $type One of the TYPE_* constants.
	 */
	public function build_baseline( $type ) {
		global $wpdb;

		$table = $wpdb->prefix . 'k101_file_hashes';

		// Clear the existing baseline for this type before rebuilding so
		// entries for files that were deliberately removed don't linger
		// and get reported as "deleted" forever.
		$wpdb->delete( $table, array( 'file_type' => $type ), array( '%s' ) );

		foreach ( $this->get_paths_for_type( $type ) as $absolute_path ) {
			$this->upsert_hash( $absolute_path, $type );
		}

		$this->logger->info( 'integrity_scanner', sprintf( 'Baseline rebuilt for type "%s".', $type ) );
	}

	/**
	 * Compare current on-disk state against the stored baseline for one
	 * file type, recording a Finding for every new/modified/deleted file.
	 *
	 * @param string $type    One of the TYPE_* constants.
	 * @param int    $scan_id Owning report ID.
	 * @return int Number of findings recorded.
	 */
	public function compare( $type, $scan_id ) {
		global $wpdb;

		$table   = $wpdb->prefix . 'k101_file_hashes';
		$baseline = $wpdb->get_results(
			$wpdb->prepare( "SELECT relative_path, sha256 FROM {$table} WHERE file_type = %s", $type ), // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			OBJECT_K
		);

		if ( empty( $baseline ) ) {
			// No baseline yet: first run establishes one silently rather
			// than reporting every existing file as "new".
			$this->build_baseline( $type );
			return 0;
		}

		$seen        = array();
		$finding_count = 0;

		foreach ( $this->get_paths_for_type( $type ) as $absolute_path ) {
			$relative_path        = $this->to_relative( $absolute_path );
			$seen[ $relative_path ] = true;
			$current_hash          = Utilities::hash_file( $absolute_path );

			if ( null === $current_hash ) {
				continue;
			}

			if ( ! isset( $baseline[ $relative_path ] ) ) {
				$this->findings->record(
					array(
						'scan_id'     => $scan_id,
						'type'        => 'integrity',
						'severity'    => Findings::SEVERITY_HIGH,
						'file_path'   => $relative_path,
						'signature'   => 'file_added',
						'description' => sprintf( __( 'New file appeared since the last baseline: %s', 'kloud101-sentinel' ), $relative_path ),
					)
				);
				$this->upsert_hash( $absolute_path, $type );
				++$finding_count;
				continue;
			}

			if ( $baseline[ $relative_path ]->sha256 !== $current_hash ) {
				$severity = self::TYPE_CORE === $type ? Findings::SEVERITY_CRITICAL : Findings::SEVERITY_HIGH;

				$this->findings->record(
					array(
						'scan_id'     => $scan_id,
						'type'        => 'integrity',
						'severity'    => $severity,
						'file_path'   => $relative_path,
						'signature'   => 'file_modified',
						'description' => sprintf( __( 'File content changed since the last baseline: %s', 'kloud101-sentinel' ), $relative_path ),
					)
				);
				$this->upsert_hash( $absolute_path, $type );
				++$finding_count;
			}
		}

		foreach ( $baseline as $relative_path => $row ) {
			if ( ! isset( $seen[ $relative_path ] ) ) {
				$this->findings->record(
					array(
						'scan_id'     => $scan_id,
						'type'        => 'integrity',
						'severity'    => Findings::SEVERITY_MEDIUM,
						'file_path'   => $relative_path,
						'signature'   => 'file_deleted',
						'description' => sprintf( __( 'File present in the baseline is now missing: %s', 'kloud101-sentinel' ), $relative_path ),
					)
				);
				$wpdb->delete( $table, array( 'relative_path' => $relative_path, 'file_type' => $type ), array( '%s', '%s' ) );
				++$finding_count;
			}
		}

		if ( self::TYPE_CORE === $type ) {
			$finding_count += $this->verify_core_against_wordpress_org( $scan_id );
		}

		return $finding_count;
	}

	/**
	 * Best-effort cross-check of core file hashes against the official
	 * WordPress.org checksums API. Gated behind the "WordPress.org
	 * lookups" setting (Settings > Scanning), which the administrator
	 * must explicitly opt into — see the class docblock. Silently
	 * skipped (info-logged, not an error) if disabled or if the request
	 * fails — this plugin must never depend on connectivity to function.
	 *
	 * @param int $scan_id Owning report ID.
	 * @return int Number of additional findings recorded.
	 */
	private function verify_core_against_wordpress_org( $scan_id ) {
		global $wp_version;

		$settings = wp_parse_args( get_option( 'kloud101_sentinel_settings', array() ), Installer::default_settings() );

		if ( empty( $settings['enable_wordpress_org_lookups'] ) ) {
			return 0;
		}

		if ( ! apply_filters( 'kloud101_sentinel_enable_wordpress_org_lookups', true ) ) {
			return 0;
		}

		$locale   = get_locale();
		$response = wp_remote_get(
			sprintf( 'https://api.wordpress.org/core/checksums/1.0/?version=%s&locale=%s', rawurlencode( $wp_version ), rawurlencode( $locale ) ),
			array( 'timeout' => 8 )
		);

		if ( is_wp_error( $response ) || 200 !== (int) wp_remote_retrieve_response_code( $response ) ) {
			$this->logger->info( 'integrity_scanner', 'WordPress.org checksum verification skipped (offline or unreachable).' );
			return 0;
		}

		$body = json_decode( wp_remote_retrieve_body( $response ), true );

		if ( empty( $body['checksums'] ) || ! is_array( $body['checksums'] ) ) {
			return 0;
		}

		$finding_count = 0;

		foreach ( $body['checksums'] as $relative_path => $expected_md5 ) {
			// The official manifest covers wp-admin/wp-includes plus root
			// files; wp-content is intentionally excluded by WordPress.org
			// itself since it is site-specific.
			if ( 0 === strpos( $relative_path, 'wp-content/' ) ) {
				continue;
			}

			$absolute_path = ABSPATH . $relative_path;

			if ( ! is_file( $absolute_path ) ) {
				continue;
			}

			$actual_md5 = @md5_file( $absolute_path ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged

			if ( false !== $actual_md5 && $actual_md5 !== $expected_md5 ) {
				$this->findings->record(
					array(
						'scan_id'     => $scan_id,
						'type'        => 'integrity',
						'severity'    => Findings::SEVERITY_CRITICAL,
						'file_path'   => $relative_path,
						'signature'   => 'core_checksum_mismatch',
						'description' => sprintf( __( 'Core file does not match the official WordPress.org checksum for version %s.', 'kloud101-sentinel' ), $wp_version ),
					)
				);
				++$finding_count;
			}
		}

		return $finding_count;
	}

	/**
	 * Insert or update a single file's baseline hash row.
	 *
	 * @param string $absolute_path Absolute file path.
	 * @param string $type          One of the TYPE_* constants.
	 */
	private function upsert_hash( $absolute_path, $type ) {
		global $wpdb;

		$hash = Utilities::hash_file( $absolute_path );

		if ( null === $hash ) {
			return;
		}

		$relative_path = $this->to_relative( $absolute_path );

		$wpdb->query( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.PreparedSQL.NotPrepared
			$wpdb->prepare(
				"INSERT INTO {$wpdb->prefix}k101_file_hashes (relative_path, file_type, sha256, file_size, mtime, updated_at)
				VALUES (%s, %s, %s, %d, %d, %s)
				ON DUPLICATE KEY UPDATE sha256 = VALUES(sha256), file_size = VALUES(file_size), mtime = VALUES(mtime), updated_at = VALUES(updated_at)", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				$relative_path,
				$type,
				$hash,
				(int) filesize( $absolute_path ),
				(int) filemtime( $absolute_path ),
				current_time( 'mysql', true )
			)
		);
	}

	/**
	 * Enumerate the absolute paths that belong to a given file type.
	 *
	 * @param string $type One of the TYPE_* constants.
	 * @return \Generator<string>
	 */
	private function get_paths_for_type( $type ) {
		switch ( $type ) {
			case self::TYPE_CORE:
				return $this->get_core_paths();

			case self::TYPE_PLUGIN:
				return Utilities::iterate_files( WP_PLUGIN_DIR, array( 'php' ) );

			case self::TYPE_THEME:
				return Utilities::iterate_files( get_theme_root(), array( 'php' ) );

			default:
				return new \ArrayIterator( array() );
		}
	}

	/**
	 * Core files are wp-admin/, wp-includes/, and top-level *.php files
	 * in ABSPATH — explicitly excluding wp-content, which is site-owned
	 * and covered separately by the plugin/theme baselines.
	 *
	 * @return \Generator<string>
	 */
	private function get_core_paths() {
		foreach ( Utilities::iterate_files( ABSPATH . 'wp-admin', array( 'php' ) ) as $path ) {
			yield $path;
		}

		foreach ( Utilities::iterate_files( ABSPATH . 'wp-includes', array( 'php' ) ) as $path ) {
			yield $path;
		}

		foreach ( glob( ABSPATH . '*.php' ) as $path ) {
			yield $path;
		}
	}

	/**
	 * Convert an absolute path to a path relative to ABSPATH, used as
	 * the stable key stored in k101_file_hashes.
	 *
	 * @param string $absolute_path Absolute path.
	 * @return string
	 */
	private function to_relative( $absolute_path ) {
		return str_replace( ABSPATH, '', $absolute_path );
	}
}
