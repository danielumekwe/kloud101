<?php
/**
 * Plugin activation routine.
 *
 * @package Kloud101Sentinel\Includes
 */

namespace Kloud101Sentinel\Includes;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Activator
 *
 * Static-only: WordPress's register_activation_hook() callback must be
 * usable before the singleton Plugin object exists, so this cannot be
 * an instance method on a module.
 */
class Activator {

	/**
	 * Run on plugin activation.
	 *
	 * @param bool $network_wide Whether the plugin was network-activated
	 *                           on a multisite install.
	 */
	public static function activate( $network_wide ) {
		if ( is_multisite() && $network_wide ) {
			$site_ids = get_sites( array( 'fields' => 'ids' ) );

			foreach ( $site_ids as $site_id ) {
				switch_to_blog( $site_id );
				self::activate_single_site();
				restore_current_blog();
			}
		} else {
			self::activate_single_site();
		}
	}

	/**
	 * Activation steps for a single site: schema, capabilities, default
	 * options, quarantine directory, and cron schedule.
	 */
	private static function activate_single_site() {
		Installer::create_tables();
		Installer::add_capabilities();
		Installer::seed_default_options();
		self::prepare_quarantine_directory();
		self::schedule_events();
	}

	/**
	 * Create the quarantine directory outside the web root's obvious
	 * upload path and lock it down with both an .htaccess deny rule
	 * (Apache) and a dummy index.php (any server), so a quarantined PHP
	 * payload can never be executed even if directly requested.
	 */
	private static function prepare_quarantine_directory() {
		if ( ! file_exists( KLOUD101_SENTINEL_QUARANTINE_DIR ) ) {
			wp_mkdir_p( KLOUD101_SENTINEL_QUARANTINE_DIR );
		}

		$htaccess = KLOUD101_SENTINEL_QUARANTINE_DIR . '.htaccess';
		if ( ! file_exists( $htaccess ) ) {
			file_put_contents( $htaccess, "Require all denied\nDeny from all\n" ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents
		}

		$index = KLOUD101_SENTINEL_QUARANTINE_DIR . 'index.php';
		if ( ! file_exists( $index ) ) {
			file_put_contents( $index, "<?php\n// Silence is golden.\n" ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents
		}

		$web_config = KLOUD101_SENTINEL_QUARANTINE_DIR . 'web.config';
		if ( ! file_exists( $web_config ) ) {
			file_put_contents( // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents
				$web_config,
				"<configuration>\n\t<system.webServer>\n\t\t<authorization>\n\t\t\t<deny users=\"*\" />\n\t\t</authorization>\n\t</system.webServer>\n</configuration>\n"
			);
		}
	}

	/**
	 * Schedule the recurring scan and daily maintenance cron events if
	 * they are not already scheduled. Actual interval/frequency is
	 * re-evaluated by Scheduler on every settings save.
	 */
	private static function schedule_events() {
		if ( ! wp_next_scheduled( 'kloud101_sentinel_scheduled_scan' ) ) {
			wp_schedule_event( time() + HOUR_IN_SECONDS, 'daily', 'kloud101_sentinel_scheduled_scan' );
		}

		if ( ! wp_next_scheduled( 'kloud101_sentinel_daily_maintenance' ) ) {
			wp_schedule_event( time() + ( 2 * HOUR_IN_SECONDS ), 'daily', 'kloud101_sentinel_daily_maintenance' );
		}
	}
}
