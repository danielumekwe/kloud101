<?php
/**
 * Structured, database-backed logging for the plugin.
 *
 * @package Kloud101Sentinel\Includes
 */

namespace Kloud101Sentinel\Includes;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Logger
 *
 * Every module writes through this class instead of touching
 * `error_log()` or a flat file directly, so log entries are queryable
 * (by level, source, date range) from the Logs admin page and can be
 * exported without needing filesystem access to the log location.
 */
class Logger {

	const LEVEL_ERROR   = 'error';
	const LEVEL_WARNING = 'warning';
	const LEVEL_INFO    = 'info';
	const LEVEL_ACTION  = 'action';

	/**
	 * Table name (without the wpdb prefix helper, resolved lazily since
	 * $wpdb may not be available yet at construction on very early hooks).
	 *
	 * @return string
	 */
	private function table() {
		global $wpdb;

		return $wpdb->prefix . 'k101_logs';
	}

	/**
	 * Write a log entry.
	 *
	 * @param string $level   One of the LEVEL_* constants.
	 * @param string $source  Short module identifier, e.g. 'malware_scanner'.
	 * @param string $message Human-readable message.
	 * @param array  $context Optional structured context, stored as JSON.
	 */
	public function log( $level, $source, $message, array $context = array() ) {
		global $wpdb;

		$wpdb->insert(
			$this->table(),
			array(
				'level'      => $level,
				'source'     => $source,
				'message'    => $message,
				'context'    => wp_json_encode( $context ),
				'created_at' => current_time( 'mysql', true ),
			),
			array( '%s', '%s', '%s', '%s', '%s' )
		);

		if ( self::LEVEL_ERROR === $level && function_exists( 'do_action' ) ) {
			/**
			 * Fires whenever an error-level log entry is written, so
			 * Notifications can react without Logger depending on it.
			 *
			 * @param string $source  Module that logged the error.
			 * @param string $message Error message.
			 * @param array  $context Structured context.
			 */
			do_action( 'kloud101_sentinel_error_logged', $source, $message, $context );
		}
	}

	/**
	 * Convenience wrapper for error-level entries.
	 *
	 * @param string $source  Module identifier.
	 * @param string $message Message.
	 * @param array  $context Context.
	 */
	public function error( $source, $message, array $context = array() ) {
		$this->log( self::LEVEL_ERROR, $source, $message, $context );
	}

	/**
	 * Convenience wrapper for warning-level entries.
	 *
	 * @param string $source  Module identifier.
	 * @param string $message Message.
	 * @param array  $context Context.
	 */
	public function warning( $source, $message, array $context = array() ) {
		$this->log( self::LEVEL_WARNING, $source, $message, $context );
	}

	/**
	 * Convenience wrapper for info-level entries.
	 *
	 * @param string $source  Module identifier.
	 * @param string $message Message.
	 * @param array  $context Context.
	 */
	public function info( $source, $message, array $context = array() ) {
		$this->log( self::LEVEL_INFO, $source, $message, $context );
	}

	/**
	 * Convenience wrapper for auditable actions (settings changes,
	 * hardening toggles, quarantine restore/delete, remote-triggered
	 * operations).
	 *
	 * @param string $source  Module identifier.
	 * @param string $message Message.
	 * @param array  $context Context.
	 */
	public function action( $source, $message, array $context = array() ) {
		$this->log( self::LEVEL_ACTION, $source, $message, $context );
	}

	/**
	 * Query recent log entries.
	 *
	 * @param array $args {
	 *     Optional filters.
	 *
	 *     @type string $level  Restrict to one level.
	 *     @type string $source Restrict to one source module.
	 *     @type int    $paged  1-indexed page number.
	 *     @type int    $per_page Rows per page.
	 * }
	 * @return array{rows: array<int, object>, total: int}
	 */
	public function get_logs( array $args = array() ) {
		global $wpdb;

		$defaults = array(
			'level'    => '',
			'source'   => '',
			'paged'    => 1,
			'per_page' => 50,
		);
		$args     = wp_parse_args( $args, $defaults );

		$where  = array( '1=1' );
		$params = array();

		if ( ! empty( $args['level'] ) ) {
			$where[]  = 'level = %s';
			$params[] = $args['level'];
		}

		if ( ! empty( $args['source'] ) ) {
			$where[]  = 'source = %s';
			$params[] = $args['source'];
		}

		$where_sql = implode( ' AND ', $where );
		$table     = $this->table();
		$offset    = max( 0, ( (int) $args['paged'] - 1 ) * (int) $args['per_page'] );

		$count_sql = "SELECT COUNT(*) FROM {$table} WHERE {$where_sql}"; // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$total     = (int) ( empty( $params )
			? $wpdb->get_var( $count_sql ) // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
			: $wpdb->get_var( $wpdb->prepare( $count_sql, $params ) ) ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared

		$rows_sql   = "SELECT * FROM {$table} WHERE {$where_sql} ORDER BY id DESC LIMIT %d OFFSET %d"; // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$row_params = array_merge( $params, array( (int) $args['per_page'], $offset ) );
		$rows       = $wpdb->get_results( $wpdb->prepare( $rows_sql, $row_params ) ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared

		return array(
			'rows'  => $rows ? $rows : array(),
			'total' => $total,
		);
	}

	/**
	 * Stream all log rows as CSV to the current output buffer. Caller
	 * is responsible for sending headers before invoking this.
	 */
	public function export_csv() {
		global $wpdb;

		$table  = $this->table();
		$rows   = $wpdb->get_results( "SELECT id, level, source, message, context, created_at FROM {$table} ORDER BY id DESC" ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.PreparedSQL.NotPrepared
		$output = fopen( 'php://output', 'w' );

		fputcsv( $output, array( 'ID', 'Level', 'Source', 'Message', 'Context', 'Created At (UTC)' ) );

		foreach ( $rows as $row ) {
			fputcsv( $output, array( $row->id, $row->level, $row->source, $row->message, $row->context, $row->created_at ) );
		}

		fclose( $output );
	}

	/**
	 * Delete log entries older than the retention window. Hooked into
	 * daily maintenance by Scheduler.
	 *
	 * @param int $days Retention window in days.
	 */
	public function prune( $days = 90 ) {
		global $wpdb;

		$table = $this->table();
		$wpdb->query( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.PreparedSQL.NotPrepared
			$wpdb->prepare(
				"DELETE FROM {$table} WHERE created_at < %s", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				gmdate( 'Y-m-d H:i:s', time() - ( (int) $days * DAY_IN_SECONDS ) )
			)
		);
	}
}
