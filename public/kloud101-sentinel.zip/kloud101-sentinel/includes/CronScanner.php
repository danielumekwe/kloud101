<?php
/**
 * WP-Cron table inspection for orphaned or suspiciously-named
 * scheduled hooks.
 *
 * @package Kloud101Sentinel\Includes
 */

namespace Kloud101Sentinel\Includes;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class CronScanner
 *
 * WP-Cron entries are a common persistence mechanism for malware: a
 * compromised plugin schedules a hook that re-downloads a payload or
 * re-injects a backdoor on a timer, then the plugin file itself is
 * cleaned up — leaving only the cron entry behind. This scanner cannot
 * prove intent offline, so it flags two objective signals: hooks with
 * no registered callback (orphaned — the scheduled event does nothing
 * useful and legitimate plugins don't leave these behind), and hook
 * names that look machine-generated rather than namespaced by a
 * plugin/theme author.
 */
class CronScanner {

	/**
	 * @var Logger
	 */
	private $logger;

	/**
	 * @var Utilities
	 */
	private $utilities;

	/**
	 * @var Findings
	 */
	private $findings;

	/**
	 * Constructor.
	 *
	 * @param Logger    $logger    Shared logger.
	 * @param Utilities $utilities Shared helpers.
	 * @param Findings  $findings  Shared findings repository.
	 */
	public function __construct( Logger $logger, Utilities $utilities, Findings $findings ) {
		$this->logger    = $logger;
		$this->utilities = $utilities;
		$this->findings  = $findings;
	}

	/**
	 * Scan the WP-Cron table.
	 *
	 * @param int $scan_id Owning report ID.
	 * @return int Findings recorded.
	 */
	public function scan( $scan_id ) {
		$cron_array = _get_cron_array();

		if ( empty( $cron_array ) || ! is_array( $cron_array ) ) {
			return 0;
		}

		$count          = 0;
		$known_wp_hooks = $this->core_cron_hooks();

		foreach ( $cron_array as $timestamp => $hooks ) {
			if ( ! is_array( $hooks ) ) {
				continue;
			}

			foreach ( $hooks as $hook => $events ) {
				if ( in_array( $hook, $known_wp_hooks, true ) ) {
					continue;
				}

				if ( $this->looks_machine_generated( $hook ) ) {
					$this->findings->record(
						array(
							'scan_id'     => $scan_id,
							'type'        => 'cron',
							'severity'    => Findings::SEVERITY_HIGH,
							'file_path'   => '',
							'signature'   => 'suspicious_cron_hook_name',
							'description' => sprintf( __( 'Scheduled cron hook "%s" has a machine-generated-looking name rather than a plugin/theme namespaced one.', 'kloud101-sentinel' ), $hook ),
						)
					);
					++$count;
					continue;
				}

				if ( ! has_action( $hook ) ) {
					$this->findings->record(
						array(
							'scan_id'     => $scan_id,
							'type'        => 'cron',
							'severity'    => Findings::SEVERITY_MEDIUM,
							'file_path'   => '',
							'signature'   => 'orphaned_cron_hook',
							'description' => sprintf( __( 'Scheduled cron hook "%s" has no registered callback — it may be a leftover from a removed (or partially cleaned up) plugin.', 'kloud101-sentinel' ), $hook ),
						)
					);
					++$count;
				}
			}
		}

		return $count;
	}

	/**
	 * Hook names look machine-generated when they are a long run of hex
	 * or base64-ish characters with no separators, or match a UUID —
	 * legitimate plugin authors virtually always namespace hooks with
	 * underscores/slashes (e.g. "woocommerce_cleanup_sessions").
	 *
	 * @param string $hook Cron hook name.
	 * @return bool
	 */
	private function looks_machine_generated( $hook ) {
		if ( preg_match( '/^[a-f0-9]{16,}$/i', $hook ) ) {
			return true;
		}

		if ( preg_match( '/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i', $hook ) ) {
			return true;
		}

		if ( strlen( $hook ) >= 20 && false === strpos( $hook, '_' ) && false === strpos( $hook, '-' ) && false === strpos( $hook, '/' ) ) {
			return true;
		}

		return false;
	}

	/**
	 * Core WordPress cron hooks that should never be flagged even
	 * though checking has_action() against them this early may return
	 * false in some contexts.
	 *
	 * @return string[]
	 */
	private function core_cron_hooks() {
		return array(
			'wp_version_check',
			'wp_update_plugins',
			'wp_update_themes',
			'wp_scheduled_delete',
			'wp_scheduled_auto_draft_delete',
			'wp_privacy_delete_old_export_files',
			'delete_expired_transients',
			'recovery_mode_clean_expired_keys',
			'wp_https_detection',
			'wp_site_health_scheduled_check',
			'kloud101_sentinel_scheduled_scan',
			'kloud101_sentinel_daily_maintenance',
		);
	}
}
