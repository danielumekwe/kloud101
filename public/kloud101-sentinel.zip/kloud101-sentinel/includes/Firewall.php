<?php
/**
 * Lightweight application firewall: blocks common exploit payloads at
 * the request level, before WordPress routing has a chance to act on
 * them.
 *
 * @package Kloud101Sentinel\Includes
 */

namespace Kloud101Sentinel\Includes;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Firewall
 *
 * Hooks as early as 'init' (the earliest point at which WordPress has
 * finished enough bootstrapping for capability/option lookups to be
 * safe) and inspects the raw request line, query string, and POST body
 * for signatures of SQL injection, XSS, path traversal, and known bad
 * bot/user-agent strings. Every rule is a static local regex — there
 * is no remote reputation lookup, by design, so the firewall keeps
 * working even if the site has no outbound connectivity.
 */
class Firewall {

	/**
	 * @var Logger
	 */
	private $logger;

	/**
	 * @var Utilities
	 */
	private $utilities;

	/**
	 * @var Findings
	 */
	private $findings;

	/**
	 * Constructor.
	 *
	 * @param Logger    $logger    Shared logger.
	 * @param Utilities $utilities Shared helpers.
	 * @param Findings  $findings  Shared findings repository.
	 */
	public function __construct( Logger $logger, Utilities $utilities, Findings $findings ) {
		$this->logger    = $logger;
		$this->utilities = $utilities;
		$this->findings  = $findings;
	}

	/**
	 * Register hooks. Priority 1 on 'init' so the check runs before
	 * virtually all plugin/theme code, minimizing the chance a
	 * malicious request reaches vulnerable application logic first.
	 *
	 * @param Loader $loader Shared hook loader.
	 */
	public function register( Loader $loader ) {
		$loader->add_action( 'init', $this, 'inspect_request', 1 );
	}

	/**
	 * Rule catalog, grouped by the settings toggle that gates them.
	 *
	 * @return array<string, array<int, string>>
	 */
	private function rule_groups() {
		return array(
			'firewall_block_sqli'      => array(
				'/(\%27)|(\')|(\-\-)|(\%23)|(#)/i',
				'/((\%3D)|(=))[^\n]*((\%27)|(\')|(\-\-)|(\%3B)|(;))/i',
				'/\b(union\s+select|select\s+.*\s+from|information_schema|sleep\s*\(\s*\d|benchmark\s*\()/i',
			),
			'firewall_block_xss'       => array(
				'/<script[^>]*>.*?<\/script>/is',
				'/on(?:error|load|click|mouseover|focus)\s*=\s*["\']?/i',
				'/javascript\s*:/i',
			),
			'firewall_block_traversal' => array(
				'/\.\.\/|\.\.\\\\/',
				'/(?:etc\/passwd|proc\/self\/environ|boot\.ini|win\.ini)/i',
			),
			'firewall_block_bad_bots'  => array(
				'/\b(?:masscan|sqlmap|nikto|acunetix|nmap|libwww-perl|havij|wpscan)\b/i',
			),
		);
	}

	/**
	 * Known exploit / probing URL fragments that are always blocked
	 * regardless of the per-category toggles, since they have no
	 * legitimate use case on a normal WordPress request.
	 *
	 * @return array<int, string>
	 */
	private function always_blocked_paths() {
		return array( '/wp-config.php', '/.env', '/.git/config', '/phpmyadmin', '/xmlrpc.php?', '/.ssh/' );
	}

	/**
	 * Inspect the current request and block it (403) if it matches an
	 * enabled rule category. Whitelisted IPs are never blocked.
	 */
	public function inspect_request() {
		$settings = wp_parse_args( get_option( 'kloud101_sentinel_settings', array() ), Installer::default_settings() );

		if ( empty( $settings['firewall_enabled'] ) ) {
			return;
		}

		$ip = Utilities::get_client_ip();

		if ( in_array( $ip, (array) $settings['login_whitelist'], true ) ) {
			return;
		}

		$request_uri = isset( $_SERVER['REQUEST_URI'] ) ? wp_unslash( $_SERVER['REQUEST_URI'] ) : ''; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.MissingUnslash
		$user_agent  = isset( $_SERVER['HTTP_USER_AGENT'] ) ? wp_unslash( $_SERVER['HTTP_USER_AGENT'] ) : ''; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.MissingUnslash
		$query       = isset( $_SERVER['QUERY_STRING'] ) ? wp_unslash( $_SERVER['QUERY_STRING'] ) : ''; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.MissingUnslash
		$post_body   = ! empty( $_POST ) ? wp_json_encode( wp_unslash( $_POST ) ) : ''; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.MissingUnslash

		$haystacks = array_filter( array( $request_uri, $query, $post_body, $user_agent ) );

		foreach ( $this->always_blocked_paths() as $path_fragment ) {
			if ( false !== stripos( $request_uri, $path_fragment ) ) {
				$this->block( $ip, 'blocked_path', sprintf( 'Request to known-sensitive path: %s', $path_fragment ) );
			}
		}

		foreach ( $this->rule_groups() as $setting_key => $patterns ) {
			if ( empty( $settings[ $setting_key ] ) ) {
				continue;
			}

			foreach ( $patterns as $pattern ) {
				foreach ( $haystacks as $haystack ) {
					if ( preg_match( $pattern, $haystack ) ) {
						$this->block( $ip, $setting_key, sprintf( 'Matched rule group "%s" on request content.', $setting_key ) );
					}
				}
			}
		}

		/**
		 * Allows a site owner (or a future addon) to add fully custom
		 * regex rules without editing this class.
		 *
		 * @param array $custom_patterns Array of PCRE patterns.
		 */
		$custom_patterns = apply_filters( 'kloud101_sentinel_firewall_custom_patterns', array() );

		foreach ( $custom_patterns as $pattern ) {
			foreach ( $haystacks as $haystack ) {
				if ( @preg_match( $pattern, $haystack ) ) { // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
					$this->block( $ip, 'custom_rule', sprintf( 'Matched custom firewall pattern: %s', $pattern ) );
				}
			}
		}
	}

	/**
	 * Log, record a finding for, and terminate a blocked request with a
	 * plain 403 response.
	 *
	 * @param string $ip          Offending IP.
	 * @param string $signature   Rule identifier.
	 * @param string $description Human-readable reason.
	 */
	private function block( $ip, $signature, $description ) {
		$this->findings->record(
			array(
				'type'        => 'firewall',
				'severity'    => Findings::SEVERITY_HIGH,
				'file_path'   => isset( $_SERVER['REQUEST_URI'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REQUEST_URI'] ) ) : '',
				'signature'   => $signature,
				'description' => sprintf( '[%s] %s', $ip, $description ),
			)
		);

		$this->logger->warning( 'firewall', sprintf( 'Blocked request from %s: %s', $ip, $description ), array( 'signature' => $signature ) );

		status_header( 403 );
		nocache_headers();
		wp_die(
			esc_html__( 'Request blocked by Kloud101 Sentinel.', 'kloud101-sentinel' ),
			esc_html__( 'Forbidden', 'kloud101-sentinel' ),
			array( 'response' => 403 )
		);
	}
}
