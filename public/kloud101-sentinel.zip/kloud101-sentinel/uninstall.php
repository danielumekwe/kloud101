<?php
/**
 * Uninstall handler.
 *
 * WordPress only ever loads this file via WP_UNINSTALL_PLUGIN, never as
 * part of a normal request, so it has no access to the plugin's
 * autoloaded classes unless it requires them itself. It deliberately
 * does the minimum necessary directly against $wpdb/the filesystem
 * rather than booting the whole plugin.
 *
 * @package Kloud101Sentinel
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

/**
 * Remove all Kloud101 Sentinel data for a single site (tables, options,
 * transients, and — if the owner opted in — quarantined files).
 *
 * @global wpdb $wpdb
 */
function kloud101_sentinel_uninstall_site() {
	global $wpdb;

	// The opt-in checkbox lives inside the single settings array (see
	// Settings::sanitize()), not as its own top-level option.
	$settings    = get_option( 'kloud101_sentinel_settings', array() );
	$remove_data = ! empty( $settings['remove_data_on_uninstall'] );

	if ( ! $remove_data ) {
		// Default is to preserve findings/quarantine/settings in case the
		// site owner is reinstalling rather than permanently removing
		// the plugin. Only the explicit opt-in below wipes everything.
		return;
	}

	$tables = array(
		$wpdb->prefix . 'k101_findings',
		$wpdb->prefix . 'k101_logs',
		$wpdb->prefix . 'k101_login_attempts',
		$wpdb->prefix . 'k101_quarantine',
		$wpdb->prefix . 'k101_file_hashes',
		$wpdb->prefix . 'k101_reports',
	);

	foreach ( $tables as $table ) {
		// Table names are hard-coded above (never user input), so this
		// direct query is safe without additional escaping/preparation.
		$wpdb->query( "DROP TABLE IF EXISTS `{$table}`" ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
	}

	// Every option name actually written by the plugin (see Installer,
	// UserScanner::BASELINE_OPTION, and PluginScanner's mtime snapshot).
	$options = array(
		'kloud101_sentinel_settings',
		'kloud101_sentinel_db_version',
		'kloud101_sentinel_activated_at',
		'kloud101_sentinel_admin_baseline',
		'kloud101_sentinel_plugin_mtimes',
	);

	foreach ( $options as $option ) {
		delete_option( $option );
		delete_site_option( $option );
	}

	// Remove quarantine directory and its contents (quarantined payloads
	// are neutralized copies, but honor an explicit "remove everything").
	if ( defined( 'KLOUD101_SENTINEL_QUARANTINE_DIR' ) && is_dir( KLOUD101_SENTINEL_QUARANTINE_DIR ) ) {
		kloud101_sentinel_rrmdir( KLOUD101_SENTINEL_QUARANTINE_DIR );
	}

	wp_clear_scheduled_hook( 'kloud101_sentinel_scheduled_scan' );
	wp_clear_scheduled_hook( 'kloud101_sentinel_daily_maintenance' );
}

/**
 * Recursively remove a directory and its contents.
 *
 * @param string $dir Absolute directory path.
 */
function kloud101_sentinel_rrmdir( $dir ) {
	$items = @scandir( $dir );

	if ( false === $items ) {
		return;
	}

	foreach ( $items as $item ) {
		if ( '.' === $item || '..' === $item ) {
			continue;
		}

		$path = $dir . '/' . $item;

		if ( is_dir( $path ) ) {
			kloud101_sentinel_rrmdir( $path );
		} else {
			@unlink( $path );
		}
	}

	@rmdir( $dir );
}

if ( is_multisite() ) {
	$site_ids = get_sites( array( 'fields' => 'ids' ) );

	foreach ( $site_ids as $site_id ) {
		switch_to_blog( $site_id );
		kloud101_sentinel_uninstall_site();
		restore_current_blog();
	}
} else {
	kloud101_sentinel_uninstall_site();
}
