=== Kloud101 Sentinel ===
Contributors: kloud101
Tags: security, malware scanner, firewall, file integrity, login protection
Requires at least: 6.0
Tested up to: 6.7
Requires PHP: 7.4
Stable tag: 1.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Enterprise-grade WordPress security: malware scanning, file integrity monitoring, upload scanning, login protection, a lightweight firewall, one-click hardening, and quarantine management — entirely offline, no external API required.

== Description ==

Kloud101 Sentinel is a complete WordPress security suite that runs entirely on your own server. It does not depend on any external API, cloud service, or reputation feed to function — every detection rule is a local signature or heuristic, so it keeps protecting your site even on a fully air-gapped host.

**Core capabilities**

* **Malware scanning** — recursive signature-based detection of webshells, obfuscated backdoors (`eval(base64_decode(...))`, hex/XOR obfuscation, `preg_replace` with the `/e` modifier, `create_function`, high-entropy encoded strings), cryptocurrency miners, hidden iframe/SEO-spam injections, and hidden JavaScript redirects.
* **File integrity monitoring** — SHA-256 baselines for WordPress core, every plugin, and every theme, with new/modified/deleted file detection and an optional best-effort cross-check against the official WordPress.org core checksums API.
* **Upload scanning** — blocks executable file types, double extensions, malicious SVGs, and image/PHP polyglots inside `wp-content/uploads`, auto-quarantining anything dangerous.
* **Plugin & theme security** — detects abandoned, duplicate, hidden, and known-vulnerable plugins, plus hidden theme directories and PHP embedded in theme assets.
* **Login protection** — IP-based brute-force rate limiting with temporary lockouts, a permanent blacklist/whitelist, forced logout, password strength enforcement, and a Two-Factor Authentication extension point.
* **Lightweight firewall** — blocks common SQL injection, XSS, path traversal, and known bad-bot request patterns before WordPress routes them.
* **One-click hardening** — disable XML-RPC, disable the theme/plugin file editor, block PHP execution in uploads, hide the WordPress version, disable directory browsing, protect wp-config.php/.htaccess, rotate secret keys/salts, and restrict the REST API to logged-in users.
* **Database & cron scanning** — flags suspicious autoloaded options, injected post content, hidden administrator accounts, and orphaned/suspiciously-named cron hooks.
* **Quarantine manager** — dangerous files are moved, never deleted, to a locked-down holding directory; restore or permanently delete them at any time.
* **Reports & logs** — a security score, print-ready HTML reports, CSV exports, and a full audit log of every action the plugin takes.

Every scan runs in small, resumable batches via WP-Cron and AJAX so it never times out or slows down your site — even on modest shared hosting.

== Installation ==

1. Upload the `kloud101-sentinel` folder to `/wp-content/plugins/`.
2. Activate the plugin through the "Plugins" screen in WordPress.
3. Visit **Sentinel** in the admin menu to review your security score and run your first scan.

== Frequently Asked Questions ==

= Does this plugin need an internet connection to work? =

No. Every detection rule (malware signatures, integrity hashing, firewall patterns) is entirely local. A small number of *optional* enrichments make outbound requests, only to the official WordPress.org API, and only when you allow them:

* **Core checksum verification** and **plugin abandonment lookups** are controlled by the "WordPress.org lookups" checkbox under Settings > Scanning (on by default, and you can turn it off at any time). When enabled, an Integrity Check sends your WordPress version and locale to `api.wordpress.org` to fetch the official core checksums, and a Full Scan sends each installed plugin's slug to check its last-updated date. No personal data, page content, or credentials are ever transmitted.
* **Salt rotation** (Settings > Hardening > "Rotate Salts") is a manual, one-click action you trigger yourself. It fetches fresh random keys from `api.wordpress.org/secret-key/1.1/salt/` and falls back to locally generated random values if that request fails or is unreachable.

With the "WordPress.org lookups" setting turned off, the plugin makes no outbound network requests of any kind and keeps protecting your site fully offline.

= Will scanning slow down my site? =

No. All scanning happens in the admin area via AJAX (manual scans) or WP-Cron (scheduled scans), in small batches, and never on a public-facing page load.

= What happens to a file that's flagged as malware? =

Files found in `wp-content/uploads` that match a dangerous pattern (wrong extension, double extension, embedded PHP, etc.) are automatically quarantined. Findings inside core/plugin/theme files are reported for manual review — the plugin never deletes or modifies your plugin/theme code automatically.

= Is quarantine safe? Can I undo it? =

Yes. Quarantine always *moves* a file (it is never copied-then-deleted, and never simply deleted) into a locked-down holding directory outside your web root's executable path. From the Quarantine Manager screen you can restore any quarantined file back to its original location at any time, or permanently delete the isolated copy — both actions require administrator permissions, a confirmation step, and are recorded in the audit log. Nothing is ever permanently deleted without an explicit, confirmed action from you.

= What data does this plugin collect or send? =

None of your site's content, credentials, or visitor data is collected or transmitted anywhere. The only outbound requests this plugin ever makes are the optional, disclosed calls to the official WordPress.org API described above, and only when you leave the "WordPress.org lookups" setting enabled. There is no telemetry, analytics, or tracking of any kind, and no account or sign-up is required to use any feature.

== Screenshots ==

1. Dashboard — overall security score, website health, and at-a-glance stats (active threats, quarantined files, failed logins, plugin/theme counts).
2. Run a Scan — Quick, Full, Uploads, and Integrity Check options with a live progress bar and recent scan history.
3. Quarantine Manager — review, restore, or permanently delete quarantined files.
4. Reports — scan history, security recommendations, and print-ready HTML/CSV export.
5. Settings — General, Scanning, Login Protection, Firewall, Hardening, and Notifications tabs.
6. Logs — filterable audit trail of every scan, finding, and administrative action, with CSV export.

== Changelog ==

= 1.0.0 =
* Initial release.
